"""Real local-Qwen evaluation with synthetic metadata only. Never uses Feishu/CALL-E."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import time
from feishu_calle.natural_language import LocalPlanner, ModelClarification
from feishu_calle.preview import Clarification


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--enable-local-model',action='store_true',required=True)
    parser.add_argument('--output',type=Path,default=Path('var/natural-language-evaluation.json'))
    args=parser.parse_args()
    fields=json.loads(Path('fixtures/natural-language/fields.json').read_text())
    planner=LocalPlanner();reports=[]
    cases=[('attendance','帮我联系活动名称是模拟产品交流会、出席意向还是待定的人，确认能否按时参加；同一号码保留一条。结果用回访出席意向记录参加、不参加、待定、不明，再用回访摘要记录简短说明。'),
           ('supplier','联系订单状态为待发货的供应商，问一下现在有没有发货，预计什么时候到货。发货确认记录已发货、未发货或不明，预计到货时间用文本，异常说明也用文本。同号只保留一个。')]
    drafts={}
    for name,text in cases:
        started=time.monotonic()
        try:
            definition=planner.propose(text,fields)
            drafts[name]=definition
            success=bool(definition['conditions']) and len(definition['result_fields'])>=2
            if name=='supplier':
                dispatch=next((f for f in definition['result_fields'] if f['label']=='发货确认'),{})
                success=success and dispatch.get('type')=='enum' and set(dispatch.get('options',[]))=={'已发货','未发货','不明'}
            reports.append({'case':name,'passed':success,'seconds':round(time.monotonic()-started,2),'definition':definition})
        except Clarification as e:reports.append({'case':name,'passed':False,'seconds':round(time.monotonic()-started,2),'clarification':str(e)})
        print(json.dumps({k:v for k,v in reports[-1].items() if k not in ('definition',)},ensure_ascii=False),flush=True)
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(reports,ensure_ascii=False,indent=2));args.output.chmod(0o600)
    if 'attendance' in drafts:
        previous=deepcopy(drafts['attendance'])
        changes=[('edit_enum','回访出席意向里不要待定了，只保留参加、不参加、不明。其他结果字段、任务目的、名单条件都不要改。'),
                 ('edit_filter','名单条件改成出席意向为参加，活动名称和其他设置保持不变。'),
                 ('edit_purpose','外呼目的改成询问他们是否需要活动资料，不再确认能否到场。筛选条件和结果字段暂时不改，后续我再修改。')]
        for name,text in changes:
            started=time.monotonic()
            try:
                definition=planner.propose(text,fields,previous=previous)
                if name=='edit_enum':
                    changed=next(f for f in definition['result_fields'] if f['label']=='回访出席意向')
                    success=changed['options']==['参加','不参加','不明'] and definition['conditions']==previous['conditions'] and definition['purpose']==previous['purpose'] and len(definition['result_fields'])==len(previous['result_fields'])
                elif name=='edit_filter':success=definition['purpose']==previous['purpose'] and definition['result_fields']==previous['result_fields'] and any(c[0]=='出席意向' and c[2]=='参加' for c in definition['conditions'])
                else:success='资料' in definition['purpose'] and definition['conditions']==previous['conditions'] and definition['result_fields']==previous['result_fields']
                reports.append({'case':name,'passed':success,'seconds':round(time.monotonic()-started,2),'definition':definition})
            except Clarification as e:reports.append({'case':name,'passed':False,'seconds':round(time.monotonic()-started,2),'clarification':str(e)})
            print(json.dumps({k:v for k,v in reports[-1].items() if k!='definition'},ensure_ascii=False),flush=True)
            args.output.write_text(json.dumps(reports,ensure_ascii=False,indent=2));args.output.chmod(0o600)
    extra=[('after_sales','只联系订单状态为已收货的客户，问他收到的货物有没有问题，只需要人工联系请求记录需要、不需要、不明，以及回访摘要。同一电话只留一个。',False),
           ('missing_goal_and_scope','帮我给表里的人打个电话。',True),
           ('unsupported_or','联系订单状态为已发货或者已收货的人，问一下收货情况。结果用回访摘要文本记录。',True)]
    for name,text,expect_question in extra:
        started=time.monotonic()
        try:
            definition=planner.propose(text,fields)
            success=not expect_question and any(c[0]=='订单状态' and c[2]=='已收货' for c in definition['conditions'])
            if name=='after_sales':success=success and definition['exclude_duplicates'] and any(f['label']=='人工联系请求' and f['type']=='enum' for f in definition['result_fields'])
            reports.append({'case':name,'passed':success,'seconds':round(time.monotonic()-started,2),'definition':definition})
        except ModelClarification as e:reports.append({'case':name,'passed':expect_question,'seconds':round(time.monotonic()-started,2),'clarification':str(e)})
        except Clarification as e:reports.append({'case':name,'passed':False,'seconds':round(time.monotonic()-started,2),'clarification':str(e)})
        print(json.dumps({k:v for k,v in reports[-1].items() if k!='definition'},ensure_ascii=False),flush=True)
        args.output.write_text(json.dumps(reports,ensure_ascii=False,indent=2));args.output.chmod(0o600)
    print(json.dumps({'cases':len(reports),'passed':sum(r['passed'] for r in reports),'real_calls':0},ensure_ascii=False),flush=True)


if __name__=='__main__':main()
