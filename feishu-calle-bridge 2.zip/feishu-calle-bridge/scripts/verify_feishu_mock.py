"""Explicitly authorized real Feishu/mock-telephone acceptance. Never constructs CalleAPI."""
import argparse
import json
import os
import time
from pathlib import Path
from feishu_calle.setup import load_local_env
from feishu_calle.config import Settings
from feishu_calle.store import Store
from feishu_calle.feishu import FeishuGateway, create_client
from feishu_calle.resources import BaseRef, WikiRef
from feishu_calle.preview import build_roster, init_previews, save_preview, text_value
from feishu_calle.definitions import init_definitions, save_definition, act_on_definition
from feishu_calle.jobs import init_jobs
from feishu_calle.execution import init_execution, attach_execution, approve_execution, ExecutionWorker, notify_execution


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--enable-feishu',action='store_true',required=True)
    parser.add_argument('--approve-mock-writeback',action='store_true',required=True)
    args=parser.parse_args()
    load_local_env(Path('.env'))
    settings=Settings.from_env(os.environ)
    if settings.mode!='mock' or not settings.writeback:
        raise ValueError('Acceptance requires mock mode and explicitly enabled writeback')
    store=Store(settings.database)
    init_jobs(store);init_definitions(store);init_previews(store);init_execution(store)
    gateway=FeishuGateway(create_client(settings.app_id,settings.app_secret))
    evidence=Path('var/feishu-mock-acceptance.json')
    if evidence.exists():
        record=json.loads(evidence.read_text())
        batch_id=record['batch_id']
    else:
        draft=store.db.execute("SELECT * FROM task_definitions WHERE state='confirmed' ORDER BY rowid DESC LIMIT 1").fetchone()
        if not draft or draft['actor'] not in settings.users or draft['chat_id'] not in settings.chats:
            raise ValueError('No prior operator-confirmed task in approved group')
        definition=json.loads(draft['definition']);payload=json.loads(draft['payload'])
        bindings=json.loads(Path('var/bindings.json').read_text())
        binding=next(x for x in bindings if x['chat_id']==draft['chat_id'])
        ref=BaseRef('my.feishu.cn',binding['app_token'],binding['table_id'],binding.get('view_id'))
        if binding.get('wiki_node_token'):
            ref=gateway.resolve_wiki(WikiRef(ref.host,binding['wiki_node_token'],ref.table_id,ref.view_id),ref.app_token)
        fields=gateway.fields(ref);records=gateway.records(ref)
        snapshot=build_roster(records,definition['conditions'],exclude_duplicates=definition['exclude_duplicates'])
        if not snapshot['candidates'] or any(p['data_mode']!='SYNTHETIC_NO_CALL' for p in snapshot['candidates']):
            raise ValueError('Mock acceptance is restricted to existing synthetic candidates')
        # This is a Codex-authorized development run, not a forged Feishu event or button click.
        payload.update(message_id='dev-mock-acceptance-20261101',origin='codex_explicit_mock_acceptance')
        definition.update(mode='mock',revision=definition['revision']+1)
        fresh=save_definition(store,payload,definition)
        act_on_definition(store,fresh['token'],payload['actor'],payload['chat_id'],'confirm')
        # The harness owns the scan; do not leave a second scan for the listener to replay.
        with store.db:store.db.execute("UPDATE inspection_jobs SET state='done' WHERE message_id=?",(payload['message_id']+':scan',))
        snapshot.update(definition_token=fresh['token'],purpose=definition['purpose'],result_fields=definition['result_fields'])
        attach_execution(snapshot,definition,ref,records,fields,settings)
        if not snapshot['execution_ready']:
            print(json.dumps({'stage':'preflight','execution_ready':False,'outputs':[{k:v for k,v in f.items() if k in ('field_name','type','options')} for f in snapshot['execution']['outputs']]},ensure_ascii=False))
            return
        preview=save_preview(store,payload,snapshot)
        batch_id=approve_execution(store,preview['token'],payload['actor'],payload['chat_id'],'execute_mock',settings)
        record={'batch_id':batch_id,'origin':'user authorized development mock/writeback acceptance in Codex',
                'mode':'mock','scanned':snapshot['scanned'],'candidates':len(snapshot['candidates']),
                'candidate_labels':[p['label'] for p in snapshot['candidates']],
                'before':{r['record_id']:r['fields'] for r in records},'real_calls_created':0}
        fd=os.open(evidence,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
        with os.fdopen(fd,'w') as handle:json.dump(record,handle,ensure_ascii=False,indent=2)
        print(json.dumps({'stage':'batch_created','mode':'mock','scanned':snapshot['scanned'],'candidates':len(snapshot['candidates'])},ensure_ascii=False),flush=True)
    worker=ExecutionWorker(store,gateway,settings)
    notify_execution(store,gateway)
    for _ in range(100):
        worker.tick()
        notify_execution(store,gateway)
        batch=store.db.execute('SELECT * FROM execution_batches WHERE id=?',(batch_id,)).fetchone()
        counts=dict(store.db.execute('SELECT state,count(*) FROM execution_items WHERE batch_id=? GROUP BY state',(batch_id,)))
        if batch['state'] in ('finished','paused','cancelled'):
            print(json.dumps({'stage':'execution','state':batch['state'],'item_counts':counts},ensure_ascii=False),flush=True)
            if batch['state']!='finished':
                errors=[dict(r) for r in store.db.execute('SELECT state,error_kind FROM execution_items WHERE batch_id=?',(batch_id,))]
                print(json.dumps({'errors':errors},ensure_ascii=False),flush=True)
                return
            break
        time.sleep(0.3)
    else:
        print('Acceptance interrupted: run remains persisted; no replacement calls will be created.')
        return
    manifest=json.loads(batch['manifest']);ref=BaseRef(**manifest['execution']['resource'])
    current={r['record_id']:r['fields'] for r in gateway.records(ref)}
    output_names={f['field_name'] for f in manifest['execution']['outputs']}
    changed=[];unexpected=[]
    for rid,old in record['before'].items():
        new=current.get(rid)
        if new is None:unexpected.append('record_deleted');continue
        for key in set(old)|set(new):
            if text_value(old.get(key))!=text_value(new.get(key)):
                changed.append(key)
                if key not in output_names:unexpected.append(key)
    items=store.db.execute('SELECT state,output,record_id FROM execution_items WHERE batch_id=?',(batch_id,)).fetchall()
    outputs_match=all(r['state']=='done' and all(text_value(current.get(r['record_id'],{}).get(k))==v for k,v in json.loads(r['output'] or '{}').items()) for r in items)
    notifications=store.db.execute('SELECT message_id FROM execution_notifications WHERE batch_id=?',(batch_id,)).fetchone()
    record['verification']={'outputs_match':outputs_match,'changed_fields':sorted(set(changed)),
                            'unexpected_changes':unexpected,'completion_card_message_saved':bool(notifications and notifications[0]),
                            'real_calls_created':0,'mode':'mock'}
    evidence.write_text(json.dumps(record,ensure_ascii=False,indent=2));evidence.chmod(0o600)
    print(json.dumps(record['verification'],ensure_ascii=False),flush=True)
    store.close()


if __name__=='__main__':main()
