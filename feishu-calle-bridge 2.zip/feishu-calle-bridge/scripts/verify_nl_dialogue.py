"""Actual local-model clarification and revision roundtrip; temporary DB, no remote services."""
import argparse
import json
from pathlib import Path
import tempfile
from feishu_calle.store import Store
from feishu_calle.jobs import init_jobs
from feishu_calle.definitions import init_definitions
from feishu_calle.preview import init_previews
from feishu_calle.execution import init_execution
from feishu_calle.natural_language import LocalPlanner,ModelClarification
from feishu_calle.nl_workflow import init_nl_workflow,resolve_nl_input,propose_nl_task


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--enable-local-model',action='store_true',required=True);parser.parse_args()
    fields=json.loads(Path('fixtures/natural-language/fields.json').read_text())
    with tempfile.TemporaryDirectory() as folder:
        store=Store(Path(folder)/'state.sqlite3')
        for init in (init_jobs,init_definitions,init_previews,init_execution,init_nl_workflow):init(store)
        planner=LocalPlanner()
        first={'message_id':'first','chat_id':'synthetic-chat','actor':'synthetic-user',
               'text':'帮我给表里的人打个电话。 https://example.feishu.cn/base/BASEexample?table=tblExample&view=vewExample'}
        try:propose_nl_task(store,planner,first,resolve_nl_input(store,first),fields)
        except ModelClarification:pass
        else:raise AssertionError('Missing task facts should request clarification')
        answer={**first,'message_id':'answer','text':'确认他们能否参加活动，只联系活动名称是模拟产品交流会、出席意向为待定的人。同号只留一个。回访出席意向记录参加、不参加、不明，回访摘要记录文本。'}
        context=resolve_nl_input(store,answer);assert 'https://' in context['source']['text']
        ready=propose_nl_task(store,planner,answer,context,fields)
        before=json.loads(ready['definition'])
        edit={**first,'message_id':'edit','text':'回访出席意向改成参加、不参加、待定、不明，其他条件和目的保持不变。'}
        changed=propose_nl_task(store,planner,edit,resolve_nl_input(store,edit),fields)
        after=json.loads(changed['definition'])
        report={'clarification_context_preserved':True,'link_inherited':True,
                'purpose_preserved':before['purpose']==after['purpose'],'filters_preserved':before['conditions']==after['conditions'],
                'old_version_invalidated':store.db.execute('SELECT state FROM task_definitions WHERE token=?',(ready['token'],)).fetchone()[0]=='superseded',
                'new_version_pending_confirmation':changed['state']=='pending',
                'phone_submissions':store.db.execute('SELECT count(*) FROM submissions').fetchone()[0]}
        assert all(report[k] for k in report if k!='phone_submissions') and report['phone_submissions']==0
        out=Path('var/nl-dialogue-verification.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2));out.chmod(0o600)
        print(json.dumps(report,ensure_ascii=False),flush=True)
        store.close()


if __name__=='__main__':main()
