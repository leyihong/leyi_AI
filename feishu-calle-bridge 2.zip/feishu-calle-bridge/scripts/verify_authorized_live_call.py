"""Explicit one-recipient acceptance via the project API adapter. No automatic redial."""
import argparse
from copy import deepcopy
from dataclasses import replace
from datetime import datetime
import json
import os
from pathlib import Path
import time
from zoneinfo import ZoneInfo
from feishu_calle.setup import load_local_env
from feishu_calle.config import Settings
from feishu_calle.store import Store
from feishu_calle.feishu import FeishuGateway,create_client
from feishu_calle.resources import BaseRef,WikiRef
from feishu_calle.preview import init_previews,build_roster,save_preview,text_value
from feishu_calle.jobs import init_jobs
from feishu_calle.definitions import init_definitions,save_definition,act_on_definition
from feishu_calle.execution import init_execution,attach_execution,approve_execution,ExecutionWorker,notify_execution
from feishu_calle.calle_api import API_ORIGIN


def private_save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(descriptor,'w') as f:json.dump(value,f,ensure_ascii=False,indent=2)
    path.chmod(0o600)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--authorization-file',type=Path,required=True)
    parser.add_argument('--checkpoint',type=Path,default=Path('var/live-attendance-acceptance.json'))
    parser.add_argument('--retry-previous',type=Path)
    parser.add_argument('--execute-authorized-one-call',action='store_true',required=True)
    args=parser.parse_args()
    auth=json.loads(args.authorization_file.read_text())
    if auth.get('max_calls')!=1 or auth.get('purpose')!='attendance_confirmation' or not auth.get('explicit_user_authorization'):
        raise ValueError('This harness requires an existing explicit one-call user authorization')
    now=datetime.now(ZoneInfo('Asia/Shanghai'))
    if auth.get('region','CN')=='CN' and not 8<=now.hour<21:raise ValueError('Outside approved CN test-line window')
    test_bot=auth.get('recipient_kind')=='provider_test_bot'
    if test_bot and auth['phone']!='+12763229632':raise ValueError('Automated test exception is not valid for this number')
    load_local_env(Path('.env'))
    if os.environ.get('CALLE_BASE_URL',API_ORIGIN)!=API_ORIGIN:raise ValueError('API configuration mismatch')
    configured=Settings.from_env(os.environ)
    # Do not switch the background bot or persist a global live-mode change.
    settings=replace(configured,mode='live',allowed_phones=(auth['phone'],),writeback=True)
    if not settings.api_key:raise ValueError('API Key missing')
    store=Store(settings.database)
    for init in (init_jobs,init_definitions,init_previews,init_execution):init(store)
    gateway=FeishuGateway(create_client(settings.app_id,settings.app_secret))
    checkpoint=args.checkpoint
    previous_attempt=json.loads(args.retry_previous.read_text()) if args.retry_previous else None
    bindings=json.loads(Path('var/bindings.json').read_text())
    binding=next(x for x in bindings if x['chat_id'] in settings.chats)
    ref=BaseRef('my.feishu.cn',binding['app_token'],binding['table_id'],binding.get('view_id'))
    if binding.get('wiki_node_token'):ref=gateway.resolve_wiki(WikiRef(ref.host,binding['wiki_node_token'],ref.table_id,ref.view_id),ref.app_token)
    if checkpoint.exists():
        proof=json.loads(checkpoint.read_text());batch_id=proof['batch_id']
        if proof['authorized_phone']!=auth['phone']:raise ValueError('Existing acceptance belongs to another recipient')
    else:
        fields=gateway.fields(ref);records=gateway.records(ref)
        label=auth.get('record_label','LIVE-20261102-001')
        matches=[r for r in records if text_value(r['fields'].get('测试记录编号'))==label]
        if len(matches)>1:raise ValueError('Ambiguous existing real-test record; reconcile first')
        source=next(r['fields'] for r in records if text_value(r['fields'].get('测试记录编号'))=='T001')
        if matches:
            row=matches[0]
            if text_value(row['fields'].get('电话号码'))!=auth['phone']:raise ValueError('Existing test record phone differs')
        else:
            values={'测试记录编号':label,'联系人':auth.get('contact_label','用户本人（真实链路验收）'),'电话号码':auth['phone'],
                    '活动名称':source['活动名称'],'活动时间':source['活动时间'],'活动时区':source['活动时区'],
                    '联系人时区':auth.get('timezone','Asia/Shanghai'),'通话地区':auth.get('region','CN'),'通话语言':auth.get('locale','zh-CN'),'出席意向':'待定',
                    '允许电话联系':'是','禁止联系':'否','授权来源':auth.get('authorization_label','用户在 Codex 明确授权本人号码单次真实参会确认测试（2026-11-02）'),
                    '数据模式':'REAL_AUTHORIZED','外呼状态':'待外呼'}
            row=gateway.create_record(ref,values,auth.get('operation_id','authorized-own-attendance-test-20261102'))
        previous=store.db.execute("SELECT * FROM task_definitions WHERE state='confirmed' ORDER BY rowid DESC LIMIT 1").fetchone()
        if not previous:raise ValueError('No confirmed business definition')
        definition=deepcopy(json.loads(previous['definition']))
        event_time=datetime.fromisoformat(text_value(source['活动时间']).replace('Z','+00:00')).astimezone(ZoneInfo('Asia/Shanghai'))
        definition['purpose']=('这是用户授权的一次真实电话链路验收，请用普通话。开场说明是 CALL-E 的 AI 助手，正在做用户授权的模拟参会确认测试，先询问现在是否方便。'
            '外呼目的沿用已确认任务：确认对方是否能够按时参加活动。活动名称是'+text_value(source['活动名称'])+'，'
            '表格时间按其 UTC 标记换算为北京时间 '+event_time.strftime('%Y年%m月%d日 %H:%M')+'。'
            '如对方不能确定是否参加，使用已确认枚举中的不明，不把犹豫强行当成不参加。询问是否需要工作人员后续联系。'
            '活动地点、时长等未提供的信息不能编造；如被询问则在摘要中记录需要人工补充。收到答复后礼貌结束，不做购买或商业承诺，不自动回拨。')
        if auth.get('locale')=='en-US':
            definition['purpose']=(
                'Speak English. This is an authorized end-to-end integration test with the automated reception test line supplied in the assignment. '
                'Identify yourself as CALL-E AI assistant and explain this is a simulated attendance-confirmation test, not a real booking or invitation. '
                'The mock product-exchange event (table label 模拟产品交流会) is on November 6, 2026 at '+event_time.strftime('%H:%M')+' Beijing time (UTC+8). '
                'Ask whether the test recipient can attend, and whether staff follow-up is requested. '
                'If the automated recipient cannot make a commitment, preserve unknown rather than infer yes/no. '
                'No venue or duration has been provided; do not invent them or make commercial promises. Politely end after the response. '
                'Extract into the confirmed Chinese result values: attendance 参加 / 不参加 / 不明, staff contact 需要 / 不需要 / 不明. '
                'Write the factual summary in Chinese. No automatic redial.')
        definition['conditions']=[('测试记录编号','=',label)]
        id_field=next(f for f in fields if f['field_name']=='测试记录编号')
        definition['condition_bindings']=[{'field_id':id_field['field_id'],'field_name':'测试记录编号','operator':'=','value':label}]
        definition['mode']='live';definition['exclude_duplicates']=True
        definition['context_fields']=['活动名称','活动时间','活动时区']
        definition['revision']+=1
        definition['proposal_source']=auth.get('authorization_label','用户在 Codex 明确授权的本人单通电话链路验收。')
        payload={'message_id':auth.get('operation_id','authorized-live-attendance-20261102'),'actor':settings.users[0],
                 'chat_id':binding['chat_id'],'text':definition['purpose'],'origin':'explicit_codex_user_one_call_test'}
        fresh=save_definition(store,payload,definition)
        act_on_definition(store,fresh['token'],payload['actor'],payload['chat_id'],'confirm')
        with store.db:store.db.execute("UPDATE inspection_jobs SET state='done' WHERE message_id=?",(payload['message_id']+':scan',))
        actual=gateway.record(ref,row['record_id'])
        snapshot=build_roster([actual],definition['conditions'],exclude_duplicates=True)
        assert len(snapshot['candidates'])==1 and snapshot['candidates'][0]['phone']==auth['phone']
        snapshot.update(definition_token=fresh['token'],purpose=definition['purpose'],result_fields=definition['result_fields'])
        attach_execution(snapshot,definition,ref,[actual],fields,settings)
        if test_bot:
            snapshot['execution']['authorized_provider_test_bot']=True
            snapshot['candidates'][0]['recipient_kind']='provider_test_bot'
        if previous_attempt:
            parent=store.db.execute('SELECT i.id,s.provider_id FROM execution_items i JOIN submissions s ON s.operation_id=i.id WHERE i.batch_id=?',(previous_attempt['batch_id'],)).fetchone()
            assert previous_attempt['authorized_phone']==auth['phone'] and previous_attempt['record_id']==row['record_id']
            snapshot['execution']['explicit_recontact']={'authorization_id':auth['operation_id'],'scope':'one_more_call','phone':auth['phone'],
                  'parent_operation_id':parent['id'],'parent_resource_id':parent['provider_id']}
        preview=save_preview(store,payload,snapshot)
        batch_id=approve_execution(store,preview['token'],payload['actor'],payload['chat_id'],'execute_live',settings)
        proof={'batch_id':batch_id,'record_id':row['record_id'],'authorized_phone':auth['phone'],
               'interface':'api-key','origin':API_ORIGIN,'max_logical_calls':1,'state':'prepared',
               'activity_time_beijing':event_time.isoformat(),'result_fields':[f['label'] for f in definition['result_fields']]}
        private_save(checkpoint,proof)
        print(json.dumps({'stage':'prepared','recipients':1,'mode':'live','test_record_label':label},ensure_ascii=False),flush=True)
    worker=ExecutionWorker(store,gateway,settings)
    last_notice=0;last_signature=None
    for _ in range(1500):
        worker.tick()
        batch=store.db.execute('SELECT * FROM execution_batches WHERE id=?',(batch_id,)).fetchone()
        items=store.db.execute('SELECT * FROM execution_items WHERE batch_id=?',(batch_id,)).fetchall()
        if len(items)!=1:raise RuntimeError('Acceptance cannot process multiple recipients')
        item=items[0]
        signature=(batch['state'],item['state'],item['error_kind'])
        if signature!=last_signature:
            print(json.dumps({'batch_state':batch['state'],'item_state':item['state'],'error_kind':item['error_kind']},ensure_ascii=False),flush=True)
            last_signature=signature
        if time.time()-last_notice>=3 or batch['state'] in ('finished','stopped','paused'):
            try:notify_execution(store,gateway)
            except Exception as e:print(json.dumps({'notification_error_type':type(e).__name__}),flush=True)
            last_notice=time.time()
        if batch['state'] in ('finished','stopped','paused','cancelled'):
            proof.update(state=batch['state'],item_state=item['state'],error_kind=item['error_kind'],
                         response=json.loads(item['response']) if item['response'] else None,
                         output=json.loads(item['output']) if item['output'] else None)
            original=store.db.execute('SELECT provider_id FROM submissions WHERE operation_id=?',(item['id'],)).fetchone()
            proof['provider_resource_id']=original['provider_id'] if original else None
            current=gateway.record(ref,proof['record_id'])
            proof['writeback_verified']=item['state']=='done' and all(text_value(current['fields'].get(k))==v for k,v in (proof['output'] or {}).items())
            private_save(checkpoint,proof)
            print(json.dumps({'stage':'acceptance_stopped','state':batch['state'],'item_state':item['state'],
                              'writeback_verified':proof['writeback_verified'],'resource_id_saved':bool(proof['provider_resource_id'])},ensure_ascii=False),flush=True)
            break
        time.sleep(0.5)
    store.close()


if __name__=='__main__':main()
