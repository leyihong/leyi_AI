"""Run a loopback-only Ollama service; weights/runtime are external, not part of the contribution."""
import os
from pathlib import Path
import shutil
import subprocess
import httpx


def main():
    try:
        response=httpx.get('http://127.0.0.1:11434/api/tags',timeout=2,trust_env=False)
        if response.status_code==200:
            print('Reusing the existing local Ollama service on 127.0.0.1:11434.')
            return
    except httpx.HTTPError:pass
    root=Path(__file__).resolve().parents[1]
    bundled=root/'var/ollama-runtime/ollama'
    executable=str(bundled) if bundled.exists() else shutil.which('ollama')
    if not executable:
        raise SystemExit('Install Ollama from https://ollama.com/download, then rerun. Runtime/weights are not included in this contribution.')
    env={**os.environ,'OLLAMA_HOST':'127.0.0.1:11434','OLLAMA_MODELS':str(root/'var/ollama-models'),
         'OLLAMA_NO_CLOUD':'1','OLLAMA_NUM_PARALLEL':'1','OLLAMA_CONTEXT_LENGTH':'8192'}
    print('Starting local-only Ollama. Pull qwen3:4b in a second terminal; no phone services are used.',flush=True)
    subprocess.run([executable,'serve'],env=env,check=True)


if __name__=='__main__':main()
