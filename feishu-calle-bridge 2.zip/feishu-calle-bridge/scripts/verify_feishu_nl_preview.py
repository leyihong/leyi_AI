"""Authorized local-Qwen + real Feishu metadata/preview check. No calls or record writes."""
import argparse
from dataclasses import asdict
import json
import os
import httpx
from pathlib import Path
from feishu_calle.setup import load_local_env
from feishu_calle.config import Settings
from feishu_calle.store import Store
from feishu_calle.feishu import FeishuGateway,create_client
from feishu_calle.resources import BaseRef,WikiRef
from feishu_calle.jobs import init_jobs
from feishu_calle.definitions import init_definitions,definition_card
from feishu_calle.preview import init_previews
from feishu_calle.execution import init_execution
from feishu_calle.natural_language import LocalPlanner
from feishu_calle.nl_workflow import init_nl_workflow,resolve_nl_input,propose_nl_task


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--enable-feishu',action='store_true',required=True);parser.parse_args()
    load_local_env(Path('.env'));settings=Settings.from_env(os.environ)
    assert settings.mode=='mock' and not settings.allowed_phones
    bindings=json.loads(Path('var/bindings.json').read_text())
    binding=next(b for b in bindings if b['chat_id'] in settings.chats)
    gateway=FeishuGateway(create_client(settings.app_id,settings.app_secret))
    ref=BaseRef('my.feishu.cn',binding['app_token'],binding['table_id'],binding.get('view_id'))
    if binding.get('wiki_node_token'):ref=gateway.resolve_wiki(WikiRef(ref.host,binding['wiki_node_token'],ref.table_id,ref.view_id),ref.app_token)
    fields=gateway.fields(ref)
    key='wiki/'+binding['wiki_node_token'] if binding.get('wiki_node_token') else 'base/'+ref.app_token
    link='https://my.feishu.cn/'+key+'?table='+ref.table_id+('&view='+ref.view_id if ref.view_id else '')
    text='帮我联系出席意向还是待定且活动名称为模拟产品交流会的人，确认能否按时参加。重复电话号码只保留一条。回访出席意向记录参加、不参加、待定、不明，人工联系请求记录需要、不需要、不明，回访摘要记录文本。\n'+link
    store=Store(settings.database)
    for init in (init_jobs,init_definitions,init_previews,init_execution,init_nl_workflow):init(store)
    with store.db:store.db.execute("UPDATE task_definitions SET state='cancelled' WHERE message_id='dev-local-nl-preview-20261102'")
    payload={'message_id':'dev-local-nl-preview-20261102-v2','actor':settings.users[0],'chat_id':binding['chat_id'],
             'text':text,'origin':'codex_authorized_local_nl_preview'}
    context=resolve_nl_input(store,payload);context['mode']='mock'
    def inspect_response(response):
        response.read()
        try:
            reply=json.loads(response.json()['message']['content'])
            names={f['field_id']:f['field_name'] for f in fields}
            conditions=reply.get('changes',{}).get('conditions',[])
            print(json.dumps({'model_result_labels':[f.get('label') for f in reply.get('changes',{}).get('result_fields',[])],'model_filter_proposal':[{'field':c.get('field_name',names.get(c.get('field_id'),'unknown')),'operator':c.get('operator'),'value':c.get('value')} for c in conditions]},ensure_ascii=False),flush=True)
        except (ValueError,KeyError,TypeError):pass
    client=httpx.Client(timeout=httpx.Timeout(180,connect=3),trust_env=False,event_hooks={'response':[inspect_response]})
    row=propose_nl_task(store,LocalPlanner(settings.nlp_model,client=client),payload,context,fields)
    definition=json.loads(row['definition'])
    assert {f['label'] for f in definition['result_fields']}=={'回访出席意向','人工联系请求','回访摘要'}, 'Preview does not preserve requested output fields'
    card=definition_card(row)
    card['elements'].insert(0,{'tag':'div','text':{'tag':'plain_text','content':'本地 Qwen 解析验证：仅生成待确认方案，未外呼、未回填。'}})
    message_id=gateway.send_card(payload['chat_id'],payload['message_id'],card,kind='local-qwen-preview')
    definition=json.loads(row['definition'])
    report={'field_metadata_read':len(fields),'preview_sent':bool(message_id),'task_state':row['state'],
            'mapped_output_fields':sum(bool(f['target_field_id']) for f in definition['result_fields']),
            'output_field_count':len(definition['result_fields']),'mode':'mock','record_rows_sent_to_model':0,'real_calls':0,'record_writes':0}
    out=Path('var/feishu-nl-preview-verification.json');out.write_text(json.dumps(report,ensure_ascii=False,indent=2));out.chmod(0o600)
    print(json.dumps(report,ensure_ascii=False),flush=True)
    store.close()


if __name__=='__main__':main()
