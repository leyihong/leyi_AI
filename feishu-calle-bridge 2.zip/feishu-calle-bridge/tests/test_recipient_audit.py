from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
import httpx
from feishu_calle.recipient_scope import recipient_edit,check_recipient_selection,retain_recipient_selection
from feishu_calle.preview import Clarification,init_previews,save_preview
from feishu_calle.store import Store
from feishu_calle.jobs import init_jobs
from feishu_calle.definitions import init_definitions,save_definition
from feishu_calle.execution import init_execution
from feishu_calle.nl_workflow import init_nl_workflow,propose_nl_task,resolve_nl_input
from feishu_calle.audit import record_audit,read_audit
from feishu_calle.natural_language import LocalPlanner,ModelClarification
from feishu_calle.conversation import task_code


FIELDS=json.loads(Path('fixtures/natural-language/fields.json').read_text())
FIELDS.append({'field_name':'测试记录编号','field_id':'label','type':1,'options':[]})
OLD={'revision':2,'purpose':'确认是否参加活动','mode':'mock','context_fields':[],
     'disclosure':'不发送额外背景','conditions':[['出席意向','=','待定']],
     'condition_bindings':[{'field_id':'fld_intent','field_name':'出席意向','operator':'=','value':'待定'}],
     'exclude_duplicates':True,'result_fields':[{'key':'result_1','label':'回访出席意向','type':'enum',
       'options':['参加','不参加','待定','不明'],'unknown_value':'不明','target_field_id':'fld_visit_intent'}]}


class RecipientAuditTests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory();self.store=Store(Path(self.folder.name)/'state.sqlite3')
        for init in (init_jobs,init_definitions,init_previews,init_execution,init_nl_workflow):init(self.store)
        self.payload={'message_id':'original','actor':'operator','chat_id':'group',
                      'text':'联系待定的人确认参会 https://example.feishu.cn/base/BASE1?table=tbl1&view=vew1'}
        self.old=save_definition(self.store,self.payload,deepcopy(OLD))

    def tearDown(self):self.store.close();self.folder.cleanup()

    def test_named_recipient_preserves_business_fields_and_does_not_call_model_or_execute(self):
        save_preview(self.store,{**self.payload,'message_id':'roster'}, {'definition_token':self.old['token']})
        payload={**self.payload,'message_id':'select','text':'先给测试甲拨号'}
        planner=Mock()
        row=propose_nl_task(self.store,planner,payload,resolve_nl_input(self.store,payload),FIELDS)
        d=json.loads(row['definition'])
        self.assertEqual(d['conditions'],OLD['conditions']+[['联系人','=','测试甲']])
        self.assertEqual(d['purpose'],OLD['purpose'])
        self.assertEqual(d['result_fields'],OLD['result_fields'])
        self.assertEqual(d['revision'],3)
        planner.propose.assert_not_called()
        self.assertEqual(self.store.db.execute('SELECT state FROM roster_previews').fetchone()[0],'invalidated')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],0)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM execution_batches').fetchone()[0],0)
        stages=[r['stage'] for r in read_audit(self.store,task_code(payload))]
        self.assertEqual(stages,['input','recipient.selection','proposal.saved'])

    def test_replacing_a_recipient_keeps_original_business_scope(self):
        first=recipient_edit('先给测试甲拨号',OLD,FIELDS)
        second=recipient_edit('只联系测试乙',first,FIELDS)
        self.assertEqual(second['conditions'],[('出席意向','=','待定'),('联系人','=','测试乙')])
        self.assertEqual(len(second['condition_bindings']),2)
        self.assertEqual(OLD['conditions'],[['出席意向','=','待定']])

    def test_later_model_filter_edit_cannot_silently_drop_named_recipient(self):
        d=recipient_edit('对象：测试甲',OLD,FIELDS)
        d['conditions']=[('出席意向','=','参加')];d['condition_bindings']=[]
        with self.assertRaises(Clarification):check_recipient_selection([{'fields':{'联系人':'测试乙','出席意向':'参加'}}],d)
        retain_recipient_selection(d,FIELDS)
        self.assertIn(('联系人','=','测试甲'),d['conditions'])
        self.assertEqual(d['condition_bindings'][0]['field_name'],'联系人')

    def test_only_unique_match_within_original_filters_can_generate_roster(self):
        d=recipient_edit('先给测试甲拨号',OLD,FIELDS)
        record={'fields':{'联系人':'测试甲','出席意向':'待定'}}
        check_recipient_selection([record],d)
        for rows in ([],[record,deepcopy(record)],[{'fields':{'联系人':'测试甲','出席意向':'参加'}}]):
            with self.subTest(rows=rows),self.assertRaises(Clarification):check_recipient_selection(rows,d)
        with self.assertRaises(Clarification):recipient_edit('先给测试甲和测试乙拨号',OLD,FIELDS)

    def test_record_label_selection_and_unknown_edit_are_not_result_edits(self):
        d=recipient_edit('只给T001打电话',OLD,FIELDS)
        self.assertEqual(d['recipient_selection']['field_name'],'测试记录编号')
        self.assertEqual(d['recipient_selection']['value'],'T001')
        client=Mock()
        with self.assertRaises(ModelClarification):LocalPlanner(client=client).propose('先处理一下',FIELDS,previous=OLD)
        client.post.assert_not_called()

    def test_visible_labels_scope_changes_and_recipient_stays_outside_model(self):
        from feishu_calle.edit_commands import normalize_edit_request
        from feishu_calle.natural_language import allowed_edit_keys
        for text,keys in [('目的：确认是否需要资料',{'purpose'}),
                          ('筛选：出席意向=参加',{'conditions'}),
                          ('结果：回访出席意向=参加/不参加/不明',{'result_fields'})]:
            self.assertEqual(allowed_edit_keys(normalize_edit_request(text),OLD),keys)
        d=recipient_edit('任务 abcdef12 对象：测试甲',OLD,FIELDS)
        self.assertEqual(d['recipient_selection']['value'],'测试甲')
        self.assertEqual(d['result_fields'],OLD['result_fields'])

    def test_trace_records_inputs_model_patch_validation_and_diff_without_phone_or_secret(self):
        payload={**self.payload,'message_id':'model-edit','text':'结果字段回访出席意向改为参加/不参加/不明，号码+12025550101'}
        reply={'action':'propose','clarification':'','changes':{'result_fields':[{'label':'回访出席意向','type':'enum','options':['参加','不参加','不明']}]}}
        client=httpx.Client(transport=httpx.MockTransport(lambda request:httpx.Response(200,json={
            'done':True,'message':{'content':json.dumps(reply)}})))
        row=propose_nl_task(self.store,LocalPlanner(client=client),payload,resolve_nl_input(self.store,payload),FIELDS)
        code=task_code(payload);traces=read_audit(self.store,code)
        self.assertEqual([r['stage'] for r in traces],['input','model.request','model.response','validation.passed','proposal.saved'])
        self.assertNotIn('+12025550101',json.dumps(traces))
        saved=json.loads(row['definition']);self.assertEqual(set(saved['review_diff']),{'result_fields'})
        self.assertEqual(saved['trace_code'],code)
        record_audit(self.store,payload,'test',{'api_key':'test-secret','phone':'+12025550101'})
        self.assertNotIn('test-secret',json.dumps(read_audit(self.store,code)))
