import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from feishu_calle.store import Store
from feishu_calle.jobs import init_jobs
from feishu_calle.definitions import init_definitions,save_definition,act_on_definition,definition_card
from feishu_calle.output_columns import plan_output_columns,ensure_output_columns
from feishu_calle.preview import Clarification
from feishu_calle.resources import BaseRef
from feishu_calle.inspection_runtime import validate_resource


class ColumnTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.store=Store(Path(self.tmp.name)/'db.sqlite3')
        init_jobs(self.store);init_definitions(self.store)
        self.fields=[{'field_name':'已有结果','field_id':'old','type':1,'options':[]}]
        self.definition={'revision':1,'purpose':'确认情况','proposal_source':'test','disclosure':'test','conditions':[],
            'exclude_duplicates':True,'result_fields':[{'key':'result_1','label':'已有结果','type':'enum','options':['是','不明'],'target_field_id':'old'},
            {'key':'result_2','label':'新结果','type':'enum','options':['完成','不明'],'target_field_id':None}]}
        plan_output_columns(self.definition,self.fields)
        self.draft=save_definition(self.store,{'message_id':'one','actor':'owner','chat_id':'group'},self.definition)
        self.ref=BaseRef('example.feishu.cn','BASE1','tbl1','vew1');self.gateway=Mock()
        self.gateway.fields.side_effect=lambda ref:list(self.fields)
        def create(ref,name,kind,options,operation):
            self.fields.append({'field_name':name,'field_id':'created','type':kind,'options':options})
        self.gateway.create_field.side_effect=create

    def tearDown(self):self.store.close();self.tmp.cleanup()

    def confirm(self):act_on_definition(self.store,self.draft['token'],'owner','group','confirm')

    def test_preview_then_confirm_creates_only_missing_column_once_and_binds_id(self):
        self.assertIn('确认后新建单选列',json.dumps(definition_card(self.draft),ensure_ascii=False))
        with self.assertRaises(Clarification):ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        self.gateway.create_field.assert_not_called();self.confirm()
        definition,fields=ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        self.assertEqual(definition['result_fields'][1]['target_field_id'],'created')
        ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        self.gateway.create_field.assert_called_once()
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],0)

    def test_literal_new_field_and_sdk_builder_keep_requested_name_and_type(self):
        from feishu_calle.natural_language import explicit_result_instructions
        from feishu_calle.feishu import FeishuGateway
        from types import SimpleNamespace
        results=explicit_result_instructions('结果：配送确认=已到/未到/不明；配送备注=文本。',[])
        self.assertEqual([r['label'] for r in results],['配送确认','配送备注'])
        client=Mock();response=Mock();response.success.return_value=True;response.data=SimpleNamespace(field=SimpleNamespace(field_id='new'))
        client.bitable.v1.app_table_field.create.return_value=response
        FeishuGateway(client).create_field(self.ref,'配送确认',3,['已到','未到','不明'],'fixed-op')
        request=client.bitable.v1.app_table_field.create.call_args.args[0]
        self.assertEqual(request.request_body.field_name,'配送确认')
        self.assertEqual(request.request_body.type,3)
        self.assertEqual([o.name for o in request.request_body.property.options],['已到','未到','不明'])

    def test_timeout_reconciles_visible_column_without_creating_duplicate(self):
        self.confirm()
        def timeout(*args):
            self.fields.append({'field_name':'新结果','field_id':'created','type':3,'options':['完成','不明']})
            raise TimeoutError()
        self.gateway.create_field.side_effect=timeout
        with self.assertRaises(Clarification):ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        d,_=ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        self.assertEqual(d['result_fields'][1]['target_field_id'],'created');self.gateway.create_field.assert_called_once()

    def test_timeout_without_visible_column_stops_and_does_not_retry(self):
        self.confirm();self.gateway.create_field.side_effect=TimeoutError()
        for _ in range(2):
            with self.assertRaises(Clarification):ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        self.gateway.create_field.assert_called_once()

    def test_incompatible_and_replaced_existing_columns_never_get_overwritten(self):
        self.confirm();self.fields[0].update(type=3,options=['别的选项'])
        with self.assertRaises(Clarification):ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        self.gateway.create_field.assert_not_called()
        self.fields[0].update(type=1,field_id='replaced')
        with self.assertRaises(Clarification):ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        self.gateway.create_field.assert_not_called()

    def test_root_link_only_inherits_unique_exact_group_binding(self):
        bindings={('group','wiki:node123','tbl1')};views={('group','wiki:node123','tbl1'):'vew1'}
        payload={'chat_id':'group','text':'https://example.feishu.cn/wiki/node123?from=from_copylink'}
        ref=validate_resource(payload,bindings,views);self.assertEqual((ref.table_id,ref.view_id),('tbl1','vew1'))
        with self.assertRaises(Clarification):validate_resource({**payload,'chat_id':'other'},bindings,views)
        with self.assertRaises(Clarification):validate_resource(payload,bindings|{('group','wiki:node123','tbl2')},views)

    def test_new_column_flows_through_roster_execution_and_original_record_writeback(self):
        from copy import deepcopy
        from feishu_calle.config import Settings
        from feishu_calle.execution import init_execution,attach_execution,approve_execution,ExecutionWorker
        from feishu_calle.preview import init_previews,build_roster,save_preview
        init_execution(self.store);init_previews(self.store)
        d=json.loads(self.draft['definition']);d['context_fields']=[];d['questions']=[]
        for f in d['result_fields']:f['unknown_value']='不明'
        with self.store.db:self.store.db.execute('UPDATE task_definitions SET definition=? WHERE token=?',(json.dumps(d),self.draft['token']))
        self.confirm();d,fields=ensure_output_columns(self.store,self.gateway,self.ref,self.draft['token'])
        record={'record_id':'synthetic','fields':{'联系人':'虚构测试','电话号码':'+12025550101','允许电话联系':'是','禁止联系':'否','授权来源':'虚构测试授权','数据模式':'SYNTHETIC_NO_CALL'}}
        settings=Settings.from_env({'BRIDGE_DATABASE':str(Path(self.tmp.name)/'db.sqlite3'),'BRIDGE_WRITEBACK':'true'})
        snapshot=build_roster([record],[]);snapshot['definition_token']=self.draft['token']
        attach_execution(snapshot,d,self.ref,[record],fields,settings)
        preview=save_preview(self.store,{'message_id':'roster','actor':'owner','chat_id':'group'},snapshot)
        batch=approve_execution(self.store,preview['token'],'owner','group','execute_mock',settings)
        self.gateway.record.side_effect=lambda *a:deepcopy(record)
        self.gateway.write_fields.side_effect=lambda ref,rid,values,op:record['fields'].update(values)
        clock=[0];worker=ExecutionWorker(self.store,self.gateway,settings,clock=lambda:clock[0])
        for _ in range(10):worker.tick();clock[0]+=5
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_batches WHERE id=?',(batch,)).fetchone()[0],'finished')
        self.assertEqual(record['fields']['新结果'],'不明')
        self.assertEqual(record['fields']['电话号码'],'+12025550101')
        self.gateway.create_field.assert_called_once();self.gateway.write_fields.assert_called_once()
