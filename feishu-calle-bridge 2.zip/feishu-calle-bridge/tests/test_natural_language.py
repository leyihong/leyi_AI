from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
import httpx
from feishu_calle.natural_language import LocalPlanner, validate_proposal, ModelClarification, PlannerUnavailable
from feishu_calle.nl_workflow import init_nl_workflow, resolve_nl_input, propose_nl_task
from feishu_calle.preview import Clarification,init_previews,save_preview
from feishu_calle.definitions import init_definitions,act_on_definition
from feishu_calle.execution import init_execution
from feishu_calle.jobs import init_jobs
from feishu_calle.store import Store
from feishu_calle.conversation import task_code

FIELDS=json.loads(Path('fixtures/natural-language/fields.json').read_text())
CREATE={'purpose':'确认能否参加活动','conditions':[{'field_id':'fld_intent','operator':'=','value':'待定'}],
        'exclude_duplicates':True,'result_fields':[{'label':'回访出席意向','type':'enum','options':['参加','不参加','未知']},
                                                  {'label':'回访摘要','type':'text','options':[]}]}


def proposal(changes):return {'action':'propose','clarification':'','changes':deepcopy(changes)}


def baseline():return validate_proposal(proposal(CREATE),FIELDS,user_text='联系待定的人')


class NaturalLanguageTests(unittest.TestCase):
    def test_source_column_proposal_is_corrected_once_without_weakening_validation(self):
        from feishu_calle.natural_language import ProposalInvalid
        bad=proposal({**CREATE,'result_fields':[{'label':'联系人','type':'text','options':[]}]})
        seen=[]
        def handle(request):
            seen.append(json.loads(request.content))
            reply=bad if len(seen)==1 else proposal({**CREATE,'purpose':'不允许的扩大目标','conditions':[]})
            return httpx.Response(200,json={'done':True,'message':{'content':json.dumps(reply)}})
        planner=LocalPlanner(client=httpx.Client(transport=httpx.MockTransport(handle)))
        result=planner.propose('筛选：出席意向=待定；无重复号码的联系人。目的：确认是否参加活动。',FIELDS)
        self.assertEqual(len(seen),2)
        self.assertTrue(result['exclude_duplicates'])
        self.assertEqual(result['purpose'],CREATE['purpose'])
        self.assertEqual(result['conditions'],[('出席意向','=','待定')])
        self.assertNotIn('联系人',{f['label'] for f in result['result_fields']})
        self.assertIn('上一个模型方案被程序拒绝',seen[1]['messages'][-1]['content'])
        self.assertEqual(seen[0]['format'],seen[1]['format'])
        calls=[]
        def always_bad(request):
            calls.append(request)
            return httpx.Response(200,json={'done':True,'message':{'content':json.dumps(bad)}})
        planner=LocalPlanner(client=httpx.Client(transport=httpx.MockTransport(always_bad)))
        with self.assertRaises(ProposalInvalid):planner.propose('联系待定的人确认是否参加活动',FIELDS)
        self.assertEqual(len(calls),2)

    def test_different_scenes_have_different_business_schemas(self):
        attendance=baseline()
        supplier=validate_proposal(proposal({'purpose':'确认发货进度','conditions':[{'field_id':'fld_shipping','operator':'=','value':'待发货'}],
              'result_fields':[{'label':'发货确认','type':'enum','options':['已发货','未发货','不明']},
                               {'label':'预计到货时间','type':'text','options':[]}]}),FIELDS)
        self.assertNotEqual(attendance['result_fields'],supplier['result_fields'])
        self.assertEqual(supplier['result_fields'][0]['target_field_id'],'fld_dispatch_result')

    def test_patches_preserve_omitted_constraints_and_do_not_generate_script(self):
        old=baseline();copy=deepcopy(old)
        new=validate_proposal(proposal({'purpose':'询问是否需要资料'}),FIELDS,previous=old,user_text='改问是否需要资料')
        self.assertEqual(old,copy)
        self.assertEqual(new['conditions'],old['conditions'])
        self.assertEqual(new['result_fields'],old['result_fields'])
        self.assertEqual(new['revision'],old['revision']+1)
        self.assertEqual(new['questions'],[])
        with self.assertRaises(Clarification):validate_proposal(proposal({'script':'say this'}),FIELDS,previous=old)

    def test_bad_fields_operators_values_and_system_edits_are_rejected(self):
        for bad in [{'mode':'live'},{'phone':'+12025550101'},{'conditions':[{'field_id':'fake','operator':'=','value':'x'}]},
                    {'conditions':[{'field_id':'fld_intent','operator':'OR','value':'待定'}]},
                    {'conditions':[{'field_id':'fld_intent','operator':'=','value':'不存在'}]},
                    {'result_fields':[{'label':'电话号码','type':'text','options':[]}]},
                    {'result_fields':[{'label':'出席意向','type':'text','options':[]}]}]:
            with self.subTest(bad=bad),self.assertRaises(Clarification):validate_proposal(proposal(bad),FIELDS,previous=baseline())

    def test_empty_filter_requires_explicit_all_contacts_not_all_fields(self):
        with self.assertRaises(Clarification):validate_proposal(proposal({'conditions':[]}),FIELDS,previous=baseline(),user_text='所有结果字段保持')
        revised=validate_proposal(proposal({'conditions':[]}),FIELDS,previous=baseline(),user_text='联系整个视图内的合格联系人')
        self.assertEqual(revised['conditions'],[])

    def test_partial_result_patch_merges_and_explicit_deletion_requires_named_field(self):
        old=baseline()
        patch={'result_fields':[{'label':'回访出席意向','type':'enum','options':['参加','不参加','不明']}]}
        new=validate_proposal(proposal(patch),FIELDS,previous=old,user_text='回访出席意向里不要待定')
        self.assertEqual(len(new['result_fields']),2)
        self.assertEqual(new['result_fields'][1],old['result_fields'][1])
        with self.assertRaises(Clarification):validate_proposal(proposal({'remove_result_fields':['回访摘要']}),FIELDS,previous=old,user_text='不要待定')
        reduced=validate_proposal(proposal({'remove_result_fields':['回访摘要']}),FIELDS,previous=old,user_text='删除回访摘要')
        self.assertEqual(len(reduced['result_fields']),1)

    def test_local_transport_has_no_tools_credentials_or_contact_records(self):
        seen=[]
        def handle(request):
            seen.append(request)
            return httpx.Response(200,json={'done':True,'done_reason':'stop','message':{'content':json.dumps(proposal(CREATE),ensure_ascii=False)}})
        planner=LocalPlanner(client=httpx.Client(transport=httpx.MockTransport(handle)))
        planner.propose('联系待定的人确认是否参加，号码+12025550101，https://example.feishu.cn/base/PRIVATE?table=tbl1',FIELDS)
        request=seen[0];body=json.loads(request.content)
        self.assertEqual(str(request.url),'http://127.0.0.1:11434/api/chat')
        self.assertNotIn('+12025550101',request.content.decode())
        self.assertNotIn('/base/PRIVATE',request.content.decode())
        self.assertNotIn('Authorization',request.headers)
        self.assertNotIn('tools',body)
        self.assertFalse(body['think'])
        with self.assertRaises(ValueError):LocalPlanner('qwen3:cloud')

    def test_edit_schema_does_not_allow_goal_changes_for_a_filter_only_request(self):
        from feishu_calle.natural_language import allowed_edit_keys
        self.assertEqual(allowed_edit_keys('名单条件改成出席意向为参加，活动名称和其他设置保持不变。',baseline()),{'conditions'})
        self.assertEqual(allowed_edit_keys('回访出席意向里不要待定了，其他任务目的和名单条件不要改。',baseline()),{'result_fields'})
        def handle(request):
            return httpx.Response(200,json={'done':True,'message':{'content':json.dumps(proposal({'purpose':'accidental new goal'}))}})
        planner=LocalPlanner(client=httpx.Client(transport=httpx.MockTransport(handle)))
        with self.assertRaises(Clarification):planner.propose('名单条件改为出席意向为参加，其他设置保持不变',FIELDS,previous=baseline())

    def test_explicit_enums_override_inferred_storage_type_and_dedup_is_preserved(self):
        from feishu_calle.natural_language import explicit_enum_instructions
        text='联系订单状态为已收货的人，询问是否需要人工协助。人工联系请求记录需要、不需要、不明，以及回访摘要。同一电话只留一个。'
        self.assertEqual(explicit_enum_instructions(text,FIELDS)['人工联系请求'],['需要','不需要','不明'])
        reply=proposal({'purpose':'询问是否需要协助','conditions':[{'field_id':'fld_shipping','operator':'=','value':'已收货'}],
                        'result_fields':[{'label':'人工联系请求','type':'text','options':[]},{'label':'回访摘要','type':'text','options':[]}]})
        planner=LocalPlanner(client=httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(200,json={'done':True,'message':{'content':json.dumps(reply)}}))))
        definition=planner.propose(text,FIELDS)
        self.assertEqual(definition['result_fields'][0]['type'],'enum')
        self.assertTrue(definition['exclude_duplicates'])

    def test_result_label_does_not_match_a_shorter_source_column_name(self):
        from feishu_calle.natural_language import explicit_enum_instructions
        hints=explicit_enum_instructions('出席意向为待定，结果用回访出席意向记录参加、不参加、待定、不明，再用回访摘要记录简短说明。',FIELDS)
        self.assertIn('回访出席意向',hints)
        self.assertNotIn('出席意向',hints)
        from feishu_calle.natural_language import explicit_result_instructions
        typed=explicit_result_instructions('结果用回访出席意向记录文本，回访摘要记录文本',FIELDS)
        self.assertEqual({f['label'] for f in typed},{'回访出席意向','回访摘要'})
        self.assertEqual(explicit_result_instructions('再用回访摘要记录简短说明',FIELDS),[{'label':'回访摘要','type':'text','options':[]}])

    def test_multiple_result_columns_in_one_sentence_keep_their_separate_enums(self):
        from feishu_calle.natural_language import explicit_result_instructions
        text='回访出席意向记录参加、不参加、待定、不明，人工联系请求记录需要、不需要、不明，回访摘要记录文本。'
        results=explicit_result_instructions(text,FIELDS)
        self.assertEqual({f['label'] for f in results},{'回访出席意向','人工联系请求','回访摘要'})
        self.assertEqual(next(f for f in results if f['label']=='回访出席意向')['options'],['参加','不参加','待定','不明'])
        self.assertEqual(next(f for f in results if f['label']=='人工联系请求')['options'],['需要','不需要','不明'])

    def test_unsupported_or_and_missing_objective_ask_before_inference(self):
        client=Mock();planner=LocalPlanner(client=client)
        for text in ['帮我给表里的人打电话','联系订单状态为已发货或者已收货的人，询问收货情况']:
            with self.subTest(text=text),self.assertRaises(ModelClarification):planner.propose(text,FIELDS)
        client.post.assert_not_called()

    def test_clarification_question_does_not_invent_a_goal_and_latest_answer_can_resolve_or(self):
        from feishu_calle.natural_language import input_preflight
        with self.assertRaises(ModelClarification):input_preflight('给他们打电话\n待澄清问题：具体希望确认什么？\n用户补充：好的',FIELDS,None)
        original='联系订单状态为已发货或者已收货的人，询问收货情况'
        input_preflight(original+'\n待澄清问题：请选择一个值\n用户补充：那就只联系已发货的人',FIELDS,None)
        with self.assertRaises(ModelClarification):input_preflight(original+'\n用户补充：好的',FIELDS,None)

    def test_mutually_exclusive_equalities_are_not_treated_as_or(self):
        changes={'conditions':[{'field_id':'fld_shipping','operator':'=','value':'已发货'},{'field_id':'fld_shipping','operator':'=','value':'已收货'}]}
        with self.assertRaises(ModelClarification):validate_proposal(proposal(changes),FIELDS,previous=baseline())

    def test_incomplete_model_response_never_mutates_task(self):
        for data in [{'done':True,'done_reason':'length','message':{'content':'{}'}},
                     {'done':False,'message':{'content':json.dumps(proposal(CREATE))}},
                     {'done':True,'message':{'content':'not JSON'}}]:
            planner=LocalPlanner(client=httpx.Client(transport=httpx.MockTransport(lambda r:httpx.Response(200,json=data))))
            with self.subTest(data=data),self.assertRaises(Clarification):planner.propose('确认是否参加',FIELDS)


class NaturalWorkflowTests(unittest.TestCase):
    def test_expired_drafts_do_not_make_current_followup_ambiguous(self):
        first=self.create()
        with self.store.db:self.store.db.execute('UPDATE task_definitions SET expires_at=0 WHERE token=?',(first['token'],))
        current_payload={**self.payload,'message_id':'current'}
        current=propose_nl_task(self.store,self.planner,current_payload,resolve_nl_input(self.store,current_payload),FIELDS)
        edit={**self.payload,'message_id':'edit','text':'建议结果字段需要更改为回访出席意向：参加/不参加/待定/不明'}
        context=resolve_nl_input(self.store,edit)
        self.assertEqual(context['previous']['token'],current['token'])
        with self.assertRaises(Clarification):
            resolve_nl_input(self.store,{**edit,'text':'任务 '+task_code(first)+' 修改结果字段'})

    def test_task_expiring_during_inference_cannot_be_revived_by_edit(self):
        first=self.create()
        edit={**self.payload,'message_id':'edit','text':'把目的改成确认是否需要资料'}
        context=resolve_nl_input(self.store,edit)
        def expired(*args,**kwargs):
            with self.store.db:self.store.db.execute('UPDATE task_definitions SET expires_at=0 WHERE token=?',(first['token'],))
            return baseline()
        self.planner.propose.side_effect=expired
        with self.assertRaises(Clarification):propose_nl_task(self.store,self.planner,edit,context,FIELDS)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM task_definitions').fetchone()[0],1)

    def setUp(self):
        self.folder=tempfile.TemporaryDirectory();self.store=Store(Path(self.folder.name)/'state.sqlite3')
        init_jobs(self.store);init_definitions(self.store);init_previews(self.store);init_execution(self.store);init_nl_workflow(self.store)
        self.payload={'message_id':'new','actor':'ou1','chat_id':'oc1','text':'联系待定的人确认参会 https://example.feishu.cn/base/BASE1?table=tbl1&view=vew1'}
        self.planner=Mock();self.planner.propose.return_value=baseline()

    def tearDown(self):self.store.close();self.folder.cleanup()

    def create(self):return propose_nl_task(self.store,self.planner,self.payload,resolve_nl_input(self.store,self.payload),FIELDS)

    def test_new_task_and_replay_are_review_only(self):
        first=self.create();second=self.create()
        self.assertEqual(first['token'],second['token']);self.planner.propose.assert_called_once()
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],0)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM execution_batches').fetchone()[0],0)

    def test_clarification_reply_inherits_original_link_and_request(self):
        self.planner.propose.side_effect=ModelClarification('只联系待定的人吗？')
        with self.assertRaises(ModelClarification):self.create()
        reply={'message_id':'answer','actor':'ou1','chat_id':'oc1','text':'是，只联系待定的人'}
        context=resolve_nl_input(self.store,reply)
        self.assertIn('https://',context['source']['text'])
        self.assertIn('只联系待定的人吗',context['request'])
        self.planner.propose.side_effect=None
        draft=propose_nl_task(self.store,self.planner,reply,context,FIELDS)
        self.assertEqual(draft['state'],'pending')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM nl_clarifications').fetchone()[0],0)

    def test_confirmed_but_unexecuted_revision_invalidates_old_roster_and_buttons(self):
        first=self.create();act_on_definition(self.store,first['token'],'ou1','oc1','confirm')
        save_preview(self.store,{'message_id':'old-roster','actor':'ou1','chat_id':'oc1'},{'definition_token':first['token']})
        reply={'message_id':'edit','actor':'ou1','chat_id':'oc1','text':'目的改成询问是否需要资料'}
        changed=validate_proposal(proposal({'purpose':'询问是否需要资料'}),FIELDS,previous=baseline())
        self.planner.propose.return_value=changed
        row=propose_nl_task(self.store,self.planner,reply,resolve_nl_input(self.store,reply),FIELDS)
        self.assertEqual(json.loads(row['definition'])['purpose'],'询问是否需要资料')
        self.assertEqual(self.store.db.execute('SELECT state FROM roster_previews').fetchone()[0],'invalidated')
        with self.assertRaises(Clarification):act_on_definition(self.store,first['token'],'ou1','oc1','confirm')

    def test_execution_started_during_inference_prevents_stale_revision(self):
        first=self.create()
        reply={'message_id':'edit','actor':'ou1','chat_id':'oc1','text':'修改目的'}
        context=resolve_nl_input(self.store,reply)
        # A concurrent valid execution binds a manifest to the original definition.
        preview=save_preview(self.store,{'message_id':'roster','actor':'ou1','chat_id':'oc1'},{'definition_token':first['token']})
        with self.store.db:self.store.db.execute('INSERT INTO execution_batches VALUES (?,?,?,?,?,?,?,?,?,?)',
            ('batch-test',preview['token'],'ou1','oc1','mock','running','{}',9999999999,None,0))
        with self.assertRaises(Clarification):propose_nl_task(self.store,self.planner,reply,context,FIELDS)
        self.assertEqual(self.store.db.execute('SELECT state FROM task_definitions WHERE token=?',(first['token'],)).fetchone()[0],'pending')

    def test_multiple_tasks_require_target_and_other_actor_cannot_inherit(self):
        first=self.create();other={**self.payload,'message_id':'second'}
        propose_nl_task(self.store,self.planner,other,resolve_nl_input(self.store,other),FIELDS)
        reply={**self.payload,'message_id':'edit','text':'改一下结果'}
        with self.assertRaises(Clarification):resolve_nl_input(self.store,reply)
        selected=resolve_nl_input(self.store,{**reply,'text':'任务 '+task_code(first)+' 改一下结果'})
        self.assertEqual(selected['previous']['token'],first['token'])
        with self.assertRaises(Clarification):resolve_nl_input(self.store,{**reply,'actor':'outsider'})
