import tempfile
import unittest
from pathlib import Path
from feishu_calle.store import Store, SubmissionConflict
from feishu_calle.config import Settings


class SubmissionRecoveryTests(unittest.TestCase):
    def test_restart_preserves_key_and_unknown_submission_cannot_be_claimed_again(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "state.sqlite3"
            store = Store(path)
            first = store.reserve("intent-1", {"task": "Confirm attendance"})
            self.assertTrue(store.claim_submission("intent-1"))
            store.close()
            store = Store(path)
            replay = store.reserve("intent-1", {"task": "Confirm attendance"})
            self.assertEqual(first["idempotency_key"], replay["idempotency_key"])
            self.assertFalse(store.claim_submission("intent-1"))
            self.assertEqual(store.recovery_actions()[0]["action"], "reconcile_unknown_submission")
            store.accepted("intent-1", "provider-resource-1")
            self.assertEqual(store.recovery_actions()[0]["action"], "read_original")
            with self.assertRaises(SubmissionConflict):
                store.reserve("intent-1", {"task": "A different task"})
            store.close()

    def test_configuration_does_not_disclose_secret_values(self):
        settings = Settings.from_env({"CALLE_API_KEY": "private-key", "FEISHU_APP_SECRET": "private-secret"})
        self.assertEqual(settings.mode, "mock")
        self.assertNotIn("private-key", repr(settings))
        self.assertNotIn("private-secret", repr(settings))
        self.assertIn("FEISHU_APP_ID", settings.missing_live_settings())
