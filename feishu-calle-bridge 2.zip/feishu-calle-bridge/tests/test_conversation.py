import json
from pathlib import Path
import tempfile
import unittest
from feishu_calle.definitions import (init_definitions, propose_definition, save_definition,
                                     act_on_definition)
from feishu_calle.conversation import revise_pending_definition, confirm_from_text, task_code
from feishu_calle.jobs import init_jobs
from feishu_calle.store import Store
from feishu_calle.preview import Clarification


class ConversationTests(unittest.TestCase):
    def test_expired_draft_does_not_block_current_rule_edit_or_get_revived(self):
        with self.store.db:self.store.db.execute('UPDATE task_definitions SET expires_at=0 WHERE token=?',(self.old['token'],))
        with self.assertRaises(Clarification):self.edit('回访出席意向：参加/不参加/不明')
        current=save_definition(self.store,{**self.payload,'message_id':'current'},json.loads(self.old['definition']))
        updated=self.edit('回访出席意向：参加/不参加/不明')
        self.assertEqual(json.loads(updated['definition'])['revision'],2)
        self.assertEqual(self.store.db.execute('SELECT state FROM task_definitions WHERE token=?',(current['token'],)).fetchone()[0],'superseded')
        self.assertEqual(self.store.db.execute('SELECT state FROM task_definitions WHERE token=?',(self.old['token'],)).fetchone()[0],'pending')

    def setUp(self):
        self.folder=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.folder.name)/'state.sqlite3')
        init_jobs(self.store);init_definitions(self.store)
        self.text='筛选：出席意向=待定。目的：确认是否参加活动。\nhttps://example.feishu.cn/base/ABC?table=tbl1&view=vew1'
        fields=[{'field_name':'出席意向','field_id':'source','type':3},
                {'field_name':'回访出席意向','field_id':'output','type':1}]
        self.payload={'message_id':'original','actor':'ou1','chat_id':'oc1','text':self.text}
        self.old=save_definition(self.store,self.payload,propose_definition(self.text,fields))

    def tearDown(self):
        self.store.close();self.folder.cleanup()

    def edit(self,text,**kw):
        return revise_pending_definition(self.store,{**self.payload,'message_id':'edit','text':text,**kw})

    def test_bullet_edits_inherit_request_preserve_others_and_invalidate_old(self):
        row=self.edit('@_user_1\n• 外呼状态：待外呼/外呼中/已外呼/未接通\n• 回访出席意向：参加 / 不参加 / 待定 / 不明；匹配已有输出列\n• 人工联系请求：需要 / 不需要 / 不明；匹配已有输出列\n• 回访摘要：简短文本；匹配已有输出列\n• 外呼任务：outboundID')
        d=json.loads(row['definition']);previous=json.loads(self.old['definition'])
        self.assertEqual(d['revision'],2)
        self.assertEqual(d['purpose'],previous['purpose'])
        self.assertEqual(d['conditions'],previous['conditions'])
        self.assertEqual(d['result_fields'][0]['options'],['参加','不参加','待定','不明'])
        self.assertEqual(d['result_fields'][0]['unknown_value'],'不明')
        self.assertEqual(d['result_fields'][0]['target_field_id'],'output')
        self.assertIn('https://',json.loads(row['payload'])['text'])
        with self.assertRaises(Clarification):
            act_on_definition(self.store,self.old['token'],'ou1','oc1','confirm')
        act_on_definition(self.store,row['token'],'ou1','oc1','confirm')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM inspection_jobs').fetchone()[0],1)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],0)

    def test_edit_replay_returns_same_revision_and_preserves_unmentioned_fields(self):
        row=self.edit('回访出席意向：参加/不参加/不明')
        again=self.edit('回访出席意向：参加/不参加/不明')
        self.assertEqual(row['token'],again['token'])
        self.assertEqual(len(json.loads(row['definition'])['result_fields']),3)

    def test_invalid_or_other_actor_edit_does_not_invalidate_pending_task(self):
        for text,kw in [('回访出席意向：参加/不参加',{'actor':'outsider'}),
                        ('回访出席意向：参加/不参加',{'chat_id':'other'}),
                        ('电话号码：是/否',{}),('修改一下',{})]:
            with self.subTest(text=text,kw=kw),self.assertRaises(Clarification):
                self.edit(text,**kw)
        state=self.store.db.execute('SELECT state FROM task_definitions WHERE token=?',(self.old['token'],)).fetchone()[0]
        self.assertEqual(state,'pending')

    def test_text_confirmation_binds_code_actor_and_superseded_revision(self):
        old_code=task_code(self.old)
        revised=self.edit('回访出席意向：参加/不参加/不明')
        with self.assertRaises(Clarification):
            confirm_from_text(self.store,{**self.payload,'text':'确认定义 '+old_code})
        code=task_code(revised)
        with self.assertRaises(Clarification):
            confirm_from_text(self.store,{**self.payload,'actor':'outsider','text':'确认定义 '+code})
        for _ in range(2):
            result=confirm_from_text(self.store,{**self.payload,'message_id':'confirm-message','text':'@_user_1 确认定义 '+code})
            self.assertEqual(result['state'],'confirmed')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM inspection_jobs').fetchone()[0],1)

    def test_heading_before_bullets_does_not_turn_edit_into_new_task(self):
        from feishu_calle.definitions import definition_card
        revised=self.edit('@_user_1 修改结果字段\n•外呼状态：待外呼/外呼中/已外呼/未接通\n· 回访出席意向：参加/不参加/待定/不明；匹配已有输出列\n• 人工联系请求：需要/不需要/不明；匹配已有输出列\n• 回访摘要：简短文本；匹配已有输出列\n·外呼任务：outboundID')
        card=definition_card(revised)
        self.assertEqual(card['header']['title']['content'],'CALL-E：结果字段已更新（待确认）')
        self.assertEqual(json.loads(revised['definition'])['revision'],2)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM inspection_jobs').fetchone()[0],0)
