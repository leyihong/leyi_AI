import json
from pathlib import Path
import tempfile
import unittest
from feishu_calle.definitions import (propose_definition, init_definitions, save_definition,
                                     act_on_definition, approved_definition, definition_card)
from feishu_calle.preview import Clarification
from feishu_calle.jobs import init_jobs, next_job
from feishu_calle.store import Store

FIELDS = [{'field_name':'出席意向','field_id':'fld_source','type':3},
          {'field_name':'回访出席意向','field_id':'fld_output','type':3,'options':['参加','不参加','待定','拒绝回答','未知']}]
REQUEST = '筛选：出席意向=待定。目的：确认能否参加活动。'


class DefinitionTests(unittest.TestCase):
    def test_two_purposes_produce_different_reviewable_schemas(self):
        attendance = propose_definition(REQUEST, FIELDS)
        custom = propose_definition('筛选：出席意向=待定。目的：询问预计到货时间。结果：到货状态=已发货/未发货；预计日期=文本', FIELDS)
        self.assertEqual(attendance['result_fields'][0]['target_field_id'], 'fld_output')
        self.assertEqual(custom['result_fields'][0]['options'], ['已发货','未发货','未知'])
        self.assertEqual(custom['result_fields'][1]['type'], 'text')
        self.assertIsNone(custom['result_fields'][0]['target_field_id'])
        self.assertNotEqual(attendance['result_fields'], custom['result_fields'])
        self.assertEqual(attendance['mode'], 'preview_only')

    def test_malformed_or_source_field_outputs_require_clarification(self):
        for results in ['电话号码=文本', '字段=唯一', '重复=是/否；重复=文本',
                        'a=文本；b=文本；c=文本；d=文本；e=文本；f=文本']:
            with self.subTest(results=results), self.assertRaises(Clarification):
                propose_definition(REQUEST+'结果：'+results, FIELDS)
        with self.assertRaises(Clarification):
            propose_definition('筛选：出席意向=待定',FIELDS)

    def test_confirmation_atomically_queues_scan_once_and_survives_restart(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'state.sqlite3'
            store=Store(path);init_jobs(store);init_definitions(store)
            payload={'message_id':'om1','actor':'ou1','chat_id':'oc1','text':REQUEST}
            draft=save_definition(store,payload,propose_definition(REQUEST,FIELDS))
            self.assertIsNone(next_job(store))
            for actor,chat in [('outsider','oc1'),('ou1','other')]:
                with self.assertRaises(Clarification):
                    act_on_definition(store,draft['token'],actor,chat,'confirm')
            act_on_definition(store,draft['token'],'ou1','oc1','confirm')
            store.close()
            store=Store(path);init_jobs(store);init_definitions(store)
            act_on_definition(store,draft['token'],'ou1','oc1','confirm')
            self.assertEqual(store.db.execute('SELECT count(*) FROM inspection_jobs').fetchone()[0],1)
            queued=json.loads(next_job(store)['payload'])
            self.assertEqual(approved_definition(store,queued)['purpose'],'确认能否参加活动。')
            with self.assertRaises(Clarification):
                approved_definition(store,{**queued,'message_id':'other'})
            self.assertEqual(store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],0)
            with self.assertRaises(Clarification):
                act_on_definition(store,draft['token'],'ou1','oc1','cancel')
            store.close()

    def test_cancel_and_expiry_cannot_schedule_scan(self):
        with tempfile.TemporaryDirectory() as folder:
            store=Store(Path(folder)/'s.sqlite3');init_jobs(store);init_definitions(store)
            draft=save_definition(store,{'message_id':'om1','actor':'ou1','chat_id':'oc1'},propose_definition(REQUEST,FIELDS))
            card=json.dumps(definition_card(draft),ensure_ascii=False)
            self.assertIn('不拨号',card)
            act_on_definition(store,draft['token'],'ou1','oc1','cancel')
            with self.assertRaises(Clarification):
                act_on_definition(store,draft['token'],'ou1','oc1','confirm')
            with store.db:
                store.db.execute('UPDATE task_definitions SET expires_at=0')
            with self.assertRaises(Clarification):
                act_on_definition(store,draft['token'],'ou1','oc1','cancel')
            self.assertIsNone(next_job(store));store.close()
