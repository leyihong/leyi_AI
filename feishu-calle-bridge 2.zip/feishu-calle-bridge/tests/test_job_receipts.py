from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock
from feishu_calle.store import Store
from feishu_calle.jobs import init_jobs, enqueue_job, next_job, deliver_notice, queue_failure
from feishu_calle.feishu import FeishuGateway


class ReceiptTests(unittest.TestCase):
    def setUp(self):
        self.folder=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.folder.name)/'state.sqlite3')
        init_jobs(self.store)

    def tearDown(self):
        self.store.close()
        self.folder.cleanup()

    def test_receipt_precedes_work_and_event_replay_does_not_duplicate(self):
        payload={'message_id':'om1','chat_id':'oc1'}
        self.assertTrue(enqueue_job(self.store,payload))
        self.assertFalse(enqueue_job(self.store,payload))
        self.assertIsNone(next_job(self.store))
        gateway=Mock()
        self.assertTrue(deliver_notice(self.store,gateway))
        self.assertEqual(next_job(self.store)['message_id'],'om1')
        self.assertFalse(deliver_notice(self.store,gateway))
        gateway.reply_text.assert_called_once()

    def test_new_receipt_delivered_even_if_previous_table_job_is_running(self):
        gateway=Mock()
        enqueue_job(self.store,{'message_id':'om1'})
        deliver_notice(self.store,gateway)
        with self.store.db:
            self.store.db.execute("UPDATE inspection_jobs SET state='running' WHERE message_id='om1'")
        enqueue_job(self.store,{'message_id':'om2'})
        deliver_notice(self.store,gateway)
        self.assertEqual(gateway.reply_text.call_args.args[0],'om2')

    def test_delivery_failure_is_bounded_and_failure_notice_persistent(self):
        enqueue_job(self.store,{'message_id':'om1'})
        gateway=Mock()
        gateway.reply_text.side_effect=TimeoutError()
        for _ in range(3):
            with self.store.db:
                self.store.db.execute('UPDATE job_notices SET next_attempt=0')
            deliver_notice(self.store,gateway)
        self.assertEqual(next_job(self.store)['message_id'],'om1')
        self.assertEqual(self.store.db.execute('SELECT state FROM job_notices').fetchone()[0],'abandoned')
        queue_failure(self.store,'om1')
        queue_failure(self.store,'om1')
        self.assertEqual(self.store.db.execute("SELECT count(*) FROM job_notices WHERE kind='failure'").fetchone()[0],1)

    def test_receipt_and_preview_use_distinct_delivery_identifiers(self):
        client=Mock()
        client.im.v1.message.reply.return_value.success.return_value=True
        client.im.v1.message.create.return_value.success.return_value=True
        gateway=FeishuGateway(client)
        gateway.reply_text('om1','received','receipt')
        first=client.im.v1.message.reply.call_args.args[0].request_body.uuid
        gateway.reply_text('om1','received','receipt')
        self.assertEqual(first,client.im.v1.message.reply.call_args.args[0].request_body.uuid)
        gateway.send_card('oc1','om1',{'elements':[]})
        preview_id=client.im.v1.message.create.call_args.args[0].request_body.uuid
        self.assertNotEqual(first,preview_id)
        gateway.send_card('oc1','om1',{'elements':[]},kind='clarification')
        self.assertNotEqual(preview_id,client.im.v1.message.create.call_args.args[0].request_body.uuid)
