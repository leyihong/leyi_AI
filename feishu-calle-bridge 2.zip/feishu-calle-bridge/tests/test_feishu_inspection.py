import copy
import json
import unittest
from types import SimpleNamespace as NS
from unittest.mock import Mock
from feishu_calle.resources import parse_base_link, parse_resource_link, WikiRef
from feishu_calle.feishu import FeishuGateway, FeishuFailure
from feishu_calle.inspection_runtime import accepted_message, validate_resource
from feishu_calle.preview import Clarification

LINK = "https://example.feishu.cn/base/BASExyz?table=tbl123&view=vew456"


class ResourceTests(unittest.TestCase):
    def test_model_errors_are_not_presented_as_missing_user_information(self):
        from feishu_calle.inspection_runtime import task_issue_card
        from feishu_calle.natural_language import ProposalInvalid, ModelClarification, PlannerUnavailable
        for exc,title in [(ProposalInvalid('模型选错列'),'任务方案未通过检查'),
                          (ModelClarification('请选择范围'),'需要确认一处信息'),
                          (PlannerUnavailable('服务未就绪'),'任务解析服务暂不可用'),
                          (Clarification('链接不匹配'),'任务暂未生成')]:
            with self.subTest(title=title):
                card=task_issue_card(exc)
                self.assertEqual(card['header']['title']['content'],'CALL-E：'+title)
                self.assertEqual(card['elements'][0]['text']['content'],str(exc))

    def test_wiki_resolution_preserves_scope_and_requires_bitable(self):
        ref = parse_resource_link('https://example.feishu.cn/wiki/node123?table=tbl123&view=vew456')
        self.assertIsInstance(ref, WikiRef)
        client = Mock()
        response = Mock()
        response.success.return_value = True
        response.data = NS(node=NS(obj_type='bitable', obj_token='BASEtarget'))
        client.wiki.v2.space.get_node.return_value = response
        gateway = FeishuGateway(client)
        resolved = gateway.resolve_wiki(ref, 'BASEtarget')
        self.assertEqual((resolved.app_token, resolved.table_id, resolved.view_id), ('BASEtarget', 'tbl123', 'vew456'))
        with self.assertRaises(FeishuFailure):
            gateway.resolve_wiki(ref, 'BASEother')
        response.data.node.obj_type = 'docx'
        with self.assertRaises(FeishuFailure):
            gateway.resolve_wiki(ref)

    def test_parses_table_and_view_without_network(self):
        ref = parse_base_link(LINK)
        self.assertEqual((ref.app_token, ref.table_id, ref.view_id), ("BASExyz", "tbl123", "vew456"))

    def test_rejects_untrusted_or_ambiguous_resources(self):
        for link in ["http://example.feishu.cn/base/BASExyz?table=tbl123",
                     "https://example.feishu.cn.attacker.test/base/BASExyz?table=tbl123",
                     "https://user:password@example.feishu.cn/base/BASExyz?table=tbl123",
                     "https://example.feishu.cn:443/base/BASExyz?table=tbl123",
                     "https://example.feishu.cn/wiki/abc?table=tbl123",
                     LINK + "&table=tbl999", "https://example.feishu.cn/base/BASExyz"]:
            with self.subTest(link=link), self.assertRaises(ValueError):
                parse_base_link(link)

    def test_ingress_requires_approved_actor_bot_mention_and_resource_binding(self):
        payload = {"event": {"sender": {"sender_type": "user", "sender_id": {"open_id": "ou_operator"}},
            "message": {"message_id": "om_1", "chat_id": "oc_1", "chat_type": "group", "message_type": "text",
                        "mentions": [{"id": {"open_id": "ou_bot"}}],
                        "content": json.dumps({"text": "@bot inspect " + LINK})}}}
        kwargs = dict(chats={"oc_1"}, users={"ou_operator"}, bot_id="ou_bot",
                      bindings={("oc_1", "BASExyz", "tbl123")})
        self.assertEqual(accepted_message(payload, **kwargs)["message_id"], "om_1")
        scope = {('oc_1', 'BASExyz', 'tbl123'): 'vew456'}
        self.assertIsNotNone(accepted_message(payload, **kwargs, view_scopes=scope))
        admitted = accepted_message(payload, **kwargs)
        with self.assertRaises(Clarification):
            validate_resource(admitted, kwargs['bindings'], {('oc_1', 'BASExyz', 'tbl123'): 'vewOther'})
        with self.assertRaises(Clarification):
            validate_resource(admitted, set())
        changed = copy.deepcopy(payload)
        changed["event"]["message"]["mentions"] = [{"id": {"open_id": "ou_someone_else"}}]
        self.assertIsNone(accepted_message(changed, **kwargs))
        changed = copy.deepcopy(payload)
        changed["event"]["sender"]["sender_id"]["open_id"] = "ou_outsider"
        self.assertIsNone(accepted_message(changed, **kwargs))

    def test_rich_post_extracts_actual_link_and_acknowledges_missing_link(self):
        kwargs = dict(chats={'oc_1'}, users={'ou_operator'}, bot_id='ou_bot',
                      bindings={('oc_1', 'BASExyz', 'tbl123')})
        post = {'title':'', 'content':[[{'tag':'at','user_id':'ou_bot'},
                 {'tag':'text','text':'筛选：出席意向=待定。目的：确认参会'}],
                 [{'tag':'a','href':LINK,'text':'飞书外呼测试名单'},
                  {'tag':'img','image_key':'ignored'}]]}
        event = {'event':{'sender':{'sender_type':'user','sender_id':{'open_id':'ou_operator'}},
                 'message':{'message_id':'om_post','chat_id':'oc_1','chat_type':'group',
                 'message_type':'post','mentions':[{'id':{'open_id':'ou_bot'}}],
                 'content':json.dumps(post)}}}
        for content in (post, {'zh_cn':post}):
            event['event']['message']['content'] = json.dumps(content)
            admitted = accepted_message(event, **kwargs)
            self.assertIn('出席意向=待定', admitted['text'])
            self.assertEqual(validate_resource(admitted, kwargs['bindings']).app_token, 'BASExyz')
        post['content'][1] = [{'tag':'img','image_key':'ignored'}]
        event['event']['message']['content'] = json.dumps(post)
        admitted = accepted_message(event, **kwargs)
        self.assertIsNotNone(admitted)  # Receipt still queued; no table read is permitted.
        with self.assertRaises(Clarification):
            validate_resource(admitted, kwargs['bindings'])
        event['event']['message']['content'] = '{invalid'
        admitted = accepted_message(event, **kwargs)
        with self.assertRaises(Clarification):
            validate_resource(admitted, kwargs['bindings'])

    def test_preview_link_trailing_equals_is_corrected_only_with_bound_resource(self):
        payload = {'chat_id':'oc_1','text':'筛选：出席意向=待定\n' + LINK + '='}
        bindings = {('oc_1', 'BASExyz', 'tbl123')}
        scope = {('oc_1', 'BASExyz', 'tbl123'):'vew456'}
        self.assertEqual(validate_resource(payload, bindings, scope).view_id, 'vew456')
        for link in (LINK + '==', LINK.replace('vew456', 'vewOther') + '=',
                     LINK.replace('tbl123', 'tblOther') + '='):
            with self.subTest(link=link), self.assertRaises(Clarification):
                validate_resource({**payload, 'text':link}, bindings, scope)

    def test_sdk_requests_keep_view_and_page_without_filter_or_sort(self):
        client = Mock()
        def response(**kwargs):
            result = Mock()
            result.success.return_value = True
            result.data = NS(**kwargs)
            return result
        client.bitable.v1.app_table_field.list.return_value = response(
            items=[NS(field_id="fld1", field_name="Status", type=3)], has_more=False)
        client.bitable.v1.app_table_record.list.side_effect = [
            response(items=[NS(record_id="rec1")], has_more=True, page_token="page2"),
            response(items=[NS(record_id="rec1"), NS(record_id="rec2")], has_more=False)]
        summary = FeishuGateway(client).inspect(parse_base_link(LINK))
        self.assertEqual(summary["record_count"], 2)
        requests = [call.args[0] for call in client.bitable.v1.app_table_record.list.call_args_list]
        self.assertEqual(requests[1].page_token, "page2")
        for request in requests:
            self.assertEqual(request.view_id, "vew456")
            self.assertIsNone(request.filter)
            self.assertIsNone(request.sort)

    def test_repeated_cursor_fails_instead_of_claiming_complete(self):
        data = NS(items=["record"], has_more=True, page_token="same")
        with self.assertRaises(FeishuFailure):
            list(FeishuGateway._pages(lambda token: data))


class RecordCreateTests(unittest.TestCase):
    def test_record_create_uses_stable_uuid4_format_token(self):
        import uuid
        client=Mock();response=Mock();response.success.return_value=True
        response.data=NS(record=NS(record_id='rec_new',fields={'测试记录编号':'test'}))
        client.bitable.v1.app_table_record.create.return_value=response
        gateway=FeishuGateway(client);ref=parse_base_link(LINK)
        first=gateway.create_record(ref,{'测试记录编号':'test'},'one-authorized-operation')
        request=client.bitable.v1.app_table_record.create.call_args.args[0]
        self.assertEqual(uuid.UUID(request.client_token).version,4)
        first_token=request.client_token
        gateway.create_record(ref,{'测试记录编号':'test'},'one-authorized-operation')
        self.assertEqual(first_token,client.bitable.v1.app_table_record.create.call_args.args[0].client_token)
        self.assertEqual(first['record_id'],'rec_new')
