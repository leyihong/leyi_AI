import json
from pathlib import Path
import tempfile
import time
import unittest
from feishu_calle.preview import (parse_conditions, parse_selection, build_roster, init_previews, save_preview,
                                  act_on_preview, preview_card, Clarification)
from feishu_calle.store import Store


class PreviewTests(unittest.TestCase):
    def row(self, number, **updates):
        fields = {'联系人': f'Test {number}', '电话号码': f'+120255501{number:02d}',
                  '允许电话联系':'是', '禁止联系':'否', '授权来源':'synthetic fixture',
                  '出席意向':'待定', '活动名称':'模拟产品交流会', '测试记录编号':f'T{number:03d}',
                  '数据模式':'SYNTHETIC_NO_CALL'}
        fields.update(updates)
        return {'record_id':f'rec{number}','fields':fields}

    def test_explicit_filters_scope_roster_and_detect_duplicate_numbers(self):
        fields = [{'field_name':name} for name in self.row(1)['fields']]
        conditions = parse_conditions('筛选：活动名称=模拟产品交流会；出席意向=待定。目的：确认是否参加',fields)
        rows = [self.row(1),self.row(2, **{'允许电话联系':'否'}),
                self.row(3, **{'禁止联系':'是'}), self.row(4, **{'出席意向':'参加'}),
                self.row(5, **{'电话号码':''}),self.row(6, **{'电话号码':'+12025550101'})]
        roster = build_roster(rows,conditions)
        self.assertEqual(roster['duplicates'],2)
        self.assertEqual(len(roster['candidates']),2)
        self.assertEqual(sum(roster['excluded'].values()),4)
        filtered = parse_conditions('筛选：测试记录编号!=T006',fields)
        self.assertEqual(len(build_roster(rows,conditions+filtered)['candidates']),1)

    def test_user_boolean_and_unique_number_phrases_keep_first_record(self):
        rows = [self.row(1), self.row(2, **{'电话号码':'+12025550101'}), self.row(3)]
        fields = [{'field_name':name} for name in rows[0]['fields']]
        conditions, unique = parse_selection('筛选：活动名称=模拟产品交流会；出席意向=待定；允许电话联系；无重复号码的联系人\n目的：确认是否参加', fields)
        roster = build_roster(rows, conditions, exclude_duplicates=unique)
        self.assertEqual([p['record_id'] for p in roster['candidates']], ['rec1', 'rec3'])
        self.assertEqual(roster['duplicates'], 0)
        self.assertEqual(roster['excluded']['重复号码（保留第一条）'], 1)
        card = preview_card({'snapshot':json.dumps(roster),'state':'pending','token':'test'})
        self.assertIn('只保留视图读取顺序中的第一条', json.dumps(card,ensure_ascii=False))

    def test_unknown_or_missing_filter_requires_clarification(self):
        for text in ['帮我筛选一下','筛选：不存在的字段=待定','筛选：出席意向']:
            with self.subTest(text=text), self.assertRaises(Clarification):
                parse_conditions(text,[{'field_name':'出席意向'}])

    def test_confirmation_binds_actor_chat_expiry_and_persists_without_call(self):
        with tempfile.TemporaryDirectory() as folder:
            store=Store(Path(folder)/'state.sqlite3')
            init_previews(store)
            roster=build_roster([self.row(1)],[])
            payload={'message_id':'om1','actor':'ou_owner','chat_id':'oc_test'}
            original=save_preview(store,payload,roster)
            replay=save_preview(store,payload,{'different':'ignored'})
            self.assertEqual(original['token'],replay['token'])
            with self.assertRaises(Clarification):
                act_on_preview(store,original['token'],'ou_other','oc_test','confirm')
            confirmed=act_on_preview(store,original['token'],'ou_owner','oc_test','confirm')
            self.assertEqual(confirmed['state'],'confirmed')
            self.assertEqual(store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],0)
            card=json.dumps(preview_card(confirmed),ensure_ascii=False)
            self.assertNotIn('+12025550101',card)
            self.assertIn('尚未拨号',card)
            with store.db:
                store.db.execute('UPDATE roster_previews SET expires_at=?',(time.time()-1,))
            with self.assertRaises(Clarification):
                act_on_preview(store,original['token'],'ou_owner','oc_test','confirm')
            store.close()

    def test_large_roster_paginates_without_truncating_snapshot(self):
        roster=build_roster([self.row(i) for i in range(1,26)],[])
        preview={'snapshot':json.dumps(roster),'state':'pending','token':'opaque'}
        self.assertEqual(len(roster['candidates']),25)
        page=json.dumps(preview_card(preview,2),ensure_ascii=False)
        self.assertIn('第 3/3 页',page)
        self.assertIn('T025',page)
        self.assertNotIn('T001',page)
