import unittest
import httpx
from feishu_calle.calle_api import CalleAPI, CallFailure, validate_result, call_request

D={'purpose':'确认是否参加活动','result_fields':[{'key':'answer','label':'答复','type':'enum','options':['参加','不参加','未知'],'unknown_value':'未知'}]}


class CalleAPITests(unittest.TestCase):
    def test_v2_create_persists_same_key_and_reads_resource_id_not_telephone_id(self):
        requests=[]
        def handle(r):
            requests.append(r)
            if r.method=='POST':return httpx.Response(202,json={'id':'resource1','call_id':'billing2'})
            return httpx.Response(200,json={'id':'resource1','result_status':'pending','status':'completed'})
        api=CalleAPI('test-secret',client=httpx.Client(transport=httpx.MockTransport(handle)))
        body=call_request(D,{'phone':'+12025550101'})
        self.assertEqual(api.create(body,'stable-key')['id'],'resource1')
        api.get('resource1')
        self.assertEqual(str(requests[0].url),'https://api.heycall-e.com/v2/calls')
        self.assertEqual(requests[0].headers['Idempotency-Key'],'stable-key')
        self.assertTrue(str(requests[1].url).endswith('/v2/calls/resource1'))
        schema=body['result_schema']
        self.assertFalse(schema['additionalProperties'])
        self.assertEqual(schema['properties']['answer']['type'],'string')
        self.assertNotIn('maxLength',schema['properties']['answer'])

    def test_create_redirect_timeout_and_missing_id_never_trigger_second_create(self):
        for scenario in ('redirect','timeout','missing_id'):
            calls=[]
            def handle(request):
                calls.append(request)
                if scenario=='timeout':raise httpx.ReadTimeout('secret response',request=request)
                if scenario=='redirect':return httpx.Response(302,headers={'Location':'https://attacker.invalid'})
                return httpx.Response(202,json={})
            api=CalleAPI('test-secret',client=httpx.Client(transport=httpx.MockTransport(handle)))
            with self.subTest(scenario=scenario),self.assertRaises(CallFailure) as caught:
                api.create({'task':'test'},'stable')
            self.assertTrue(caught.exception.uncertain)
            self.assertNotIn('test-secret',str(caught.exception))
            self.assertEqual(len(calls),1)

    def test_business_result_requires_valid_fields_not_truthiness(self):
        self.assertFalse(validate_result(D,{}))
        self.assertFalse(validate_result(D,{'answer':'guessed'}))
        self.assertTrue(validate_result(D,{'answer':'未知','_do_not_contact':'yes'}))
        self.assertFalse(validate_result(D,{'answer':'未知','_do_not_contact':'invalid'}))

    def test_rejection_keeps_safe_code_and_message_without_changing_interface(self):
        api=CalleAPI('test-secret',client=httpx.Client(transport=httpx.MockTransport(
            lambda r:httpx.Response(400,json={'error':{'code':'result_schema_invalid','message':'property rejected','details':{}}}))))
        with self.assertRaises(CallFailure) as caught:api.create({'task':'test'},'same-key')
        self.assertEqual(caught.exception.error_code,'result_schema_invalid')
        self.assertEqual(caught.exception.details,{'message':'property rejected'})
        self.assertFalse(caught.exception.uncertain)
        body=call_request(D,{'phone':'+12025550101'})
        self.assertIn('do_not_contact',body['result_schema']['properties'])
        self.assertNotIn('_do_not_contact',body['result_schema']['properties'])
