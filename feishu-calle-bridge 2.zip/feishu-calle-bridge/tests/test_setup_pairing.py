import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from feishu_calle.pairing import pairing_target, save_target
from feishu_calle.setup import load_local_env, SetupFailure


class SetupTests(unittest.TestCase):
    def test_pairing_requires_exact_code_and_mention(self):
        message = {'sender': {'sender_type': 'user', 'sender_id': {'open_id': 'ou_user'}},
                   'message': {'chat_type': 'group', 'chat_id': 'oc_test', 'message_type': 'text',
                               'mentions': [{'key': '@_user_1', 'id': {'open_id': 'ou_bot'}}],
                               'content': json.dumps({'text': '@_user_1 PAIR-abc'})}}
        self.assertEqual(pairing_target({'event': message}, 'PAIR-abc', 'ou_bot'), ('oc_test', 'ou_user'))
        self.assertIsNone(pairing_target({'event': message}, 'PAIR-other', 'ou_bot'))
        self.assertIsNone(pairing_target({'event': message}, 'PAIR-abc', 'ou_other_bot'))

    def test_environment_load_never_executes_shell_substitution(self):
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {}, clear=True):
            path = Path(folder) / '.env'
            path.write_text('FEISHU_APP_SECRET="$(echo private)"\nFEISHU_ALLOWED_CHAT_IDS=\nFEISHU_ALLOWED_USER_IDS=\n')
            load_local_env(path)
            self.assertEqual(os.environ['FEISHU_APP_SECRET'], '$(echo private)')
            save_target(path, 'oc_test', 'ou_test')
            self.assertIn('FEISHU_ALLOWED_CHAT_IDS=oc_test', path.read_text())
            self.assertIn('FEISHU_APP_SECRET="$(echo private)"', path.read_text())
            os.environ['FEISHU_ALLOWED_CHAT_IDS'] = 'oc_existing'
            with self.assertRaises(SetupFailure):
                save_target(path, 'oc_replacement', 'ou_replacement')
