import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import Mock,patch
from dataclasses import replace
from feishu_calle.config import Settings
from feishu_calle.store import Store
from feishu_calle.jobs import init_jobs
from feishu_calle.definitions import init_definitions, propose_definition, save_definition, act_on_definition
from feishu_calle.preview import init_previews, build_roster, save_preview, Clarification
from feishu_calle.resources import BaseRef
from feishu_calle.execution import (init_execution, attach_execution, approve_execution, ExecutionWorker,
                                   control_batch, notify_execution, batch_card,
                                   authorized_automated_test_recipient, valid_explicit_recontact,attach_recontact_review)
from feishu_calle.calle_api import CallFailure


class ExecutionTests(unittest.TestCase):
    def test_ui_automated_test_exception_requires_all_explicit_gates(self):
        from copy import deepcopy
        original=json.loads(self.preview['snapshot']);definition=original['execution']['definition']
        record=deepcopy(self.record);record['fields'].update({'电话号码':'+12763229632','数据模式':'REAL_AUTHORIZED',
            '通话地区':'US','通话语言':'en-US','联系人时区':'America/New_York','测试情形':'PROVIDER_TEST_BOT'})
        settings=replace(self.settings,mode='live',allowed_phones=('+12763229632',),allow_automated_test_line=True)
        def attached(r,s):
            snapshot=build_roster([r],definition['conditions'])
            return attach_execution(snapshot,definition,BaseRef('example.feishu.cn','BASE1','tbl1','vew1'),[r],self.fields,s)
        self.assertTrue(attached(record,settings)['execution']['authorized_provider_test_bot'])
        self.assertNotIn('authorized_provider_test_bot',attached(record,replace(settings,allow_automated_test_line=False))['execution'])
        self.assertNotIn('authorized_provider_test_bot',attached(record,replace(settings,allowed_phones=()))['execution'])
        for key,value in [('测试情形',''),('通话语言','zh-CN'),('电话号码','+12025550101')]:
            changed=deepcopy(record);changed['fields'][key]=value
            self.assertNotIn('authorized_provider_test_bot',attached(changed,settings)['execution'])

    def setUp(self):
        self.folder=tempfile.TemporaryDirectory();self.path=Path(self.folder.name)/'state.sqlite3'
        self.store=Store(self.path);init_jobs(self.store);init_definitions(self.store);init_previews(self.store);init_execution(self.store)
        self.settings=Settings.from_env({'BRIDGE_DATABASE':str(self.path),'BRIDGE_WRITEBACK':'true'})
        self.fields=[{'field_name':'出席意向','field_id':'source','type':3,'options':['待定']},
                     {'field_name':'回访摘要','field_id':'summary','type':1,'options':[]},
                     {'field_name':'回访出席意向','field_id':'answer','type':1,'options':[]},
                     {'field_name':'人工联系请求','field_id':'human','type':1,'options':[]},
                     {'field_name':'外呼状态','field_id':'state','type':1,'options':[]}]
        self.record={'record_id':'rec1','fields':{'电话号码':'+12025550101','联系人':'synthetic',
                '出席意向':'待定','允许电话联系':'是','授权来源':'test','禁止联系':'否','数据模式':'SYNTHETIC_NO_CALL'}}
        payload={'message_id':'om1','chat_id':'oc1','actor':'ou1','text':'筛选：出席意向=待定。目的：确认是否参加活动。'}
        definition=propose_definition(payload['text'],self.fields)
        draft=save_definition(self.store,payload,definition)
        act_on_definition(self.store,draft['token'],'ou1','oc1','confirm')
        snapshot=build_roster([self.record],definition['conditions']);snapshot['definition_token']=draft['token']
        attach_execution(snapshot,definition,BaseRef('example.feishu.cn','BASE1','tbl1','vew1'),[self.record],self.fields,self.settings)
        self.preview=save_preview(self.store,payload,snapshot)
        self.gateway=Mock()
        self.gateway.record.side_effect=lambda *a:json.loads(json.dumps(self.record))
        self.gateway.fields.return_value=self.fields
        def write(ref,rid,values,operation):self.record['fields'].update(values)
        self.gateway.write_fields.side_effect=write
        self.gateway.send_card.return_value='progress-message'
        self.now=time.time()

    def tearDown(self):
        self.store.close();self.folder.cleanup()

    def approve(self):
        return approve_execution(self.store,self.preview['token'],'ou1','oc1','execute_mock',self.settings)

    def worker(self,provider=None):
        return ExecutionWorker(self.store,self.gateway,self.settings,provider=provider,clock=lambda:self.now)

    def finish(self,worker):
        for _ in range(12):worker.tick();self.now+=100

    def test_mock_end_to_end_writes_only_outputs_and_duplicate_click_does_not_redial(self):
        batch=self.approve();self.assertEqual(batch,self.approve())
        worker=self.worker();self.finish(worker)
        self.assertEqual(self.record['fields']['外呼状态'],'模拟完成')
        self.assertEqual(self.record['fields']['回访出席意向'],'未知')
        self.assertEqual(self.record['fields']['电话号码'],'+12025550101')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],1)
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_batches').fetchone()[0],'finished')
        self.gateway.write_fields.assert_called_once()
        notify_execution(self.store,self.gateway);notify_execution(self.store,self.gateway)
        self.assertEqual(self.gateway.send_card.call_count,2)
        self.assertEqual([c.kwargs['kind'] for c in self.gateway.send_card.call_args_list],['execution-progress','execution-completion'])

    def test_completion_delivery_retry_does_not_recreate_call_or_repeat_successful_notice(self):
        self.approve();self.finish(self.worker())
        attempts=[]
        def send(*args,**kwargs):
            kind=kwargs['kind'];attempts.append(kind)
            if kind=='execution-completion' and attempts.count(kind)==1:raise TimeoutError()
            return kind+'-id'
        self.gateway.send_card.side_effect=send
        with self.assertRaises(TimeoutError):notify_execution(self.store,self.gateway)
        notify_execution(self.store,self.gateway);notify_execution(self.store,self.gateway)
        self.assertEqual(attempts,['execution-progress','execution-completion','execution-completion'])
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],1)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM execution_terminal_notices').fetchone()[0],1)

    def test_live_recontact_card_requires_new_explicit_click_and_cannot_reuse_stale_parent(self):
        parent_batch=self.approve();self.finish(self.worker())
        parent=self.store.db.execute('SELECT i.id,s.provider_id FROM execution_items i JOIN submissions s ON s.operation_id=i.id WHERE i.batch_id=?',(parent_batch,)).fetchone()
        with self.store.db:
            self.store.db.execute("UPDATE execution_batches SET mode='live' WHERE id=?",(parent_batch,))
            self.store.db.execute('UPDATE execution_items SET response=? WHERE id=?',(json.dumps({
                'id':parent['provider_id'],'status':'failed','result_status':'not_applicable'}),parent['id']))
        live=replace(self.settings,mode='live',api_key='test-key',allowed_phones=('+12025550101',))
        self.record['fields'].update({'数据模式':'REAL_AUTHORIZED','通话地区':'US','通话语言':'en-US','联系人时区':'America/New_York'})
        original=json.loads(self.preview['snapshot']);definition=original['execution']['definition']
        snapshot=build_roster([self.record],definition['conditions']);snapshot['definition_token']=original['definition_token']
        attach_execution(snapshot,definition,BaseRef('example.feishu.cn','BASE1','tbl1','vew1'),[self.record],self.fields,live)
        attach_recontact_review(self.store,snapshot,'ou1','oc1')
        self.assertIn('recontact_review',snapshot['execution'])
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],1)
        p=save_preview(self.store,{'message_id':'new-review','actor':'ou1','chat_id':'oc1'},snapshot)
        from feishu_calle.preview import preview_card
        self.assertIn('确认再拨一通',[a['text']['content'] for a in preview_card(p)['elements'][-1]['actions']][0])
        batch=approve_execution(self.store,p['token'],'ou1','oc1','execute_live',live)
        provider=Mock();provider.create.return_value={'id':'second-resource'}
        provider.get.return_value={'id':'second-resource','status':'failed','result_status':'not_applicable'}
        worker=ExecutionWorker(self.store,self.gateway,live,provider=provider,clock=lambda:self.now)
        with patch.object(worker,'_preflight',return_value=True):self.finish(worker)
        provider.create.assert_called_once()
        self.assertEqual(approve_execution(self.store,p['token'],'ou1','oc1','execute_live',live),batch)
        stale=save_preview(self.store,{'message_id':'stale-review','actor':'ou1','chat_id':'oc1'},snapshot)
        with self.assertRaises(Clarification):approve_execution(self.store,stale['token'],'ou1','oc1','execute_live',live)

    def test_completed_but_result_pending_keeps_polling_original_call(self):
        self.approve();provider=Mock()
        provider.create.return_value={'id':'resource1'}
        provider.get.side_effect=[{'id':'resource1','status':'completed','result_status':'pending'},
                                 {'id':'resource1','status':'completed','result_status':'unavailable'}]
        self.finish(self.worker(provider))
        provider.create.assert_called_once()
        self.assertEqual(provider.get.call_count,2)
        self.assertTrue(all(c.args[0]=='resource1' for c in provider.get.call_args_list))
        self.assertNotIn('回访出席意向',self.record['fields'])

    def test_unknown_submission_pauses_and_cannot_be_recreated_after_restart(self):
        self.approve();provider=Mock();provider.create.side_effect=CallFailure(uncertain=True)
        self.finish(self.worker(provider))
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'reconcile')
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_batches').fetchone()[0],'paused')
        with self.assertRaises(Clarification):control_batch(self.store,self.approve(),'ou1','oc1','resume')
        self.store.close();self.store=Store(self.path)
        self.finish(self.worker(provider));provider.create.assert_called_once()

    def test_writeback_failure_retries_output_without_creating_another_call(self):
        batch=self.approve();worker=self.worker()
        worker.tick();self.now+=10;worker.tick()
        self.gateway.write_fields.side_effect=TimeoutError()
        worker.tick()
        self.gateway.write_fields.side_effect=lambda ref,rid,values,op:self.record['fields'].update(values)
        self.now+=100;self.finish(worker)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],1)
        self.assertEqual(self.gateway.write_fields.call_count,2)
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'done')

    def test_manual_edit_to_output_is_preserved(self):
        self.approve();worker=self.worker();worker.tick();self.now+=10;worker.tick()
        self.record['fields']['回访摘要']='operator edit'
        worker.tick()
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'conflict')
        self.assertEqual(self.record['fields']['回访摘要'],'operator edit')
        self.gateway.write_fields.assert_not_called()

    def test_source_phone_changes_before_execution_are_skipped(self):
        self.approve();provider=Mock()
        self.record['fields']['电话号码']='+12025550102'
        self.finish(self.worker(provider));provider.create.assert_not_called()
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'skipped')

    def test_cancel_prevents_queued_submissions(self):
        batch=self.approve();control_batch(self.store,batch,'ou1','oc1','cancel')
        provider=Mock();self.finish(self.worker(provider));provider.create.assert_not_called()
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],0)

    def test_synthetic_live_mode_and_old_preview_are_rejected(self):
        live=Settings.from_env({'BRIDGE_MODE':'live','CALLE_API_KEY':'test-key','CALLE_ALLOWED_TEST_PHONES':'+12025550101'})
        snapshot=json.loads(self.preview['snapshot']);snapshot['execution']['mode']='live'
        with self.store.db:self.store.db.execute('UPDATE roster_previews SET snapshot=?',(json.dumps(snapshot),))
        with self.assertRaises(Clarification):approve_execution(self.store,self.preview['token'],'ou1','oc1','execute_live',live)
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM execution_batches').fetchone()[0],0)

    def test_restart_after_acceptance_reads_original_even_if_source_changed(self):
        self.approve();worker=self.worker();worker.tick()
        with self.store.db:self.store.db.execute("UPDATE execution_items SET state='queued',next_poll=0")
        self.record['fields']['电话号码']='+12025550102'
        self.store.close();self.store=Store(self.path)
        provider=Mock();provider.get.return_value={'id':'known','result_status':'unavailable'}
        worker=self.worker(provider);worker.tick()
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'waiting')
        provider.create.assert_not_called()

    def test_read_pending_result_continues_while_batch_paused(self):
        batch=self.approve();provider=Mock();provider.create.return_value={'id':'original'}
        provider.get.return_value={'id':'original','result_status':'unavailable'}
        worker=self.worker(provider);worker.tick();self.now+=10
        control_batch(self.store,batch,'ou1','oc1','pause')
        worker.tick();provider.get.assert_called_once_with('original')
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'output_pending')

    def test_progress_uses_one_message_and_changes_do_not_create_another(self):
        self.approve();notify_execution(self.store,self.gateway)
        worker=self.worker();worker.tick();notify_execution(self.store,self.gateway)
        self.gateway.send_card.assert_called_once()
        self.gateway.patch_card.assert_called_once()

    def test_final_card_counts_unknown_but_not_technical_failure_as_business_answer(self):
        batch=self.approve()
        manifest=json.loads(self.preview['snapshot'])
        field=next(f for f in manifest['execution']['definition']['result_fields'] if f['type']=='enum')
        unknown=field['unknown_value']
        with self.store.db:
            self.store.db.execute("UPDATE execution_items SET response=? WHERE batch_id=?",(json.dumps(
                {'status':'completed','result_status':'available','result':{field['key']:unknown}}),batch))
        card=batch_card(self.store,batch)
        content=card['elements'][0]['text']['content']
        self.assertIn('模拟枚举统计：'+field['label'],content)
        self.assertIn(unknown+' 1',content)
        self.assertEqual(card['elements'][1]['actions'][0]['url'],
                         'https://example.feishu.cn/base/BASE1?table=tbl1&view=vew1')
        with self.store.db:
            self.store.db.execute("UPDATE execution_items SET response=? WHERE batch_id=?",(json.dumps(
                {'status':'failed','result_status':'not_applicable','result':None}),batch))
        content=batch_card(self.store,batch)['elements'][0]['text']['content']
        self.assertIn(unknown+' 0',content)
        self.assertIn('技术失败 1',content)

    def test_automated_line_exception_never_applies_to_other_contacts(self):
        execution={'authorized_provider_test_bot':True}
        person={'recipient_kind':'provider_test_bot','phone':'+12763229632'}
        self.assertTrue(authorized_automated_test_recipient(execution,person))
        self.assertFalse(authorized_automated_test_recipient({},person))
        self.assertFalse(authorized_automated_test_recipient(execution,{**person,'phone':'+12025550101'}))
        self.assertFalse(authorized_automated_test_recipient(execution,{**person,'recipient_kind':'person'}))

    def test_recontact_requires_same_actor_recipient_and_final_failed_parent(self):
        batch=self.approve();worker=self.worker();worker.tick()
        parent=self.store.db.execute('SELECT id,person FROM execution_items WHERE batch_id=?',(batch,)).fetchone()
        submission=self.store.db.execute('SELECT provider_id FROM submissions WHERE operation_id=?',(parent['id'],)).fetchone()
        person=json.loads(parent['person'])
        grant={'authorization_id':'explicit-new-user-instruction','scope':'one_more_call','phone':person['phone'],
               'parent_operation_id':parent['id'],'parent_resource_id':submission['provider_id']}
        response={'id':submission['provider_id'],'status':'failed','result_status':'not_applicable'}
        with self.store.db:
            self.store.db.execute("UPDATE execution_batches SET mode='live' WHERE id=?",(batch,))
            self.store.db.execute('UPDATE execution_items SET response=? WHERE id=?',(json.dumps(response),parent['id']))
        self.assertTrue(valid_explicit_recontact(self.store,grant,person,'ou1','oc1'))
        for actor,chat in [('other','oc1'),('ou1','other')]:
            self.assertFalse(valid_explicit_recontact(self.store,grant,person,actor,chat))
        self.assertFalse(valid_explicit_recontact(self.store,grant,{**person,'record_id':'another'},'ou1','oc1'))
        self.assertFalse(valid_explicit_recontact(self.store,{**grant,'parent_resource_id':'another'},person,'ou1','oc1'))
        for status,readiness in [('completed','available'),('failed','pending')]:
            with self.store.db:
                self.store.db.execute('UPDATE execution_items SET response=? WHERE id=?',
                    (json.dumps({**response,'status':status,'result_status':readiness}),parent['id']))
            self.assertFalse(valid_explicit_recontact(self.store,grant,person,'ou1','oc1'))

    def test_output_schema_changes_stop_writeback_without_redial(self):
        self.approve();worker=self.worker();worker.tick();self.now+=10;worker.tick()
        self.gateway.fields.return_value=[{**f,'field_name':'renamed'} if f['field_id']=='summary' else f for f in self.fields]
        worker.tick()
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'conflict')
        self.gateway.write_fields.assert_not_called()
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],1)

    def test_prior_mock_run_does_not_block_a_new_explicit_mock_acceptance(self):
        self.approve();self.finish(self.worker())
        # Explicit new test intent gets a new manifest/approval; same-intent retries stay idempotent.
        first=self.store.db.execute('SELECT id FROM execution_items').fetchone()[0]
        with self.store.db:
            self.store.db.execute("UPDATE execution_items SET id=? WHERE id=?",('previous-mock-item',first))
            self.store.db.execute("UPDATE submissions SET operation_id=? WHERE operation_id=?",('previous-mock-item',first))
            self.store.db.execute("UPDATE execution_batches SET state='running'")
            self.store.db.execute("INSERT INTO execution_items(id,batch_id,record_id,state,person) SELECT ?,batch_id,record_id,'queued',person FROM execution_items WHERE id='previous-mock-item'",(first,))
            person=json.loads(self.store.db.execute('SELECT person FROM execution_items WHERE id=?',(first,)).fetchone()[0])
            person['expected_outputs']={name:self.record['fields'].get(name,'') for name in person['expected_outputs']}
            self.store.db.execute('UPDATE execution_items SET person=? WHERE id=?',(json.dumps(person),first))
        self.finish(self.worker())
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items WHERE id=?',(first,)).fetchone()[0],'done')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],2)

    def test_result_timeout_stops_all_future_queries_and_survives_restart(self):
        batch=self.approve();provider=Mock();provider.create.return_value={'id':'original'}
        worker=self.worker(provider);worker.tick();self.now+=301
        worker.tick();provider.get.assert_not_called()
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'result_stopped')
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_batches').fetchone()[0],'stopped')
        self.store.close();self.store=Store(self.path)
        self.finish(self.worker(provider));provider.create.assert_called_once();provider.get.assert_not_called()
        with self.assertRaises(Clarification):control_batch(self.store,batch,'ou1','oc1','resume')

    def test_result_read_count_limit_stops_even_while_user_paused(self):
        batch=self.approve()
        manifest=json.loads(self.store.db.execute('SELECT manifest FROM execution_batches').fetchone()[0])
        manifest['execution']['poll_max_reads']=1
        with self.store.db:self.store.db.execute('UPDATE execution_batches SET manifest=?',(json.dumps(manifest),))
        provider=Mock();provider.create.return_value={'id':'original'}
        provider.get.return_value={'id':'original','status':'completed','result_status':'pending'}
        worker=self.worker(provider);worker.tick();self.now+=10
        control_batch(self.store,batch,'ou1','oc1','pause')
        worker.tick();worker.tick();worker.tick()
        provider.get.assert_called_once_with('original')
        self.assertEqual(self.store.db.execute('SELECT error_kind FROM execution_items').fetchone()[0],'RESULT_READ_LIMIT')

    def test_three_read_failures_stop_instead_of_retrying_paused_item(self):
        self.approve();provider=Mock();provider.create.return_value={'id':'original'}
        provider.get.side_effect=CallFailure(uncertain=False)
        worker=self.worker(provider);worker.tick()
        for _ in range(7):self.now+=10;worker.tick()
        self.assertEqual(provider.get.call_count,3)
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_batches').fetchone()[0],'stopped')
        provider.create.assert_called_once()

    def test_auth_read_failure_stops_after_first_rejection(self):
        self.approve();provider=Mock();provider.create.return_value={'id':'original'}
        provider.get.side_effect=CallFailure(401)
        worker=self.worker(provider);worker.tick();self.now+=10
        worker.tick();worker.tick();provider.get.assert_called_once()
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'result_stopped')

    def test_output_retry_limit_waits_for_manual_resume_without_querying_phone(self):
        batch=self.approve();worker=self.worker();worker.tick();self.now+=10;worker.tick()
        self.gateway.write_fields.side_effect=TimeoutError()
        for _ in range(7):self.now+=10;worker.tick()
        self.assertEqual(self.gateway.write_fields.call_count,3)
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'output_stopped')
        self.gateway.write_fields.side_effect=lambda ref,rid,values,op:self.record['fields'].update(values)
        control_batch(self.store,batch,'ou1','oc1','resume')
        self.finish(worker)
        self.assertEqual(self.store.db.execute('SELECT state FROM execution_items').fetchone()[0],'done')
        self.assertEqual(self.store.db.execute('SELECT count(*) FROM submissions').fetchone()[0],1)

    def test_telephone_status_is_independent_of_business_result(self):
        from feishu_calle.execution import telephone_status
        cases=[({'status':'failed','result_status':'not_applicable'},'技术失败'),
               ({'status':'failed','call_outcome':'completed'},'技术失败'),
               ({'status':'canceled','result_status':'not_applicable'},'已取消'),
               ({'status':'completed','call_outcome':'no_answer'},'未接通'),
               ({'status':'completed','call_outcome':'busy'},'忙线'),
               ({'status':'completed','call_outcome':'declined'},'拒接'),
               ({'status':'completed','call_outcome':None},'电话结果未知'),
               ({'status':'completed','call_outcome':'completed','result_status':'unavailable'},'通话完成')]
        for response,label in cases:
            with self.subTest(response=response):self.assertEqual(telephone_status(response),label)

    def test_technical_failure_writeback_never_claims_call_was_completed(self):
        self.approve();provider=Mock();provider.create.return_value={'id':'original'}
        provider.get.return_value={'id':'original','status':'failed','call_outcome':None,'result_status':'not_applicable'}
        self.finish(self.worker(provider))
        self.assertEqual(self.record['fields']['外呼状态'],'模拟：技术失败')
        self.assertNotIn('回访出席意向',self.record['fields'])
        provider.create.assert_called_once()

    def test_mock_attachment_excludes_real_authorized_record(self):
        self.record['fields']['数据模式']='REAL_AUTHORIZED'
        snapshot=build_roster([self.record],[])
        definition=json.loads(self.store.db.execute('SELECT definition FROM task_definitions LIMIT 1').fetchone()[0])
        attach_execution(snapshot,definition,BaseRef('example.feishu.cn','BASE1','tbl1','vew1'),[self.record],self.fields,self.settings)
        self.assertEqual(snapshot['candidates'],[])
        self.assertEqual(snapshot['excluded']['非模拟记录，模拟模式不处理'],1)
