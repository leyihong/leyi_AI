"""Exact recipient narrowing outside the model; never authorizes execution."""
from copy import deepcopy
import re
from .preview import Clarification, text_value


def recipient_edit(text,previous,fields):
    if not previous:return None
    clean=re.sub(r'@_user_\d+|<at\b[^>]*>.*?</at>','',text).strip()
    clean=re.sub(r'^任务\s*[a-f0-9]{8}\s*','',clean)
    match=re.fullmatch(r'(?:修改|指定)?(?:对象|联系对象|外呼对象|联系人)\s*[:：]\s*(.+)',clean)
    if not match:
        match=re.fullmatch(r'(?:请)?(?:先|只|仅|本次只|这次只)(?:给|联系|打给)\s*(.+?)(?:\s*(?:拨号|打电话|外呼|打个电话))?[。！!]?\s*',clean)
    if not match:return None
    value=match[1].strip(' “”"')
    if not value or len(value)>40 or re.search(r'[，,、/;；\n]|和|以及|或者|然后|再给|筛选|全部|所有|前\d|第\d',value):
        raise Clarification('本次只能按完整联系人姓名或测试记录编号选择一条记录；不能把多人或顺序指令猜成单个人。')
    name='测试记录编号' if re.fullmatch(r'T\d{3,}',value,re.I) else '联系人'
    if name=='测试记录编号':value=value.upper()
    column=next((f for f in fields if f['field_name']==name),None)
    if not column:raise Clarification('找不到用于定位的列“'+name+'”，请检查表格字段。')
    draft=deepcopy(previous)
    old=draft.get('recipient_selection')
    conditions=[tuple(c) for c in draft['conditions']]
    bindings=draft.get('condition_bindings',[])
    if old:
        conditions=[c for c in conditions if c!=(old['field_name'],'=',old['value'])]
        bindings=[b for b in bindings if not(b['field_name']==old['field_name'] and b['operator']=='=' and b['value']==old['value'])]
    selection={'field_name':name,'value':value,'expected_count':1}
    draft['conditions']=conditions+[(name,'=',value)]
    draft['condition_bindings']=bindings+[{'field_id':column['field_id'],'field_name':name,'operator':'=','value':value}]
    draft['recipient_selection']=selection
    draft['revision']+=1
    draft['change_summary']=['本次联系对象']
    draft['proposal_source']='按你的明确指令收窄本次名单，未调用模型、未拨号。原任务目的、业务筛选和结果字段保留。'
    draft['interpretation']='本次只处理 '+value+'；其余人本次不执行。名单须唯一匹配并再次确认，不视为真实拨号授权。'
    return draft


def check_recipient_selection(records,definition):
    selection=definition.get('recipient_selection')
    if not selection:return
    if (selection['field_name'],'=',selection['value']) not in [tuple(c) for c in definition['conditions']]:
        raise Clarification('指定对象与筛选范围不一致，已阻止生成名单；请重新指定对象。')
    matches=[r for r in records if all((text_value(r['fields'].get(name))!=value if op=='!=' else text_value(r['fields'].get(name))==value)
                                     for name,op,value in definition['conditions'])]
    if not matches:
        raise Clarification('指定对象未在原筛选范围内唯一匹配；请核对完整姓名、记录编号及原条件。不会扩大范围查找或拨号。')
    if len(matches)!=1:
        raise Clarification('指定对象匹配到多条记录，尚未生成可执行名单；请改用唯一的测试记录编号。')


def retain_recipient_selection(definition,fields):
    selection=definition.get('recipient_selection')
    if not selection:return
    column=next((f for f in fields if f['field_name']==selection['field_name']),None)
    if not column:raise Clarification('指定对象的定位列已经不存在，请重新检查表格。')
    condition=(selection['field_name'],'=',selection['value'])
    if condition not in [tuple(c) for c in definition['conditions']]:definition['conditions'].append(condition)
    bindings=definition.setdefault('condition_bindings',[])
    if not any(b['field_name']==condition[0] and b['operator']==condition[1] and b['value']==condition[2] for b in bindings):
        bindings.append({'field_id':column['field_id'],'field_name':condition[0],'operator':condition[1],'value':condition[2]})
