"""Durable submission checkpoints; never submit a network call inside a transaction."""
import json
import os
from pathlib import Path
import sqlite3
import uuid


class SubmissionConflict(ValueError):
    """An existing logical operation has different approved content."""


class Store:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        descriptor = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(descriptor)
        os.chmod(path, 0o600)
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA busy_timeout=5000")
        self.db.execute("""CREATE TABLE IF NOT EXISTS submissions (
            operation_id TEXT PRIMARY KEY,
            idempotency_key TEXT UNIQUE NOT NULL,
            request_json TEXT NOT NULL,
            state TEXT NOT NULL,
            provider_id TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        self.db.commit()

    def close(self) -> None:
        self.db.close()

    def reserve(self, operation_id: str, request: dict) -> dict:
        if not operation_id:
            raise ValueError("A stable operation_id is required")
        canonical = json.dumps(request, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        with self.db:
            self.db.execute(
                "INSERT OR IGNORE INTO submissions(operation_id,idempotency_key,request_json,state) VALUES (?,?,?,?)",
                (operation_id, f"feishu-{uuid.uuid4()}", canonical, "reserved"),
            )
            row = self.db.execute("SELECT * FROM submissions WHERE operation_id=?", (operation_id,)).fetchone()
            if row["request_json"] != canonical:
                raise SubmissionConflict("Approved content changed; create and confirm a new intent")
            return dict(row)

    def claim_submission(self, operation_id: str) -> bool:
        """Exactly one local worker can claim a reserved operation."""
        with self.db:
            changed = self.db.execute(
                "UPDATE submissions SET state='submitting' WHERE operation_id=? AND state='reserved'",
                (operation_id,),
            )
            return changed.rowcount == 1

    def accepted(self, operation_id: str, provider_id: str) -> None:
        if not provider_id:
            raise ValueError("Provider resource ID is required")
        with self.db:
            changed = self.db.execute(
                "UPDATE submissions SET state='accepted', provider_id=? WHERE operation_id=? AND state='submitting'",
                (provider_id, operation_id),
            )
            if changed.rowcount != 1:
                raise ValueError("Operation is not awaiting its create response")

    def recovery_actions(self) -> list[dict]:
        rows = self.db.execute("SELECT operation_id,state,provider_id FROM submissions WHERE state IN ('submitting','accepted')").fetchall()
        return [
            {"operation_id": row["operation_id"], "provider_id": row["provider_id"],
             "action": "read_original" if row["provider_id"] else "reconcile_unknown_submission"}
            for row in rows
        ]
