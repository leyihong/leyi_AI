"""Durable receipt notifications, independent of slow table work."""
import json
import time


RECEIPT = '了解，已收到你的任务。正在后台运行中，如需补充信息会告知你。'
FAILURE = '这次名单预览处理失败，尚未发起外呼。请稍后重试；若仍失败，请检查表格权限和筛选条件。'


def init_jobs(store) -> None:
    store.db.execute('''CREATE TABLE IF NOT EXISTS inspection_jobs (
        message_id TEXT PRIMARY KEY, payload TEXT NOT NULL,
        state TEXT NOT NULL DEFAULT 'queued', error_kind TEXT)''')
    store.db.execute('''CREATE TABLE IF NOT EXISTS job_notices (
        notice_key TEXT PRIMARY KEY, message_id TEXT NOT NULL, kind TEXT NOT NULL,
        content TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'pending',
        attempts INTEGER NOT NULL DEFAULT 0, next_attempt REAL NOT NULL DEFAULT 0)''')
    store.db.commit()


def enqueue_job(store, payload: dict) -> bool:
    # The callback does only a local transaction, never a network request.
    with store.db:
        inserted = store.db.execute('INSERT OR IGNORE INTO inspection_jobs(message_id,payload) VALUES (?,?)',
                                    (payload['message_id'], json.dumps(payload))).rowcount == 1
        if inserted:
            store.db.execute('INSERT INTO job_notices(notice_key,message_id,kind,content) VALUES (?,?,?,?)',
                ('receipt:' + payload['message_id'], payload['message_id'], 'receipt', RECEIPT))
        return inserted


def next_job(store):
    # Preserve acknowledgement-before-preview order. Old jobs without a receipt
    # are compatible; after bounded delivery failure, table work can still run.
    return store.db.execute('''SELECT j.* FROM inspection_jobs j
        LEFT JOIN job_notices n ON n.notice_key='receipt:' || j.message_id
        WHERE j.state='queued' AND (n.state IN ('sent','abandoned') OR n.notice_key IS NULL)
        ORDER BY j.rowid LIMIT 1''').fetchone()


def queue_failure(store, message_id: str) -> None:
    with store.db:
        store.db.execute('INSERT OR IGNORE INTO job_notices(notice_key,message_id,kind,content) VALUES (?,?,?,?)',
                         ('failure:' + message_id, message_id, 'failure', FAILURE))


def deliver_notice(store, gateway) -> bool:
    row = store.db.execute("SELECT * FROM job_notices WHERE state='pending' AND next_attempt<=? ORDER BY rowid LIMIT 1",
                           (time.time(),)).fetchone()
    if row is None:
        return False
    try:
        gateway.reply_text(row['message_id'], row['content'], row['kind'])
    except Exception:
        attempts = row['attempts'] + 1
        with store.db:
            store.db.execute('UPDATE job_notices SET attempts=?,state=?,next_attempt=? WHERE notice_key=?',
                (attempts, 'abandoned' if attempts >= 3 else 'pending',
                 time.time() + 2 ** attempts, row['notice_key']))
    else:
        with store.db:
            store.db.execute("UPDATE job_notices SET state='sent',attempts=attempts+1 WHERE notice_key=?", (row['notice_key'],))
    return True
