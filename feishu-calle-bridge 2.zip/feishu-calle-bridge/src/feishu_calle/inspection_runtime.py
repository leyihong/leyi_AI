"""Explicitly enabled Feishu inspection bridge; durable queue, no dialing."""
import json
import logging
import re
import threading
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,urlencode
from .store import Store
from .resources import parse_resource_link, WikiRef
from .feishu import FeishuGateway, create_client
from .jobs import init_jobs, enqueue_job, next_job, deliver_notice, queue_failure
from .preview import (Clarification, parse_selection, build_roster, init_previews,
                      save_preview, preview_card, act_on_preview)

from .definitions import (init_definitions, propose_definition, save_definition, definition_card,
                          act_on_definition, approved_definition)

from .execution import init_execution, attach_execution, attach_recontact_review, approve_execution, ExecutionWorker, notify_execution, control_batch, batch_card
from .conversation import revise_pending_definition, confirm_from_text
from .natural_language import LocalPlanner, ModelClarification, PlannerUnavailable, ProposalInvalid
from .nl_workflow import init_nl_workflow, resolve_nl_input, propose_nl_task
from .recipient_scope import check_recipient_selection
from .audit import record_audit
from .output_columns import ensure_output_columns

LOG = logging.getLogger(__name__)


def task_issue_card(exc):
    title='任务暂未生成'
    if isinstance(exc,ModelClarification):title='需要确认一处信息'
    elif isinstance(exc,PlannerUnavailable):title='任务解析服务暂不可用'
    elif isinstance(exc,ProposalInvalid):title='任务方案未通过检查'
    return {'header':{'title':{'tag':'plain_text','content':'CALL-E：'+title}},
            'elements':[{'tag':'div','text':{'tag':'plain_text','content':str(exc)}}]}


def message_text(message: dict) -> str:
    """Decode text/post without fetching embedded previews or their images."""
    content = json.loads(message.get('content', '{}'))
    if message.get('message_type') == 'text':
        text = content.get('text')
        if not isinstance(text, str):
            raise ValueError('Invalid text')
        return text
    if message.get('message_type') != 'post':
        raise ValueError('Unsupported message')
    # Receive payloads usually contain title/content directly; accept localized posts too.
    if 'content' not in content:
        content = next((content[k] for k in ('zh_cn', 'en_us', 'ja_jp')
                        if isinstance(content.get(k), dict)), {})
    paragraphs = content.get('content')
    if not isinstance(paragraphs, list):
        raise ValueError('Invalid post')
    lines = [content.get('title', '')]
    for paragraph in paragraphs:
        if not isinstance(paragraph, list):
            raise ValueError('Invalid paragraph')
        parts = []
        for element in paragraph:
            tag = element.get('tag')
            if tag in ('text', 'md'):
                parts.append(element.get('text', ''))
            elif tag == 'a':
                # Use the actual target, not the displayed document name.
                parts.append(' ' + element.get('href', '') + ' ')
        lines.append(''.join(parts))
    return '\n'.join(lines)


def validate_resource(payload: dict, bindings: set,
                      view_scopes: dict | None = None):
    if payload.get('clarification'):
        raise Clarification(payload['clarification'])
    try:
        links = list(dict.fromkeys(re.findall(r'https://[^\s<>]+', payload['text'])))
        if len(links) != 1:
            raise ValueError('Need exactly one link')
        # Some pasted preview links have a single spurious '=' after view ID.
        # Correct only that precise shape; the full binding check below still applies.
        link = re.sub(r'([?&]view=vew[A-Za-z0-9]+)=$', r'\1', links[0])
        url=urlsplit(link);query=parse_qs(url.query,keep_blank_values=True)
        if 'table' not in query and 'view' not in query:
            match=re.fullmatch(r'/(wiki|base)/([A-Za-z0-9]+)/?',url.path)
            if match:
                resource_key=('wiki:' if match[1]=='wiki' else '')+match[2]
                scopes=[s for s in bindings if s[0]==payload['chat_id'] and s[1]==resource_key]
                if len(scopes)==1:
                    scope=scopes[0];extra={'table':scope[2]}
                    if view_scopes and view_scopes.get(scope):extra['view']=view_scopes[scope]
                    link=url._replace(query=urlencode(extra)).geturl()
        ref = parse_resource_link(link)
    except (ValueError, KeyError, TypeError):
        raise Clarification('未能识别唯一有效的多维表格地址：请检查链接是否包含正确的 table 和 view 参数，且没有多余字符。可以在同一条消息中直接粘贴表格链接。') from None
    key = 'wiki:' + ref.node_token if isinstance(ref, WikiRef) else ref.app_token
    scope = (payload['chat_id'], key, ref.table_id)
    if scope not in bindings or (view_scopes is not None and ref.view_id != view_scopes.get(scope)):
        raise Clarification('这个表格或视图尚未绑定到当前群，请使用已授权的测试表格及视图链接。')
    return ref


def accepted_message(data: dict, *, chats: set[str], users: set[str], bot_id: str,
                     bindings: set[tuple[str, str, str]],
                     view_scopes: dict[tuple[str, str, str], str | None] | None = None) -> dict | None:
    event = data.get('event', {})
    message, sender = event.get('message', {}), event.get('sender', {})
    actor = (sender.get('sender_id') or {}).get('open_id')
    chat_id = message.get('chat_id')
    if (sender.get('sender_type') != 'user' or actor not in users or chat_id not in chats
            or message.get('chat_type') != 'group' or not message.get('message_id')):
        return None
    mentions = message.get('mentions') or []
    if not any((mention.get('id') or {}).get('open_id') == bot_id for mention in mentions):
        return None
    payload = {'message_id': message['message_id'], 'chat_id': chat_id, 'actor': actor}
    try:
        payload['text'] = message_text(message)
    except (ValueError, KeyError, TypeError, AttributeError):
        payload['text'] = ''
        payload['clarification'] = '暂时无法读取这条消息，请使用文字或富文本，附上表格链接、筛选条件和任务目的。'
    # Acknowledge the authorized mention first. Resource checks run in the worker
    # before any table reads, and invalid requests receive a clarification.
    return payload


def run(settings, *, bot_id: str, bindings_path: Path) -> None:
    import lark_oapi as lark
    raw_bindings = json.loads(bindings_path.read_text())
    bindings = {(item["chat_id"], 'wiki:' + item['wiki_node_token'] if item.get('wiki_node_token') else item["app_token"],
                 item["table_id"]) for item in raw_bindings}
    pinned = {(item['chat_id'], item['wiki_node_token'], item['table_id']): item['app_token']
              for item in raw_bindings if item.get('wiki_node_token')}
    view_scopes = {(item['chat_id'], 'wiki:' + item['wiki_node_token'] if item.get('wiki_node_token') else item['app_token'],
                    item['table_id']): item.get('view_id') for item in raw_bindings}
    if not bindings or not settings.chats or not settings.users or not bot_id:
        raise ValueError("Inspection requires explicit chat/user/bot IDs and resource bindings")
    if not settings.app_id or not settings.app_secret:
        raise ValueError("FEISHU_APP_ID and FEISHU_APP_SECRET are required")
    def connect_store():
        store = Store(settings.database)
        init_jobs(store)
        init_previews(store)
        init_definitions(store)
        init_execution(store)
        init_nl_workflow(store)
        return store
    initial = connect_store()
    # Only inspections are safe to resume; this does not replay phone submissions.
    with initial.db:
        initial.db.execute("UPDATE inspection_jobs SET state='queued' WHERE state='running'")
    initial.close()
    stop = threading.Event()
    receipt_wake = threading.Event()
    work_wake = threading.Event()
    def on_message(event):
        try:
            payload = accepted_message(json.loads(lark.JSON.marshal(event)), chats=set(settings.chats),
                users=set(settings.users), bot_id=bot_id, bindings=bindings, view_scopes=view_scopes)
            if payload:
                store = connect_store()
                try:
                    enqueue_job(store,payload)
                    receipt_wake.set()
                finally:
                    store.close()
        except Exception as exc:
            LOG.error("Inspection ingress failed: %s", type(exc).__name__)
    def worker():
        store = connect_store()
        planner = LocalPlanner(settings.nlp_model) if settings.nlp_engine=='ollama' else None
        gateway = FeishuGateway(create_client(settings.app_id, settings.app_secret))
        try:
            while not stop.is_set():
                with store.db:
                    row = next_job(store)
                    if row:
                        store.db.execute("UPDATE inspection_jobs SET state='running' WHERE message_id=?", (row["message_id"],))
                if not row:
                    work_wake.wait(0.5)
                    work_wake.clear()
                    continue
                payload = json.loads(row["payload"])
                try:
                    if payload.get('phase') != 'scan' and not re.search(r'https://', payload.get('text', '')):
                        if payload.get('clarification'):
                            raise Clarification(payload['clarification'])
                        draft = confirm_from_text(store, payload)
                        if draft is None:
                            if planner or re.search(r'(?:对象|联系人)\s*[:：]|(?:先|只|仅)(?:给|联系|打给)',payload['text']):
                                context=resolve_nl_input(store,payload)
                                source_ref=validate_resource(context['source'],bindings,view_scopes)
                                if isinstance(source_ref,WikiRef):
                                    source_ref=gateway.resolve_wiki(source_ref,pinned[(payload['chat_id'],source_ref.node_token,source_ref.table_id)])
                                source_fields=gateway.fields(source_ref)
                                context['mode']=settings.mode
                                draft=propose_nl_task(store,planner,payload,context,source_fields)
                            else:
                                draft = revise_pending_definition(store, payload)
                        gateway.send_card(payload['chat_id'], payload['message_id'], definition_card(draft), kind='definition')
                        with store.db:
                            store.db.execute("UPDATE inspection_jobs SET state='done' WHERE message_id=?", (row['message_id'],))
                        continue
                    ref = validate_resource(payload, bindings, view_scopes)
                    if isinstance(ref, WikiRef):
                        ref = gateway.resolve_wiki(ref, pinned[(payload['chat_id'], ref.node_token, ref.table_id)])
                    fields = gateway.fields(ref)
                    if payload.get('phase') != 'scan':
                        if planner:
                            context=resolve_nl_input(store,payload)
                            context['mode']=settings.mode
                            draft=propose_nl_task(store,planner,payload,context,fields)
                        else:
                            definition = propose_definition(payload.get('text', ''), fields)
                            definition['mode'] = settings.mode
                            draft = save_definition(store, payload, definition)
                        gateway.send_card(payload['chat_id'], payload['message_id'], definition_card(draft), kind='definition')
                        with store.db:
                            store.db.execute("UPDATE inspection_jobs SET state='done' WHERE message_id=?", (row['message_id'],))
                        continue
                    definition = approved_definition(store, payload)
                    definition,fields=ensure_output_columns(store,gateway,ref,payload['definition_token'])
                    records = gateway.records(ref)
                    check_recipient_selection(records,definition)
                    snapshot = build_roster(records, definition['conditions'],
                                            exclude_duplicates=definition['exclude_duplicates'])
                    snapshot['purpose'] = definition['purpose']
                    snapshot['definition_token'] = payload['definition_token']
                    snapshot['result_fields'] = definition['result_fields']
                    snapshot = attach_execution(snapshot, definition, ref, records, fields, settings)
                    attach_recontact_review(store,snapshot,payload['actor'],payload['chat_id'])
                    record_audit(store,payload,'roster.checked',{'read_count':len(records),'candidate_count':len(snapshot['candidates']),
                        'excluded':snapshot['excluded'],'mode':settings.mode,'execution_authorized':False})
                    preview = save_preview(store, {**payload, 'message_id': payload['message_id'] + ':' + payload['definition_token']}, snapshot)
                    gateway.send_card(payload['chat_id'], payload['message_id'], preview_card(preview),
                                      kind='roster-preview:' + payload['definition_token'])
                    with store.db:
                        store.db.execute("UPDATE inspection_jobs SET state='done' WHERE message_id=?", (row["message_id"],))
                except Clarification as exc:
                    record_audit(store,payload,'workflow.blocked',{'message':str(exc)})
                    try:
                        gateway.send_card(payload['chat_id'], payload['message_id'], task_issue_card(exc), kind='clarification')
                        with store.db:
                            store.db.execute("UPDATE inspection_jobs SET state='done' WHERE message_id=?", (row['message_id'],))
                    except Exception as delivery_error:
                        with store.db:
                            store.db.execute("UPDATE inspection_jobs SET state='failed',error_kind=? WHERE message_id=?",
                                             (type(delivery_error).__name__,row['message_id']))
                        queue_failure(store,payload['message_id'])
                        receipt_wake.set()
                except Exception as exc:
                    with store.db:
                        store.db.execute("UPDATE inspection_jobs SET state='failed',error_kind=? WHERE message_id=?",
                                         (type(exc).__name__, row["message_id"]))
                    LOG.error("Inspection job failed: %s", type(exc).__name__)
                    queue_failure(store,payload['message_id'])
                    receipt_wake.set()
        finally:
            store.close()
    def notifications():
        store = connect_store()
        gateway = FeishuGateway(create_client(settings.app_id,settings.app_secret))
        try:
            while not stop.is_set():
                if deliver_notice(store,gateway):
                    work_wake.set()
                else:
                    receipt_wake.wait(0.25)
                    receipt_wake.clear()
        finally:
            store.close()
    def execute_tasks():
        import time
        store=connect_store()
        gateway=FeishuGateway(create_client(settings.app_id,settings.app_secret))
        executor=ExecutionWorker(store,gateway,settings)
        last_notice=0
        try:
            while not stop.is_set():
                try:
                    changed=executor.tick()
                    if time.time()-last_notice>=3:
                        notify_execution(store,gateway)
                        last_notice=time.time()
                except Exception as exc:
                    LOG.error('Execution worker failed: %s',type(exc).__name__)
                stop.wait(0.5)
        finally:
            store.close()
    execution_thread=threading.Thread(target=execute_tasks,name='call-execution',daemon=True)
    execution_thread.start()
    notices_thread = threading.Thread(target=notifications,name='receipt-worker',daemon=True)
    notices_thread.start()
    thread = threading.Thread(target=worker, name="inspection-worker", daemon=True)
    thread.start()
    def on_card(event):
        from lark_oapi.event.callback.model.p2_card_action_trigger import P2CardActionTriggerResponse
        data = json.loads(lark.JSON.marshal(event)).get('event') or {}
        actor = (data.get('operator') or {}).get('open_id')
        chat = (data.get('context') or {}).get('open_chat_id')
        value = (data.get('action') or {}).get('value') or {}
        store = None
        try:
            if actor not in settings.users or chat not in settings.chats:
                raise Clarification('你没有权限操作此任务。')
            store = connect_store()
            if value.get('stage') == 'definition':
                draft = act_on_definition(store, value.get('token',''), actor, chat, value.get('operation',''))
                work_wake.set()
                return P2CardActionTriggerResponse({'toast':{'type':'success','content':'任务定义已更新（未拨号）'},
                                                    'card':{'type':'raw','data':definition_card(draft)}})
            if value.get('stage') == 'execution':
                control_batch(store,value.get('batch_id',''),actor,chat,value.get('operation',''))
                return P2CardActionTriggerResponse({'toast':{'type':'success','content':'任务控制已保存，当前电话不会被挂断'},
                    'card':{'type':'raw','data':batch_card(store,value['batch_id'])}})
            if value.get('operation') in ('execute_mock','execute_live'):
                approve_execution(store,value.get('token',''),actor,chat,value['operation'],settings)
                preview=dict(store.db.execute('SELECT * FROM roster_previews WHERE token=?',(value['token'],)).fetchone())
            else:
                preview = act_on_preview(store, value.get('token',''), actor, chat, value.get('operation',''))
            page = value.get('page',0)
            if not isinstance(page, int):
                page = 0
            return P2CardActionTriggerResponse({'toast':{'type':'success','content':('任务已入队' if value.get('operation') in ('execute_mock','execute_live') else '预览已更新（未拨号）')},
                                               'card':{'type':'raw','data':preview_card(preview,page)}})
        except Clarification as exc:
            return P2CardActionTriggerResponse({'toast':{'type':'error','content':str(exc)}})
        except Exception as exc:
            LOG.error('Preview action failed: %s',type(exc).__name__)
            return P2CardActionTriggerResponse({'toast':{'type':'error','content':'操作未能确认，请查看任务进度，勿重复发起外呼。'}})
        finally:
            if store:
                store.close()
    handler = (lark.EventDispatcherHandler.builder("", "").register_p2_im_message_receive_v1(on_message)
               .register_p2_card_action_trigger(on_card).build())
    class InspectionClient(lark.ws.Client):
        async def _connect(self):
            await super()._connect()
            print('Feishu roster-preview listener connected. Waiting for an authorized @message with explicit filters and the bound table link.', flush=True)
    try:
        InspectionClient(settings.app_id, settings.app_secret, event_handler=handler,
                       log_level=lark.LogLevel.ERROR).start()
    except KeyboardInterrupt:
        print('Feishu listener stopped.', flush=True)
    finally:
        stop.set()
        receipt_wake.set()
        work_wake.set()
        thread.join(timeout=5)
        notices_thread.join(timeout=5)
        execution_thread.join(timeout=5)
