"""Review-first output columns; reconcile uncertain creation before retrying."""
import hashlib
import json
from .preview import Clarification

PROTECTED={'联系人','电话号码','允许电话联系','禁止联系','授权来源','数据模式','外呼状态','最近任务编号'}

def plan_output_columns(definition,fields):
    protected=PROTECTED|{c[0] for c in definition['conditions']}|set(definition.get('context_fields',[]))
    for f in definition['result_fields']:
        matches=[c for c in fields if c['field_name']==f['label']]
        f.pop('column_issue',None)
        if f['label'] in protected:
            f.update(column_action='blocked',column_issue='来源或系统列不能作为业务输出',target_field_id=None)
        elif len(matches)>1:
            f.update(column_action='blocked',column_issue='同名列不唯一',target_field_id=None)
        elif not matches:f.update(column_action='create',target_field_id=None)
        else:
            col=matches[0]
            compatible=col['type']==1 or f['type']=='enum' and col['type']==3 and set(f['options'])<=set(col.get('options',[]))
            if compatible:f.update(column_action='reuse',target_field_id=col['field_id'],target_field_type=col['type'],target_field_options=col.get('options',[]))
            else:f.update(column_action='blocked',target_field_id=None,column_issue='同名列类型或枚举不兼容，请指定新列名；不改动原列')
    return definition

def ensure_output_columns(store,gateway,ref,token):
    row=store.db.execute("SELECT definition FROM task_definitions WHERE token=? AND state='confirmed'",(token,)).fetchone()
    if not row:raise Clarification('任务及建列尚未确认，不会创建输出列。')
    definition=json.loads(row['definition']);approved={f['key']:dict(f) for f in definition['result_fields']}
    fields=gateway.fields(ref);plan_output_columns(definition,fields)
    if any(f['column_action']=='blocked' for f in definition['result_fields']):
        raise Clarification('输出列存在冲突：'+'；'.join(f['label']+'：'+f['column_issue'] for f in definition['result_fields'] if f['column_action']=='blocked'))
    store.db.execute('CREATE TABLE IF NOT EXISTS output_column_operations (operation_id TEXT PRIMARY KEY,definition_token TEXT,state TEXT,field_id TEXT)');store.db.commit()
    for f in definition['result_fields']:
        before=approved[f['key']]
        if before.get('target_field_id') and f['target_field_id']!=before['target_field_id']:
            raise Clarification('输出列标识已改变，请重新确认，不会替换原列。')
        operation=hashlib.sha256(json.dumps([ref.app_token,ref.table_id,f['label'],f['type'],f['options']],ensure_ascii=False).encode()).hexdigest()
        if f['column_action']=='create':
            if before.get('column_action')!='create':raise Clarification('输出列消失或未授权创建，请重新确认。')
            prior=store.db.execute('SELECT * FROM output_column_operations WHERE operation_id=?',(operation,)).fetchone()
            if prior and (prior['state']!='rejected' or prior['definition_token']==token):
                raise Clarification('新增列状态需要核对，尚未看到对应列；未重试建列或拨号。')
            with store.db:store.db.execute('INSERT OR REPLACE INTO output_column_operations VALUES (?,?,?,NULL)',(operation,token,'submitting'))
            try:gateway.create_field(ref,f['label'],3 if f['type']=='enum' else 1,f['options'],operation)
            except Exception as exc:
                with store.db:store.db.execute('UPDATE output_column_operations SET state=? WHERE operation_id=?',('rejected' if getattr(exc,'code',None) is not None else 'uncertain',operation))
                raise Clarification('新增输出列“'+f['label']+'”未完成，请核对应用新增字段权限及该表管理权限。不会继续拨号；已创建的列保留，不自动删除。') from None
            fields=gateway.fields(ref);plan_output_columns(definition,fields)
            if f['column_action']!='reuse':raise Clarification('新增列尚未核对成功，不会继续拨号或重复建列。')
        if store.db.execute('SELECT 1 FROM output_column_operations WHERE operation_id=?',(operation,)).fetchone():
            with store.db:store.db.execute('UPDATE output_column_operations SET state=?,field_id=? WHERE operation_id=?',('complete',f['target_field_id'],operation))
    with store.db:
        changed=store.db.execute("UPDATE task_definitions SET definition=? WHERE token=? AND state='confirmed'",(json.dumps(definition,ensure_ascii=False),token)).rowcount
        if not changed:raise Clarification('任务状态已变化，停止名单生成。')
    return definition,fields
