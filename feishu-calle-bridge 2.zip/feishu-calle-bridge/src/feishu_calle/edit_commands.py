"""Visible text labels scope an edit; these are not native Feishu slash commands."""
import re


def normalize_edit_request(text):
    clean=re.sub(r'@_user_\d+|<at\b[^>]*>.*?</at>','',text).strip()
    clean=re.sub(r'^任务\s*[a-f0-9]{8}\s*','',clean)
    match=re.fullmatch(r'(?:修改)?(目的|筛选|结果)\s*[:：]\s*(.+)',clean,re.S)
    if not match:return text
    prefix={'目的':'任务目的改为：','筛选':'筛选条件改为：','结果':'结果字段修改为：'}[match[1]]
    return prefix+match[2]
