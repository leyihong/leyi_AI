"""One-time receive-only pairing through an explicitly shared random code."""
import asyncio
import json
import os
from pathlib import Path
import re
import secrets
import signal
import threading
from .setup import load_local_env, SetupFailure


def pairing_target(data: dict, code: str, bot_id: str) -> tuple[str, str] | None:
    event = data.get('event') or {}
    sender, message = event.get('sender') or {}, event.get('message') or {}
    user_id = (sender.get('sender_id') or {}).get('open_id')
    chat_id = message.get('chat_id')
    if sender.get('sender_type') != 'user' or message.get('chat_type') != 'group' or message.get('message_type') != 'text':
        return None
    mentions = message.get('mentions') or []
    if not any((m.get('id') or {}).get('open_id') == bot_id for m in mentions):
        return None
    try:
        text = json.loads(message.get('content', '{}'))['text']
    except (ValueError, KeyError, TypeError):
        return None
    for mention in mentions:
        key = mention.get('key')
        if key:
            text = text.replace(key, '')
    if text.strip() != code or not re.fullmatch(r'ou_[A-Za-z0-9]+', user_id or '') or not re.fullmatch(r'oc_[A-Za-z0-9]+', chat_id or ''):
        return None
    return chat_id, user_id


def save_target(path: Path, chat: str, user: str) -> None:
    # Pair only an unconfigured instance, never silently replace existing permissions.
    content = path.read_text()
    for name in ('FEISHU_ALLOWED_CHAT_IDS', 'FEISHU_ALLOWED_USER_IDS'):
        value = os.environ.get(name, '')
        if value:
            raise SetupFailure('Pairing is only available before chat/user bindings are configured')
    lines = [line for line in content.splitlines()
             if not re.match(r'\s*(?:export\s+)?FEISHU_ALLOWED_(CHAT|USER)_IDS=', line)]
    lines.extend([f'FEISHU_ALLOWED_CHAT_IDS={chat}', f'FEISHU_ALLOWED_USER_IDS={user}'])
    temporary = path.with_name('.env.pairing.tmp')
    descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w') as output:
        output.write('\n'.join(lines) + '\n')
    temporary.replace(path)


def main() -> None:
    import lark_oapi as lark
    path = Path('.env')
    load_local_env(path)
    app_id, secret = os.environ.get('FEISHU_APP_ID'), os.environ.get('FEISHU_APP_SECRET')
    bot_id = os.environ.get('FEISHU_BOT_OPEN_ID')
    if not app_id or not secret or not bot_id:
        raise SetupFailure('Verify app credentials and bot identity first')
    if os.environ.get('FEISHU_ALLOWED_CHAT_IDS') or os.environ.get('FEISHU_ALLOWED_USER_IDS'):
        raise SetupFailure('Pairing refused: chat/user permissions already configured')
    code = 'PAIR-' + secrets.token_hex(8).upper()
    done = threading.Event()
    lock = threading.Lock()
    def on_message(event):
        with lock:
            if done.is_set():
                return
            payload = json.loads(lark.JSON.marshal(event))
            target = pairing_target(payload, code, bot_id)
            if not target:
                message = (payload.get('event') or {}).get('message') or {}
                mentions = message.get('mentions') or []
                print('Message event received; pairing not matched. ' + json.dumps({
                    'is_group': message.get('chat_type') == 'group',
                    'is_text': message.get('message_type') == 'text',
                    'mentions_this_bot': any((m.get('id') or {}).get('open_id') == bot_id for m in mentions),
                }), flush=True)
            if target:
                save_target(path, *target)
                done.set()
                print('Pairing complete. Group/user IDs saved locally; values hidden.', flush=True)
                # Let the SDK acknowledge the event before interrupting its runner.
                asyncio.get_running_loop().call_later(0.5, os.kill, os.getpid(), signal.SIGINT)
    handler = lark.EventDispatcherHandler.builder('', '').register_p2_im_message_receive_v1(on_message).build()
    timer = threading.Timer(600, lambda: os.kill(os.getpid(), signal.SIGINT))
    timer.daemon = True
    print(f'In your private test group, @mention this bot and send exactly: {code}', flush=True)
    print('Pairing expires in 10 minutes. No message will be sent and no table or phone API will be called.', flush=True)
    timer.start()
    class PairingClient(lark.ws.Client):
        async def _connect(self):
            await super()._connect()
            print('Feishu long connection established; waiting for a matching group message.', flush=True)
    try:
        PairingClient(app_id, secret, event_handler=handler, log_level=lark.LogLevel.ERROR).start()
    except KeyboardInterrupt:
        if not done.is_set():
            print('Pairing stopped without changing permissions.', flush=True)
    finally:
        timer.cancel()


if __name__ == '__main__':
    main()
