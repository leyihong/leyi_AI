"""Feishu table-backed CALL-E integration."""
