"""Explicit result edits inherit one actor-owned pending definition, never start calls."""
import hashlib
import json
import re
import time
from .definitions import propose_definition, act_on_definition
from .preview import Clarification


def task_code(row):
    return hashlib.sha256(row['message_id'].encode()).hexdigest()[:8]


def parse_output_edit(text):
    # Deliberately accept a small visible grammar, not arbitrary natural-language mutation.
    text = re.sub(r'@_user_\d+|<at\b[^>]*>.*?</at>', '', text)
    text = re.sub(r'^\s*(?:修改)?结果\s*[:：]', '', text.strip())
    updates = []
    system_notes = []
    for raw in text.splitlines():
        line = raw.strip().lstrip('•·-* ').strip()
        if not line or re.fullmatch(r'(?:请)?修改(?:回填)?结果字段[：:]?', line):
            continue
        part = re.fullmatch(r'([^:：=＝]+)\s*[:：=＝]\s*(.+)', line)
        if not part:
            raise Clarification('修改结果字段可直接发送“字段名：选项/选项”，每个字段一行；不必重发链接。')
        label, spec = (p.strip() for p in part.groups())
        spec = re.sub(r'[;；]\s*匹配已有输出列\s*$', '', spec).strip()
        if label in ('外呼状态', '外呼任务', '最近任务编号'):
            system_notes.append(label)
            continue
        if spec in ('文本', '简短文本'):
            spec = '文本'
        elif '/' not in spec:
            raise Clarification('枚举请用 / 分隔；文本字段可写“简短文本”。不会自动改动任务目的或筛选条件。')
        updates.append((label, spec))
    if not updates:
        raise Clarification('没有识别到业务结果字段修改。外呼状态和任务编号由系统维护，独立于业务结果枚举。')
    if len({label for label,_ in updates}) != len(updates):
        raise Clarification('同一字段出现多次，请每个字段只写一行。')
    return updates, system_notes


def revise_pending_definition(store, payload):
    existing = store.db.execute('SELECT * FROM task_definitions WHERE message_id=?',(payload['message_id'],)).fetchone()
    if existing:
        return dict(existing)
    rows = store.db.execute("SELECT * FROM task_definitions WHERE actor=? AND chat_id=? AND state='pending' AND expires_at>? ORDER BY rowid DESC",
                            (payload['actor'],payload['chat_id'],time.time())).fetchall()
    if not rows:
        raise Clarification('没有可修改的待确认任务；请先发送任务目的、筛选条件和表格链接。')
    if len(rows) != 1:
        raise Clarification('有多个待确认任务，请取消其他任务后再修改，以免改错任务。')
    previous = dict(rows[0])
    updates, system_notes = parse_output_edit(payload['text'])
    old = json.loads(previous['definition'])
    known = {f['label'] for f in old['result_fields']}
    replacements = dict(updates)
    specs = []
    original_fields = []
    for f in old['result_fields']:
        spec = replacements.get(f['label'], '文本' if f['type']=='text' else '/'.join(f['options']))
        specs.append(f['label']+'='+spec)
        # Keep the already inspected mapping, not arbitrary columns from the message.
        if f['target_field_id']:
            original_fields.append({'field_name':f['label'], 'field_id':f['target_field_id'],
                                    'type':f.get('target_field_type',1),
                                    'options':f.get('target_field_options',f.get('options',[]))})
    original = json.loads(previous['payload'])
    specs.extend(label+'='+spec for label,spec in updates if label not in known)
    source = re.split(r'结果\s*[:：]',original['text'],maxsplit=1)[0]
    source = re.sub(r'https://[^\s<>]+', '',source).strip()
    # Source columns are needed to validate the original, unchanged filter.
    original_fields.extend({'field_name':name,'field_id':'source','type':1}
                           for name,_,_ in old['conditions'])
    definition = propose_definition(source+'\n结果：'+'；'.join(specs), original_fields)
    definition['revision'] = old['revision']+1
    definition['context_fields'] = old.get('context_fields',[])
    definition['disclosure'] = old.get('disclosure',definition['disclosure'])
    definition['mode'] = old.get('mode','preview_only')
    definition['proposal_source'] = '已按群内补充只修改结果字段；原任务、表格和筛选条件保持。'
    if system_notes:
        definition['proposal_source'] += ' 外呼状态/外呼任务属于系统字段，未作为业务结果枚举修改。'
    # Preserve the actual resource-bearing source request for scanning, with updated results.
    inherited = {**payload, 'text': re.split(r'结果\s*[:：]',original['text'],maxsplit=1)[0]+'\n结果：'+'；'.join(specs)}
    with store.db:
        current = store.db.execute('SELECT state,expires_at FROM task_definitions WHERE token=?',(previous['token'],)).fetchone()
        if not current or current['state'] != 'pending' or current['expires_at']<=time.time():
            raise Clarification('任务状态已变化，请查看最新卡片后再修改。')
        # Insert and supersede share one transaction; no stale card can confirm the old version.
        store.db.execute("UPDATE task_definitions SET state='superseded' WHERE token=?",(previous['token'],))
        token = __import__('secrets').token_urlsafe(24)
        store.db.execute('INSERT INTO task_definitions VALUES (?,?,?,?,?,?,?,?)',
                         (token,payload['message_id'],payload['chat_id'],payload['actor'],
                          json.dumps(inherited,ensure_ascii=False),json.dumps(definition,ensure_ascii=False),
                          'pending',time.time()+900))
    return dict(store.db.execute('SELECT * FROM task_definitions WHERE token=?',(token,)).fetchone())


def confirm_from_text(store, payload):
    text = re.sub(r'@_user_\d+|<at\b[^>]*>.*?</at>', '', payload['text']).strip()
    match = re.fullmatch(r'确认定义\s+([0-9a-f]{8})', text)
    if not match:
        return None
    rows = store.db.execute("SELECT * FROM task_definitions WHERE actor=? AND chat_id=? AND state IN ('pending','confirmed')",
                            (payload['actor'],payload['chat_id'])).fetchall()
    matches = [row for row in rows if task_code(row) == match[1]]
    if len(matches) != 1:
        raise Clarification('该确认编号已失效或不属于你的当前任务，请使用最新卡片上的编号。')
    return act_on_definition(store,matches[0]['token'],payload['actor'],payload['chat_id'],'confirm')
