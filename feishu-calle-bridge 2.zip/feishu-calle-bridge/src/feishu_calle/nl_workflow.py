"""Local-language dialogue resolution and atomic, review-only task revisions."""
from copy import deepcopy
import json
import re
import secrets
import time
from .conversation import task_code
from .definitions import save_definition
from .natural_language import ModelClarification
from .preview import Clarification
from .recipient_scope import recipient_edit,retain_recipient_selection
from .audit import record_audit
from .edit_commands import normalize_edit_request


def init_nl_workflow(store):
    store.db.execute('''CREATE TABLE IF NOT EXISTS nl_clarifications (
        actor TEXT NOT NULL, chat_id TEXT NOT NULL, source_payload TEXT NOT NULL,
        previous_token TEXT, request_text TEXT NOT NULL, question TEXT NOT NULL,
        expires_at REAL NOT NULL, PRIMARY KEY(actor,chat_id))''')
    store.db.commit()


def _has_execution(store,token):
    return store.db.execute("SELECT 1 FROM execution_batches b JOIN roster_previews p ON p.token=b.preview_token WHERE json_extract(p.snapshot,'$.definition_token')=?",(token,)).fetchone() is not None


def resolve_nl_input(store,payload):
    if re.search(r'https://',payload['text']):
        return {'source':deepcopy(payload),'previous':None,'request':payload['text']}
    target=re.search(r'任务\s*([a-f0-9]{8})\b',payload['text'])
    context=store.db.execute('SELECT * FROM nl_clarifications WHERE actor=? AND chat_id=? AND expires_at>?',
                            (payload['actor'],payload['chat_id'],time.time())).fetchone()
    if context and not target:
        previous=None
        if context['previous_token']:
            row=store.db.execute('SELECT * FROM task_definitions WHERE token=?',(context['previous_token'],)).fetchone()
            if not row or row['state'] not in ('pending','confirmed') or row['expires_at']<=time.time() or _has_execution(store,row['token']):
                raise Clarification('原任务状态已经变化，请使用最新任务卡重新提出修改。')
            previous=dict(row)
        request=context['request_text']+'\n待澄清问题：'+context['question']+'\n用户补充：'+payload['text']
        if len(request)>12000:raise Clarification('补充对话过长，请重新描述本次任务。')
        return {'source':json.loads(context['source_payload']),'previous':previous,'request':request}
    rows=store.db.execute("SELECT * FROM task_definitions WHERE actor=? AND chat_id=? AND state IN ('pending','confirmed') AND expires_at>? ORDER BY rowid DESC",
                           (payload['actor'],payload['chat_id'],time.time())).fetchall()
    candidates=[dict(r) for r in rows if not _has_execution(store,r['token']) and (not target or task_code(r)==target[1])]
    if not target:
        pending=[r for r in candidates if r['state']=='pending']
        if pending:candidates=pending
    if len(candidates)!=1:
        raise Clarification('请附上新任务的表格链接，或使用“任务 八位编号”指定要修改的待确认任务。')
    return {'source':json.loads(candidates[0]['payload']),'previous':candidates[0],'request':payload['text']}


def propose_nl_task(store,planner,payload,context,fields):
    # Replay skips the model and returns the saved version.
    existing=store.db.execute('SELECT * FROM task_definitions WHERE message_id=?',(payload['message_id'],)).fetchone()
    if existing:return dict(existing)
    previous=context['previous']
    old=json.loads(previous['definition']) if previous else None
    request=normalize_edit_request(context['request']) if old else context['request']
    record_audit(store,payload,'input',{'request':context['request'],'normalized_request':request,
        'previous_revision':old.get('revision') if old else None,'previous_task':task_code(previous) if previous else None})
    try:
        definition=recipient_edit(request,old,fields)
        if definition is not None:
            record_audit(store,payload,'recipient.selection',{'selection':definition['recipient_selection'],'execution_authorized':False})
        else:
            if planner is None:raise ModelClarification('这条修改没有识别为单人选择。规则模式可使用“对象：完整姓名或记录编号”，其他自然语言修改需要启用本地模型。')
            definition=planner.propose(request,fields,previous=old,
                audit=lambda stage,details:record_audit(store,payload,stage,details))
        retain_recipient_selection(definition,fields)
    except ModelClarification as exc:
        record_audit(store,payload,'clarification',{'message':str(exc)})
        with store.db:
            store.db.execute('INSERT OR REPLACE INTO nl_clarifications VALUES (?,?,?,?,?,?,?)',
                (payload['actor'],payload['chat_id'],json.dumps(context['source'],ensure_ascii=False),
                 previous['token'] if previous else None,context['request'],str(exc),time.time()+900))
        raise
    except Clarification as exc:
        record_audit(store,payload,'rejected',{'message':str(exc)})
        raise
    definition['trace_code']=task_code(payload)
    definition['review_diff']={key:{'before':old.get(key) if old else None,'after':definition.get(key)}
        for key in ('purpose','conditions','exclude_duplicates','result_fields','recipient_selection')
        if old is None or old.get(key)!=definition.get(key)}
    inherited={**payload,'text':context['source']['text'],'intent_request':context['request']}
    if previous:
        with store.db:
            latest=store.db.execute('SELECT state,definition,expires_at FROM task_definitions WHERE token=?',(previous['token'],)).fetchone()
            if not latest or latest['expires_at']<=time.time() or latest['state']!=previous['state'] or latest['definition']!=previous['definition'] or _has_execution(store,previous['token']):
                record_audit(store,payload,'rejected',{'message':'原任务在解析期间变化或过期，未保存修改'})
                raise Clarification('原任务状态已变化，本次修改未应用。请查看最新任务卡。')
            token=secrets.token_urlsafe(24)
            store.db.execute("UPDATE task_definitions SET state='superseded' WHERE token=?",(previous['token'],))
            # Previously generated rosters cannot execute under a superseded definition.
            store.db.execute("UPDATE roster_previews SET state='invalidated' WHERE json_extract(snapshot,'$.definition_token')=? AND state IN ('pending','confirmed')",(previous['token'],))
            store.db.execute('INSERT INTO task_definitions VALUES (?,?,?,?,?,?,?,?)',
                (token,payload['message_id'],payload['chat_id'],payload['actor'],json.dumps(inherited,ensure_ascii=False),
                 json.dumps(definition,ensure_ascii=False),'pending',time.time()+900))
            row=dict(store.db.execute('SELECT * FROM task_definitions WHERE token=?',(token,)).fetchone())
    else:
        definition['mode']=context.get('mode','preview_only')
        row=save_definition(store,inherited,definition)
    with store.db:store.db.execute('DELETE FROM nl_clarifications WHERE actor=? AND chat_id=?',(payload['actor'],payload['chat_id']))
    record_audit(store,payload,'proposal.saved',{'revision':definition['revision'],'diff':definition['review_diff'],
                                               'state':'pending','execution_authorized':False})
    return row
