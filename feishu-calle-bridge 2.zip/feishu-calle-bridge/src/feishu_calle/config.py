"""Environment configuration without secret-bearing diagnostics."""
from dataclasses import dataclass, field
from pathlib import Path
from collections.abc import Mapping


@dataclass(frozen=True)
class Settings:
    mode: str
    database: Path
    app_id: str
    app_secret: str = field(repr=False)
    api_key: str = field(repr=False)
    chats: tuple[str, ...]
    users: tuple[str, ...]

    allowed_phones: tuple[str, ...] = field(default=(), repr=False)
    writeback: bool = False
    result_poll_timeout_seconds: int = 300
    result_poll_max_reads: int = 20
    nlp_engine: str = 'rules'
    nlp_model: str = 'qwen3:4b'
    allow_automated_test_line: bool = False

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> "Settings":
        mode = env.get("BRIDGE_MODE", "mock")
        if mode not in {"mock", "live"}:
            raise ValueError("BRIDGE_MODE must be mock or live")
        poll_timeout = int(env.get('BRIDGE_RESULT_TIMEOUT_SECONDS', '300'))
        poll_limit = int(env.get('BRIDGE_RESULT_MAX_READS', '20'))
        if poll_timeout <= 0 or poll_limit <= 0:
            raise ValueError('Result query limits must be positive')
        engine=env.get('BRIDGE_NLP_ENGINE','rules')
        if engine not in ('rules','ollama'):raise ValueError('Unsupported language engine')
        return cls(
            mode, Path(env.get("BRIDGE_DATABASE", "var/bridge.sqlite3")),
            env.get("FEISHU_APP_ID", ""), env.get("FEISHU_APP_SECRET", ""),
            env.get("CALLE_API_KEY", ""),
            tuple(x.strip() for x in env.get("FEISHU_ALLOWED_CHAT_IDS", "").split(",") if x.strip()),
            tuple(x.strip() for x in env.get("FEISHU_ALLOWED_USER_IDS", "").split(",") if x.strip()),
            tuple(x.strip() for x in env.get("CALLE_ALLOWED_TEST_PHONES", "").split(",") if x.strip()),
            env.get("BRIDGE_WRITEBACK", "false").lower() == "true",
            poll_timeout, poll_limit, engine, env.get('BRIDGE_NLP_MODEL','qwen3:4b'),
            env.get('BRIDGE_ALLOW_AUTOMATED_TEST_LINE','false').lower()=='true',
        )

    def missing_live_settings(self) -> list[str]:
        values = {
            "FEISHU_APP_ID": self.app_id, "FEISHU_APP_SECRET": self.app_secret,
            "CALLE_API_KEY": self.api_key, "FEISHU_ALLOWED_CHAT_IDS": self.chats,
            "FEISHU_ALLOWED_USER_IDS": self.users,
        }
        return [name for name, value in values.items() if not value]
