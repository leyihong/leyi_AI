"""Deterministic view-scoped roster previews. Confirmation never creates a call."""
from collections import Counter
import json
import re
import secrets
import time


class Clarification(ValueError):
    pass


def text_value(value) -> str:
    if isinstance(value, list):
        return ''.join(text_value(part) for part in value)
    if isinstance(value, dict):
        return str(value.get('text', ''))
    if value is None:
        return ''
    if isinstance(value, bool):
        return '是' if value else '否'
    return str(value)


def parse_selection(text: str, fields: list[dict]) -> tuple[list[tuple[str, str, str]], bool]:
    # Require an explicit filter clause until the LLM proposal stage is implemented.
    match = re.search(r'筛选\s*[:：]\s*(.+?)(?=\s*(?:目的|结果|https://)\s*[:：]?|$)', text, re.S)
    if not match:
        raise Clarification('请明确筛选条件，例如：筛选：活动名称=模拟产品交流会；出席意向=待定。支持 = 和 !=，多个条件用分号分隔。')
    known = {field['field_name'] for field in fields}
    result = []
    exclude_duplicates = False
    for clause in re.split(r'[;；]', match[1].strip().rstrip('。；;')):
        clause = clause.strip()
        if clause in ('无重复号码的联系人', '重复号码保留一个', '重复号码保留一条'):
            exclude_duplicates = True
            continue
        if clause == '允许电话联系':
            clause = '允许电话联系=是'
        part = re.fullmatch(r'\s*(.+?)\s*(!=|=|等于|为)\s*(.+?)\s*', clause)
        if not part:
            raise Clarification('筛选条件无法确定，请使用“字段=值”，多个条件用分号分隔。')
        name, operator, value = part.groups()
        name, value = name.strip(), value.strip().strip('"“”')
        if name not in known:
            raise Clarification('筛选字段不在表格中，请使用表格的完整列名。')
        result.append((name, '!=' if operator == '!=' else '=', value))
    return result, exclude_duplicates


def parse_conditions(text: str, fields: list[dict]) -> list[tuple[str, str, str]]:
    conditions, exclude_duplicates = parse_selection(text, fields)
    if exclude_duplicates:
        raise Clarification('重复号码策略需要通过完整名单筛选流程处理。')
    return conditions


def build_roster(records: list[dict], conditions: list[tuple[str, str, str]], *, exclude_duplicates: bool = False) -> dict:
    exclusions = Counter()
    candidates = []
    for record in records:
        fields = record['fields']
        if not all((text_value(fields.get(name)) != value if op == '!=' else text_value(fields.get(name)) == value)
                   for name, op, value in conditions):
            exclusions['不符合筛选条件'] += 1
            continue
        consent = text_value(fields.get('允许电话联系'))
        if consent not in ('是', 'true', 'True') or not text_value(fields.get('授权来源')):
            exclusions['缺少联系授权'] += 1
            continue
        if text_value(fields.get('禁止联系')) in ('是', 'true', 'True'):
            exclusions['禁止联系'] += 1
            continue
        phone = text_value(fields.get('电话号码')).strip()
        if not re.fullmatch(r'\+[1-9][0-9]{7,14}', phone, re.ASCII):
            exclusions['号码缺失或格式无效'] += 1
            continue
        candidates.append({'record_id': record['record_id'],
            'label': text_value(fields.get('测试记录编号')) or record['record_id'],
            'name': text_value(fields.get('联系人')), 'phone': phone,
            'data_mode': text_value(fields.get('数据模式'))})
    counts = Counter(item['phone'] for item in candidates)
    for item in candidates:
        item['duplicate'] = counts[item['phone']] > 1
    if exclude_duplicates:
        seen = set()
        unique = []
        for item in candidates:
            if item['phone'] in seen:
                exclusions['重复号码（保留第一条）'] += 1
                continue
            seen.add(item['phone'])
            item['duplicate'] = False
            unique.append(item)
        candidates = unique
    return {'exclude_duplicates': exclude_duplicates, 'scanned': len(records), 'conditions': conditions, 'candidates': candidates,
            'excluded': dict(exclusions), 'duplicates': sum(item['duplicate'] for item in candidates)}


def init_previews(store) -> None:
    store.db.execute('''CREATE TABLE IF NOT EXISTS roster_previews (
        message_id TEXT PRIMARY KEY, token TEXT UNIQUE NOT NULL, actor TEXT NOT NULL,
        chat_id TEXT NOT NULL, snapshot TEXT NOT NULL, state TEXT NOT NULL,
        expires_at REAL NOT NULL)''')
    store.db.commit()


def save_preview(store, payload: dict, snapshot: dict) -> dict:
    with store.db:
        store.db.execute('INSERT OR IGNORE INTO roster_previews VALUES (?,?,?,?,?,?,?)',
            (payload['message_id'], secrets.token_urlsafe(24), payload['actor'], payload['chat_id'],
             json.dumps(snapshot, ensure_ascii=False), 'pending', time.time() + 900))
    return dict(store.db.execute('SELECT * FROM roster_previews WHERE message_id=?', (payload['message_id'],)).fetchone())


def preview_card(preview: dict, page: int = 0) -> dict:
    data = json.loads(preview['snapshot'])
    people = data['candidates']
    page_count = max(1, (len(people) + 9) // 10)
    page = max(0, min(page, page_count - 1))
    lines = [f"视图内读取 {data['scanned']} 条；匹配且通过基础检查 {len(people)} 人。",
             '筛选：' + '；'.join(f'{name}{op}{value}' for name, op, value in data['conditions']),
             '排除：' + ('；'.join(f'{key} {count} 条' for key, count in data['excluded'].items()) or '无'),
             f'名单第 {page + 1}/{page_count} 页；确认范围为全部名单。']
    if data.get('exclude_duplicates'):
        lines.insert(2, '同号策略：同一号码只保留视图读取顺序中的第一条，其他记录去重；本次确认以此名单快照为准。')
    if data.get('purpose'):
        lines.insert(1, ('已确认任务目的：' if data.get('definition_token') else '任务目的（待后续任务定义确认）：') + data['purpose'])
    for item in people[page * 10:(page + 1) * 10]:
        phone = item['phone']
        lines.append(f"{item['label']}  {item['name']}  {phone[:2]}{'*'*(len(phone)-4)}{phone[-2:]}" + ('【同号待处理】' if item['duplicate'] else ''))
    if data['duplicates']:
        lines.append('存在重复号码，请调整条件排除重复记录后重新发起；不会自动合并或多次联系。')
    if data.get('result_fields'):
        lines.append('已确认结果字段：' + '、'.join(f['label'] for f in data['result_fields']))
    execution=data.get('execution')
    if execution:
        mode=execution['mode']
        lines.append('执行模式：' + ('真实外呼（会拨打名单中的号码）' if mode=='live' else '模拟执行（不会拨号，业务答复仅为模拟未知值）'))
        if execution.get('authorized_provider_test_bot'):lines.append('测试例外：本次含固定美国 AI 自动接待测试号，已明确启用非真人测试线路的联系窗口例外；不适用于其他号码。')
        lines.append('结果去向：' + ('回填本卡已确认的原表输出列（读后写，非原子并发保护）' if execution['writeback'] else '仅本地保存，不修改飞书表格'))
        if execution.get('recontact_review'):lines.append('再次联系确认：该记录上一通电话已结束且失败。点击下方按钮将额外授权再拨一通；不会自动重拨。')
        if execution.get('recontact_blocked'):lines.append(execution['recontact_blocked'])
        lines.append('最多运行 30 分钟；真实电话仅在联系人当地 08:00–21:00 开始，超窗跳过，不自动重拨。')
        lines.append(f"每人仅拨一次；首次结果最多查询 {execution.get('poll_max_reads',20)} 次、等待 {execution.get('poll_timeout_seconds',300)} 秒，先到上限即停止本轮，不自动恢复。")
        lines.append('如果对方明确要求不再联系，会在本实例保存禁止联系标记。')
        for person in people[page*10:(page+1)*10]:
            if person.get('context'):
                lines.append(person['label']+' 的获准背景：'+'；'.join(f'{k}={v}' for k,v in person['context'].items()))
        if not data.get('execution_ready'):
            lines.append('结果列缺失、不兼容或枚举不匹配，暂不能执行；不会自动新增列或选项。')
    else:
        lines.append('当前为名单预览开发阶段，确认仅保存名单，不会拨号；真实外呼与回填仍在开发。')
    lines.append('状态：' + {'pending': '等待确认', 'confirmed': '名单已确认（尚未拨号）', 'cancelled': '预览已取消', 'execution_approved': '已入队，请查看任务进度卡'}.get(preview['state'], preview['state']))
    actions = []
    if preview['state'] == 'pending':
        if people and not data['duplicates'] and (not execution or data.get('execution_ready')):
            operation = ('execute_live' if execution['mode']=='live' else 'execute_mock') if execution else 'confirm'
            label = ('确认并真实外呼' if execution['mode']=='live' else '确认并模拟执行') if execution else '确认名单（不拨号）'
            if execution and execution.get('recontact_review'):label='确认再拨一通（真实外呼）'
            actions.append({'tag':'button', 'text':{'tag':'plain_text','content':label},
                'type':'primary','value':{'token':preview['token'],'operation':operation}})
        actions.append({'tag':'button','text':{'tag':'plain_text','content':'取消预览'},
                        'value':{'token':preview['token'],'operation':'cancel'}})
        for title, target in [('上一页', page-1), ('下一页',page+1)]:
            if 0 <= target < page_count:
                actions.append({'tag':'button','text':{'tag':'plain_text','content':title},
                    'value':{'token':preview['token'],'operation':'page','page':target}})
    elements = [{'tag':'div','text':{'tag':'plain_text','content':'\n'.join(lines)}}]
    if actions:
        elements.append({'tag':'action','actions':actions})
    return {'config':{'update_multi':True},'header':{'title':{'tag':'plain_text','content':'CALL-E：外呼名单预览'}},'elements':elements}


def act_on_preview(store, token: str, actor: str, chat: str, operation: str) -> dict:
    with store.db:
        row = store.db.execute('SELECT * FROM roster_previews WHERE token=?', (token,)).fetchone()
        if row is None or row['actor'] != actor or row['chat_id'] != chat or row['expires_at'] < time.time():
            raise Clarification('该预览已过期，或你无权操作。请重新发起。')
        snapshot = json.loads(row['snapshot'])
        if operation == 'confirm' and (snapshot['duplicates'] or not snapshot['candidates']):
            raise Clarification('请先处理重复号码或空名单。')
        if operation not in ('page', 'confirm', 'cancel'):
            raise Clarification('不支持的预览操作。')
        state = {'confirm':'confirmed','cancel':'cancelled'}.get(operation)
        if state and row['state'] == 'pending':
            store.db.execute("UPDATE roster_previews SET state=? WHERE token=? AND state='pending'", (state, token))
        elif state and row['state'] != state:
            raise Clarification('该预览已结束，请重新发起。')
        return dict(store.db.execute('SELECT * FROM roster_previews WHERE token=?', (token,)).fetchone())
