"""Explicit setup checks. Secrets remain local; no shell evaluation of .env."""
import os
from pathlib import Path
import re
import shlex
import httpx


class SetupFailure(RuntimeError):
    pass


def load_local_env(path: Path) -> None:
    for number, line in enumerate(path.read_text().splitlines(), 1):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        match = re.fullmatch(r'(?:export\s+)?([A-Z][A-Z0-9_]*)=(.*)', line)
        if not match:
            raise SetupFailure(f'Invalid environment assignment on line {number}')
        try:
            values = shlex.split(match[2], comments=True)
        except ValueError:
            raise SetupFailure(f'Invalid quoting on line {number}') from None
        if len(values) > 1:
            raise SetupFailure(f'Quote values containing spaces on line {number}')
        os.environ.setdefault(match[1], values[0] if values else '')


def save_bot_id(path: Path, bot_id: str) -> None:
    if not re.fullmatch(r'ou_[A-Za-z0-9]+', bot_id):
        raise SetupFailure('Feishu returned an invalid bot identifier')
    lines = path.read_text().splitlines()
    lines = [line for line in lines if not re.match(r'\s*(?:export\s+)?FEISHU_BOT_OPEN_ID=', line)]
    lines.append(f'FEISHU_BOT_OPEN_ID={bot_id}')
    path.write_text('\n'.join(lines) + '\n')
    path.chmod(0o600)


def verify_bot(app_id: str, app_secret: str) -> str:
    if not app_id or not app_secret:
        raise SetupFailure('FEISHU_APP_ID and FEISHU_APP_SECRET are required')
    try:
        with httpx.Client(timeout=20, follow_redirects=False) as client:
            response = client.post('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
                                   json={'app_id': app_id, 'app_secret': app_secret})
            if response.status_code != 200:
                raise SetupFailure(f'Credential check HTTP status: {response.status_code}')
            data = response.json()
            if data.get('code') != 0 or not data.get('tenant_access_token'):
                raise SetupFailure(f"Credential check failed (code={data.get('code')})")
            response = client.get('https://open.feishu.cn/open-apis/bot/v3/info',
                                  headers={'Authorization': f"Bearer {data['tenant_access_token']}"})
            if response.status_code != 200:
                raise SetupFailure(f'Bot check HTTP status: {response.status_code}')
            data = response.json()
            if data.get('code') != 0:
                raise SetupFailure(f"Bot check failed (code={data.get('code')})")
            bot = data.get('bot') or (data.get('data') or {}).get('bot') or {}
            bot_id = bot.get('open_id')
            if not isinstance(bot_id, str) or not re.fullmatch(r'ou_[A-Za-z0-9]+', bot_id):
                raise SetupFailure('No valid bot ID returned; check bot capability and app availability')
            return bot_id
    except (httpx.HTTPError, ValueError) as exc:
        raise SetupFailure(f'Feishu setup request failed: {type(exc).__name__}') from None
