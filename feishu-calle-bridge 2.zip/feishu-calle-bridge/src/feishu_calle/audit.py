"""Private structured decision evidence, not model chain of thought."""
import hashlib
import json
import re
import time


def redact(value):
    if isinstance(value,dict):
        return {k:('[已脱敏]' if re.search(r'api.?key|secret|token|authorization|phone|电话号码|credential',k,re.I) else redact(v)) for k,v in value.items()}
    if isinstance(value,list):return [redact(v) for v in value]
    if isinstance(value,tuple):return [redact(v) for v in value]
    if not isinstance(value,str):return value
    value=re.sub(r'https?://[^\s<>]+','[链接已脱敏]',value)
    value=re.sub(r'\+?[0-9][0-9 ()-]{6,}[0-9]','[号码已脱敏]',value)
    return re.sub(r'(?i)(?:Bearer\s+\S+|(?:api[_ -]?key|secret)\s*[:=]\s*\S+)','[凭证已脱敏]',value)


def init_audit(store):
    store.db.execute('''CREATE TABLE IF NOT EXISTS workflow_audit (
        id INTEGER PRIMARY KEY, trace_code TEXT NOT NULL, stage TEXT NOT NULL,
        details TEXT NOT NULL, created_at REAL NOT NULL)''')
    store.db.commit()


def record_audit(store,payload,stage,details):
    init_audit(store)
    code=hashlib.sha256(payload['message_id'].encode()).hexdigest()[:8]
    with store.db:store.db.execute('INSERT INTO workflow_audit(trace_code,stage,details,created_at) VALUES (?,?,?,?)',
                                  (code,stage,json.dumps(redact(details),ensure_ascii=False),time.time()))


def read_audit(store,code):
    if not re.fullmatch(r'[a-f0-9]{8}',code):raise ValueError('Use the eight-character task/trace code')
    init_audit(store)
    return [{'stage':r['stage'],'at':r['created_at'],'details':json.loads(r['details'])}
            for r in store.db.execute('SELECT * FROM workflow_audit WHERE trace_code=? ORDER BY id',(code,))]
