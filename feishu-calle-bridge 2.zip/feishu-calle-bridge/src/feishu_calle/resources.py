"""Strict Base-link parsing. User URLs are locators, never network destinations."""
from dataclasses import dataclass
import re
from urllib.parse import parse_qs, urlsplit


@dataclass(frozen=True)
class BaseRef:
    host: str
    app_token: str
    table_id: str
    view_id: str | None = None


@dataclass(frozen=True)
class WikiRef:
    host: str
    node_token: str
    table_id: str
    view_id: str | None = None


def parse_resource_link(value: str) -> BaseRef | WikiRef:
    url = urlsplit(value)
    host = url.hostname or ""
    if (url.scheme != "https" or url.username or url.password or url.port is not None
            or not (host == "feishu.cn" or host.endswith(".feishu.cn"))):
        raise ValueError("Use an HTTPS Feishu Base link without credentials or a port")
    match = re.fullmatch(r"/(base|wiki)/([A-Za-z0-9]+)/?", url.path)
    if not match:
        raise ValueError("Use a /base/ or /wiki/ table link; Sheets links are not supported")
    query = parse_qs(url.query, keep_blank_values=True)
    def identifier(key: str, prefix: str, required: bool) -> str | None:
        values = query.get(key, [])
        if not values and not required:
            return None
        if len(values) != 1 or not re.fullmatch(prefix + r"[A-Za-z0-9]+", values[0]):
            raise ValueError(f"The link must contain one valid {key} identifier")
        return values[0]
    table = identifier("table", "tbl", True)
    view = identifier("view", "vew", False)
    if match[1] == 'wiki':
        return WikiRef(host, match[2], table, view)
    return BaseRef(host, match[2], table, view)


def parse_base_link(value: str) -> BaseRef:
    ref = parse_resource_link(value)
    if not isinstance(ref, BaseRef):
        raise ValueError("Resolve the wiki node before using it as a Base reference")
    return ref
