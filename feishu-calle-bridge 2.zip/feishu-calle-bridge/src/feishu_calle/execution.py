"""Durable sequential execution, separate result/writeback recovery, no automatic redial."""
from collections import Counter
from dataclasses import asdict
from datetime import datetime
import hashlib
import json
import time
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from urllib.parse import urlencode
from .calle_api import CalleAPI, FakeCalls, CallFailure, call_request, validate_result
from .preview import Clarification, text_value, build_roster
from .resources import BaseRef


def init_execution(store):
    store.db.executescript('''
    CREATE TABLE IF NOT EXISTS execution_batches (
      id TEXT PRIMARY KEY, preview_token TEXT UNIQUE NOT NULL, actor TEXT NOT NULL, chat_id TEXT NOT NULL,
      mode TEXT NOT NULL, state TEXT NOT NULL, manifest TEXT NOT NULL, deadline REAL NOT NULL,
      notified_state TEXT, created_at REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS execution_items (
      id TEXT PRIMARY KEY, batch_id TEXT NOT NULL, record_id TEXT NOT NULL,
      state TEXT NOT NULL, person TEXT NOT NULL, response TEXT, output TEXT,
      error_kind TEXT, next_poll REAL NOT NULL DEFAULT 0, attempts INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS contact_suppression (phone_hash TEXT PRIMARY KEY, created_at REAL NOT NULL);
    ''')
    columns={r[1] for r in store.db.execute('PRAGMA table_info(execution_items)')}
    for name,kind in [('poll_count','INTEGER NOT NULL DEFAULT 0'),('poll_started_at','REAL')]:
        if name not in columns:store.db.execute(f'ALTER TABLE execution_items ADD COLUMN {name} {kind}')
    store.db.execute('CREATE TABLE IF NOT EXISTS recontact_uses(authorization_id TEXT PRIMARY KEY,batch_id TEXT UNIQUE NOT NULL)')
    store.db.execute('CREATE TABLE IF NOT EXISTS execution_notifications(batch_id TEXT PRIMARY KEY, message_id TEXT, digest TEXT)')
    had_terminal_table=store.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='execution_terminal_notices'").fetchone()
    store.db.execute('CREATE TABLE IF NOT EXISTS execution_terminal_notices(batch_id TEXT PRIMARY KEY, message_id TEXT)')
    if not had_terminal_table:
        # Do not broadcast historical completions when installing this migration.
        store.db.execute("INSERT OR IGNORE INTO execution_terminal_notices SELECT b.id,NULL FROM execution_batches b JOIN execution_notifications n ON n.batch_id=b.id WHERE b.state IN ('finished','stopped','cancelled')")
    store.db.commit()


def attach_execution(snapshot, definition, ref, records, fields, settings):
    """Freeze mode, field IDs, old output values, and source context before execution approval."""
    if settings.mode=='mock':
        synthetic=[p for p in snapshot['candidates'] if p['data_mode']=='SYNTHETIC_NO_CALL']
        removed=len(snapshot['candidates'])-len(synthetic)
        if removed:snapshot['excluded']['非模拟记录，模拟模式不处理']=removed
        snapshot['candidates']=synthetic
        snapshot['duplicates']=sum(bool(p.get('duplicate')) for p in synthetic)
    outputs = []
    for f in definition['result_fields']:
        field = next((x for x in fields if x['field_id']==f['target_field_id'] and x['field_name']==f['label']),None)
        if field:
            outputs.append({'key':f['key'], **field})
    for label in ('外呼状态','最近任务编号'):
        f=next((x for x in fields if x['field_name']==label and x['type']==1),None)
        if f:
            outputs.append({'key':'system_status' if label=='外呼状态' else 'system_id',**f})
    by_id={r['record_id']:r['fields'] for r in records}
    for person in snapshot['candidates']:
        source=by_id[person['record_id']]
        person['region']=text_value(source.get('通话地区'))
        person['locale']=text_value(source.get('通话语言'))
        person['timezone']=text_value(source.get('联系人时区'))
        person['context']={name:text_value(source.get(name)) for name in definition.get('context_fields',[])}
        person['expected_outputs']={f['field_name']:text_value(source.get(f['field_name'])) for f in outputs}
        if (settings.mode=='live' and settings.allow_automated_test_line and person['phone']=='+12763229632'
                and person['phone'] in settings.allowed_phones and person['data_mode']=='REAL_AUTHORIZED'
                and person['region']=='US' and person['locale']=='en-US'
                and text_value(source.get('测试情形'))=='PROVIDER_TEST_BOT'):
            person['recipient_kind']='provider_test_bot'
    snapshot['execution']={'mode':settings.mode,'writeback':settings.writeback,
                           'definition':definition,'resource':asdict(ref),'outputs':outputs,
                           'poll_timeout_seconds':settings.result_poll_timeout_seconds,
                           'poll_max_reads':settings.result_poll_max_reads}
    if any(p.get('recipient_kind')=='provider_test_bot' for p in snapshot['candidates']):
        snapshot['execution']['authorized_provider_test_bot']=True
    snapshot['execution_ready']=len([f for f in outputs if not f['key'].startswith('system_')])==len(definition['result_fields'])
    if settings.writeback:
        for f in definition['result_fields']:
            column=next((x for x in outputs if x['key']==f['key']),None)
            if column and column['type']==3 and any(v not in column.get('options',[]) for v in f['options']):
                snapshot['execution_ready']=False
    return snapshot


def authorized_automated_test_recipient(execution,person):
    # Narrow exception for the user-supplied automated test line; never a human quiet-hours bypass.
    return execution.get('authorized_provider_test_bot') is True and person.get('recipient_kind')=='provider_test_bot' and person.get('phone')=='+12763229632'


def valid_explicit_recontact(store,grant,person,actor,chat):
    if not isinstance(grant,dict) or not isinstance(grant.get('authorization_id'),str) or not grant['authorization_id'] or grant.get('scope')!='one_more_call' or grant.get('phone')!=person['phone']:
        return False
    row=store.db.execute("""SELECT s.request_json,s.provider_id,i.record_id,i.response,b.actor,b.chat_id,b.mode FROM submissions s JOIN execution_items i ON i.id=s.operation_id JOIN execution_batches b ON b.id=i.batch_id WHERE s.operation_id=?""",(grant.get('parent_operation_id'),)).fetchone()
    if not row or row['mode']!='live' or row['actor']!=actor or row['chat_id']!=chat or row['record_id']!=person['record_id']:
        return False
    if not row['provider_id'] or row['provider_id']!=grant.get('parent_resource_id'):
        return False
    latest=store.db.execute("SELECT s.operation_id FROM submissions s JOIN execution_items i ON i.id=s.operation_id JOIN execution_batches b ON b.id=i.batch_id WHERE b.mode='live' AND i.record_id=? ORDER BY s.rowid DESC LIMIT 1",(person['record_id'],)).fetchone()
    if not latest or latest['operation_id']!=grant.get('parent_operation_id'):return False
    request=json.loads(row['request_json']);response=json.loads(row['response'] or '{}')
    return request.get('phone')==person['phone'] and response.get('id')==row['provider_id'] and response.get('status')=='failed' and response.get('result_status') in ('available','unavailable','not_applicable')


def attach_recontact_review(store,snapshot,actor,chat):
    if snapshot['execution']['mode']!='live' or len(snapshot['candidates'])!=1:return
    person=snapshot['candidates'][0]
    prior=store.db.execute("SELECT i.id,s.provider_id FROM submissions s JOIN execution_items i ON i.id=s.operation_id JOIN execution_batches b ON b.id=i.batch_id WHERE b.mode='live' AND i.record_id=? ORDER BY s.rowid DESC LIMIT 1",(person['record_id'],)).fetchone()
    if not prior:return
    review={'scope':'one_more_call','phone':person['phone'],'parent_operation_id':prior['id'],'parent_resource_id':prior['provider_id']}
    if valid_explicit_recontact(store,{**review,'authorization_id':'pending-card-confirmation'},person,actor,chat):
        snapshot['execution']['recontact_review']=review
    else:
        snapshot['execution_ready']=False
        snapshot['execution']['recontact_blocked']='该记录已有电话提交，尚不能确认其为已结束的失败电话；请先人工核对，不会重复拨号。'


def approve_execution(store, token, actor, chat, operation, settings):
    with store.db:
        row=store.db.execute('SELECT * FROM roster_previews WHERE token=?',(token,)).fetchone()
        if not row or row['actor']!=actor or row['chat_id']!=chat or row['expires_at']<time.time():
            raise Clarification('名单已过期或你无权执行，请重新生成预览。')
        snapshot=json.loads(row['snapshot']); execution=snapshot.get('execution',{})
        mode={'execute_mock':'mock','execute_live':'live'}.get(operation)
        if mode is None or mode!=settings.mode or execution.get('mode')!=mode:
            raise Clarification('执行模式不匹配，请重新预览确认。')
        if row['state'] not in ('pending','execution_approved'):
            raise Clarification('这张名单已结束，请重新发起。')
        if not snapshot.get('execution_ready') or not snapshot['candidates'] or snapshot['duplicates']:
            raise Clarification('请先解决空名单、重复号码或结果字段映射。')
        draft=store.db.execute('SELECT state FROM task_definitions WHERE token=?',(snapshot.get('definition_token'),)).fetchone()
        if not draft or draft['state']!='confirmed':
            raise Clarification('任务定义尚未确认或已被修改。')
        if execution.get('writeback')!=settings.writeback:
            raise Clarification('回填设置已经变化，请重新生成名单。')
        existing=store.db.execute('SELECT id FROM execution_batches WHERE preview_token=?',(token,)).fetchone()
        if row['state']=='execution_approved' and existing:return existing['id']
        if execution.get('recontact_review'):
            execution['explicit_recontact']={**execution['recontact_review'],'authorization_id':'card-recontact:'+token}
        if mode=='live':
            if execution.get('explicit_recontact') and (len(snapshot['candidates'])!=1 or not valid_explicit_recontact(store,execution['explicit_recontact'],snapshot['candidates'][0],actor,chat)):
                raise Clarification('再次联系授权未绑定到同一联系人已结束的失败电话。')
            if not settings.api_key or not settings.allowed_phones:
                raise Clarification('真实外呼尚未配置 API Key 或测试号码白名单。')
            for person in snapshot['candidates']:
                if person['data_mode']!='REAL_AUTHORIZED' or person['phone'] not in settings.allowed_phones:
                    raise Clarification('真实外呼只允许白名单内且标记 REAL_AUTHORIZED 的联系人，模拟数据禁止拨号。')
                if not person.get('region') or not person.get('locale') or not person.get('timezone'):
                    raise Clarification('真实外呼需明确通话地区、语言和联系人时区。')
                try: ZoneInfo(person['timezone'])
                except (ZoneInfoNotFoundError,ValueError): raise Clarification('联系人时区无效。') from None
        batch_id='batch_'+hashlib.sha256(token.encode()).hexdigest()[:20]
        grant=execution.get('explicit_recontact')
        if grant:
            use=store.db.execute('SELECT batch_id FROM recontact_uses WHERE authorization_id=?',(grant['authorization_id'],)).fetchone()
            if use and use['batch_id']!=batch_id:raise Clarification('这次单通重拨授权已经使用，不能创建另一通电话。')
            store.db.execute('INSERT OR IGNORE INTO recontact_uses VALUES (?,?)',(grant['authorization_id'],batch_id))
        store.db.execute('INSERT OR IGNORE INTO execution_batches VALUES (?,?,?,?,?,?,?,?,?,?)',
            (batch_id,token,actor,chat,mode,'running',json.dumps(snapshot,ensure_ascii=False),time.time()+1800,None,time.time()))
        for person in snapshot['candidates']:
            item_id=batch_id+':'+person['record_id']
            store.db.execute('INSERT OR IGNORE INTO execution_items(id,batch_id,record_id,state,person) VALUES (?,?,?,?,?)',
                             (item_id,batch_id,person['record_id'],'queued',json.dumps(person,ensure_ascii=False)))
        store.db.execute("UPDATE roster_previews SET state='execution_approved' WHERE token=?",(token,))
    return batch_id


def batch_card(store,batch_id):
    row=store.db.execute('SELECT * FROM execution_batches WHERE id=?',(batch_id,)).fetchone()
    counts=Counter(x[0] for x in store.db.execute('SELECT state FROM execution_items WHERE batch_id=?',(batch_id,)))
    mode='模拟执行（不会拨号）' if row['mode']=='mock' else '真实外呼'
    state={'running':'处理中','paused':'已暂停：需核对','finished':'处理结束','stopped':'本轮已停止，不自动恢复','cancelled':'已取消剩余任务'}.get(row['state'],row['state'])
    names={'queued':'待执行','waiting':'等待电话结果','output_pending':'等待回填','done':'已处理',
           'skipped':'已跳过','conflict':'回填冲突','reconcile':'提交状态未知，需核对','failed':'失败','result_stopped':'结果未取得，已停止查询','output_stopped':'回填停止，需处理'}
    detail='；'.join(f'{names.get(k,k)} {v}' for k,v in counts.items())
    manifest=json.loads(row['manifest']); writes=manifest['execution']['writeback']
    responses=[json.loads(x[0]) for x in store.db.execute('SELECT response FROM execution_items WHERE batch_id=? AND response IS NOT NULL',(batch_id,))]
    ready=sum(r.get('result_status')=='available' for r in responses)
    meaningful=sum(r.get('result_status')=='available' and not r.get('mock') and any(
        r.get('result',{}).get(f['key']) not in (None,'',f.get('unknown_value'))
        for f in manifest['execution']['definition']['result_fields'] if f['type']=='enum') for r in responses)
    detail+=f'\n业务结果就绪 {ready}；含明确枚举答复 {meaningful}；已回填 {counts["done"] if writes else 0}'
    errors=Counter(x[0] for x in store.db.execute('SELECT error_kind FROM execution_items WHERE batch_id=? AND error_kind IS NOT NULL',(batch_id,)))
    detail+='\n电话情况：'+('；'.join(f'{label} {count}' for label,count in Counter(telephone_status(r,mock=row['mode']=='mock') for r in responses if r.get('result_status') in ('available','unavailable','not_applicable')).items()) or '尚无最终电话结果')
    for field in manifest['execution']['definition']['result_fields']:
        if field['type']!='enum':continue
        answers=Counter(r['result'][field['key']] for r in responses
                        if r.get('result_status')=='available' and isinstance(r.get('result'),dict)
                        and r['result'].get(field['key']) in field['options'])
        detail+='\n'+('模拟枚举统计：' if row['mode']=='mock' else '业务枚举统计：')+field['label']+'：'+ '；'.join(f'{option} {answers[option]}' for option in field['options'])
    if errors:detail+='\n待处理原因：'+'；'.join(f'{k} {v}' for k,v in errors.items())
    resource=manifest['execution']['resource']
    query={'table':resource['table_id']}
    if resource.get('view_id'):query['view']=resource['view_id']
    table_url=f"https://{resource['host']}/base/{resource['app_token']}?{urlencode(query)}"
    return {'header':{'title':{'tag':'plain_text','content':'CALL-E：'+('任务处理结束' if row['state']=='finished' else '外呼任务进度')}},
            'elements':[{'tag':'div','text':{'tag':'plain_text','content':f'{mode}\n任务编号：{batch_id}\n状态：{state}\n{detail}\n回填：'+('写入已确认的原表输出列' if writes else '仅本地保存，未开启表格写入')+'\n已处理不代表有效业务答复；完整结果状态保存在本地记录。'}},
                        {'tag':'action','actions':[{'tag':'button','text':{'tag':'plain_text','content':'查看原表'},'url':table_url,'type':'default'}]}]}


def telephone_status(response, *, mock=False):
    """Telephone execution/outcome never implies a positive business answer."""
    status=response.get('status')
    if status=='failed': label='技术失败'
    elif status=='canceled': label='已取消'
    else:
        label={'no_answer':'未接通','busy':'忙线','declined':'拒接','completed':'通话完成'}.get(response.get('call_outcome'),'电话结果未知')
    if mock:
        return '模拟完成' if status=='completed' else '模拟：'+label
    return label


class ExecutionWorker:
    def __init__(self,store,gateway,settings,*,provider=None,clock=time.time):
        self.store,self.gateway,self.settings,self.clock=store,gateway,settings,clock
        self.provider=provider or (CalleAPI(settings.api_key) if settings.mode=='live' and settings.api_key else FakeCalls(self._original_request))

    def _original_request(self,resource_id):
        row=self.store.db.execute('SELECT request_json FROM submissions WHERE provider_id=?',(resource_id,)).fetchone()
        return json.loads(row['request_json']) if row else None

    def _state(self,item,state,*,error=None,response=None,output=None,delay=0):
        with self.store.db:
            self.store.db.execute('UPDATE execution_items SET state=?,error_kind=?,response=COALESCE(?,response),output=COALESCE(?,output),next_poll=? WHERE id=?',
                (state,error,json.dumps(response,ensure_ascii=False) if response is not None else None,
                 json.dumps(output,ensure_ascii=False) if output is not None else None,self.clock()+delay,item['id']))

    def _pause(self,batch):
        with self.store.db:self.store.db.execute("UPDATE execution_batches SET state='paused' WHERE id=?",(batch['id'],))

    def _wait_for_result(self,item,*,response=None,delay=0):
        self._state(item,'waiting',response=response,delay=delay)
        with self.store.db:
            self.store.db.execute('UPDATE execution_items SET poll_started_at=COALESCE(poll_started_at,?),attempts=0 WHERE id=?',
                                  (self.clock(),item['id']))

    def _stop_result_queries(self,batch,item,reason):
        with self.store.db:
            self.store.db.execute("UPDATE execution_items SET state='result_stopped',error_kind=?,next_poll=0 WHERE id=?",(reason,item['id']))
            self.store.db.execute("UPDATE execution_batches SET state='stopped' WHERE id=?",(batch['id'],))

    def _preflight(self,person,manifest,ref):
        bindings=manifest['execution']['definition'].get('condition_bindings',[])
        if bindings:
            catalog={f['field_id']:f for f in self.gateway.fields(ref)}
            if any(b['field_id'] not in catalog or catalog[b['field_id']]['field_name']!=b['field_name'] for b in bindings):return False
        current=self.gateway.record(ref,person['record_id'])
        fields=current['fields']
        check=build_roster([current],manifest['conditions'])
        if not check['candidates'] or check['candidates'][0]['phone']!=person['phone']:
            return False
        for label,old in person.get('context',{}).items():
            if text_value(fields.get(label))!=old:return False
        if manifest['execution']['mode']=='live':
            for label,key in [('数据模式','data_mode'),('通话地区','region'),('通话语言','locale'),('联系人时区','timezone')]:
                if text_value(fields.get(label))!=person.get(key):return False
            if person['phone'] not in self.settings.allowed_phones or person['data_mode']!='REAL_AUTHORIZED':return False
            hour=datetime.now(ZoneInfo(person['timezone'])).hour
            if not 8<=hour<21 and not authorized_automated_test_recipient(manifest['execution'],person):return False
        if manifest['execution']['writeback']:
            for name,old in person.get('expected_outputs',{}).items():
                if text_value(fields.get(name))!=old:return False
        suppressed=self.store.db.execute('SELECT 1 FROM contact_suppression WHERE phone_hash=?',
                    (hashlib.sha256(person['phone'].encode()).hexdigest(),)).fetchone()
        return not suppressed

    def tick(self):
        if self.store.db.execute("SELECT 1 FROM execution_items WHERE state IN ('reconcile','result_stopped') LIMIT 1").fetchone():return False
        batch=self.store.db.execute("SELECT * FROM execution_batches WHERE state='running' OR (state IN ('paused','cancelled') AND EXISTS (SELECT 1 FROM execution_items i WHERE i.batch_id=execution_batches.id AND i.state IN ('waiting','output_pending'))) ORDER BY created_at LIMIT 1").fetchone()
        if not batch:return False
        manifest=json.loads(batch['manifest']);ref=BaseRef(**manifest['execution']['resource'])
        definition=manifest['execution']['definition']
        item=self.store.db.execute("SELECT * FROM execution_items WHERE batch_id=? AND state IN ('waiting','output_pending','queued') ORDER BY CASE state WHEN 'waiting' THEN 0 WHEN 'output_pending' THEN 1 ELSE 2 END,rowid LIMIT 1",(batch['id'],)).fetchone()
        if not item:
            if batch['state']!='running':return False
            with self.store.db:self.store.db.execute("UPDATE execution_batches SET state='finished' WHERE id=?",(batch['id'],))
            return True
        if batch['state']!='running' and item['state']=='queued':return False
        if item['state']=='waiting':
            started=item['poll_started_at']
            if started is None:
                saved=self.store.db.execute('SELECT created_at FROM submissions WHERE operation_id=?',(item['id'],)).fetchone()
                try: started=datetime.fromisoformat(saved['created_at']+'+00:00').timestamp()
                except (TypeError,ValueError): started=self.clock()
                with self.store.db:self.store.db.execute('UPDATE execution_items SET poll_started_at=? WHERE id=?',(started,item['id']))
            limits=manifest['execution']
            if self.clock()-started >= limits.get('poll_timeout_seconds',300):
                self._stop_result_queries(batch,item,'RESULT_TIMEOUT');return True
            if item['poll_count'] >= limits.get('poll_max_reads',20):
                self._stop_result_queries(batch,item,'RESULT_READ_LIMIT');return True
        if item['next_poll']>self.clock():return False
        person=json.loads(item['person'])
        try:
            if batch['mode']!=self.settings.mode or (batch['mode']=='live' and not self.settings.api_key):
                self._pause(batch);return True
            if item['state']=='queued':
                saved=self.store.db.execute('SELECT * FROM submissions WHERE operation_id=?',(item['id'],)).fetchone()
                if saved and saved['state']=='accepted':
                    self._wait_for_result(item);return True
                if saved and saved['state']=='submitting':
                    self._state(item,'reconcile',error='UNKNOWN_SUBMISSION');self._pause(batch);return True
                if self.clock()>batch['deadline'] or not self._preflight(person,manifest,ref):
                    self._state(item,'skipped',error='SOURCE_CHANGED_OR_WINDOW');return True
                # Overlapping fresh tasks never silently recontact an already reserved record.
                prior = batch['mode']=='live' and self.store.db.execute("SELECT 1 FROM execution_items i JOIN submissions s ON s.operation_id=i.id JOIN execution_batches b ON b.id=i.batch_id WHERE b.mode='live' AND i.record_id=? AND i.id!=?",(person['record_id'],item['id'])).fetchone()
                if prior and not valid_explicit_recontact(self.store,manifest['execution'].get('explicit_recontact'),person,batch['actor'],batch['chat_id']):
                    self._state(item,'skipped',error='PRIOR_CONTACT_REQUIRES_REVIEW');return True
                body=call_request(definition,person)
                reservation=self.store.reserve(item['id'],body)
                if reservation['state']=='accepted':
                    self._wait_for_result(item);return True
                # The cancellation/claim decision shares SQLite's write lock.
                with self.store.db:
                    claimed=self.store.db.execute("UPDATE submissions SET state='submitting' WHERE operation_id=? AND state='reserved' AND EXISTS (SELECT 1 FROM execution_batches WHERE id=? AND state='running')",
                                                  (item['id'],batch['id'])).rowcount==1
                if not claimed:return True
                try:
                    response=self.provider.create(body,reservation['idempotency_key'])
                except CallFailure as exc:
                    self._state(item,'reconcile' if exc.uncertain else 'failed',error='CREATE_UNCERTAIN' if exc.uncertain else 'CREATE_REJECTED',response={'request_rejected':not exc.uncertain,'http_status':exc.status,'error_code':exc.error_code,'details':exc.details})
                    self._pause(batch);return True
                except Exception:
                    self._state(item,'reconcile',error='CREATE_UNCERTAIN');self._pause(batch);return True
                self.store.accepted(item['id'],response['id'])
                self._wait_for_result(item,response=response,delay=1 if batch['mode']=='mock' else 5)
            elif item['state']=='waiting':
                original=self.store.db.execute('SELECT provider_id FROM submissions WHERE operation_id=?',(item['id'],)).fetchone()
                if not original or not original['provider_id']:
                    self._state(item,'reconcile',error='MISSING_ORIGINAL_ID');self._pause(batch);return True
                with self.store.db:self.store.db.execute('UPDATE execution_items SET poll_count=poll_count+1 WHERE id=?',(item['id'],))
                response=self.provider.get(original['provider_id'])
                with self.store.db:self.store.db.execute('UPDATE execution_items SET attempts=0 WHERE id=?',(item['id'],))
                if response.get('result_status')=='pending':
                    self._state(item,'waiting',response=response,delay=min(30,5+item['poll_count']*5))
                    return True
                if response.get('result_status') not in ('available','unavailable','not_applicable'):
                    raise CallFailure(200)
                if isinstance(response.get('result'),dict) and response['result'].get('do_not_contact',response['result'].get('_do_not_contact'))=='yes':
                    with self.store.db:
                        self.store.db.execute('INSERT OR IGNORE INTO contact_suppression VALUES (?,?)',
                            (hashlib.sha256(person['phone'].encode()).hexdigest(),self.clock()))
                output={}
                if response['result_status']=='available':
                    if not validate_result(definition,response.get('result')):
                        self._state(item,'conflict',response=response,error='INVALID_RESULT');return True
                    output={f['field_name']:response['result'][f['key']] for f in manifest['execution']['outputs'] if not f['key'].startswith('system_')}
                for f in manifest['execution']['outputs']:
                    if f['key']=='system_status':
                        output[f['field_name']]=telephone_status(response,mock=batch['mode']=='mock')
                    elif f['key']=='system_id':output[f['field_name']]=original['provider_id']
                self._state(item,'output_pending',response=response,output=output)
            elif item['state']=='output_pending':
                if not manifest['execution']['writeback']:
                    self._state(item,'done');return True
                self._writeback(item,manifest,ref,person)
        except Exception as exc:
            # Never turn errors into new calls. Writes/reads can be retried separately.
            attempts=item['attempts']+1
            with self.store.db:
                self.store.db.execute('UPDATE execution_items SET attempts=?,error_kind=?,next_poll=? WHERE id=?',
                    (attempts,type(exc).__name__,self.clock()+min(60,2**min(attempts,6)),item['id']))
            hard_read_error=isinstance(exc,CallFailure) and exc.status is not None and exc.status not in (429,503)
            if item['state']=='waiting' and (attempts>=3 or hard_read_error):
                self._stop_result_queries(batch,item,'RESULT_READ_ERROR')
            elif attempts>=3:
                if item['state']=='output_pending':self._state(item,'output_stopped',error='OUTPUT_RETRY_LIMIT')
                self._pause(batch)
        return True

    def _writeback(self,item,manifest,ref,person):
        values=json.loads(item['output'] or '{}')
        current=self.gateway.record(ref,item['record_id'])['fields']
        live_fields={f['field_id']:f for f in self.gateway.fields(ref)}
        for f in manifest['execution']['outputs']:
            if f['field_name'] not in values:continue
            live=live_fields.get(f['field_id'])
            if not live or live['field_name']!=f['field_name'] or live['type']!=f['type']:
                self._state(item,'conflict',error='OUTPUT_SCHEMA_CHANGED');return
            desired=values[f['field_name']]
            old=text_value(current.get(f['field_name']))
            if old not in (person['expected_outputs'][f['field_name']],desired):
                self._state(item,'conflict',error='MANUAL_OUTPUT_EDIT');return
            if live['type']==3 and desired not in live.get('options',[]):
                self._state(item,'conflict',error='OUTPUT_ENUM_MISMATCH');return
        if values and any(text_value(current.get(k))!=v for k,v in values.items()):
            self.gateway.write_fields(ref,item['record_id'],values,item['id'])
        self._state(item,'done')


def control_batch(store,batch_id,actor,chat,operation):
    with store.db:
        row=store.db.execute('SELECT * FROM execution_batches WHERE id=?',(batch_id,)).fetchone()
        if not row or row['actor']!=actor or row['chat_id']!=chat:
            raise Clarification('你无权操作这个外呼任务。')
        if row['state'] in ('finished','cancelled'):
            raise Clarification('该任务已结束。')
        if row['state']=='stopped' and operation!='cancel':
            raise Clarification('本轮已停止，不会继续查询或拨号；仅可取消剩余任务。')
        if operation=='resume':
            if row['state']=='stopped' or store.db.execute("SELECT 1 FROM execution_items WHERE batch_id=? AND state='result_stopped'",(batch_id,)).fetchone():
                raise Clarification('本轮结果查询已停止，不能通过继续任务重新查询或拨号。请保留原电话编号核对。')
            if store.db.execute("SELECT 1 FROM execution_items WHERE batch_id=? AND state='reconcile'",(batch_id,)).fetchone():
                raise Clarification('存在提交状态未知的电话，需先核对原请求，不能继续创建电话。')
            state='running'
            store.db.execute("UPDATE execution_items SET state='output_pending' WHERE batch_id=? AND state='output_stopped'",(batch_id,))
            store.db.execute('UPDATE execution_items SET attempts=0,next_poll=0 WHERE batch_id=?',(batch_id,))
        elif operation=='pause':state='paused'
        elif operation=='cancel':
            state='cancelled'
            store.db.execute("UPDATE execution_items SET state='skipped',error_kind='CANCELLED_BEFORE_SUBMIT' WHERE batch_id=? AND state='queued' AND NOT EXISTS (SELECT 1 FROM submissions WHERE operation_id=execution_items.id AND state!='reserved')",(batch_id,))
        else:raise Clarification('不支持的任务操作。')
        store.db.execute('UPDATE execution_batches SET state=? WHERE id=?',(state,batch_id))


def notify_execution(store,gateway):
    """Persistent same-card progress; notification failures never recreate a call."""
    for batch in store.db.execute('SELECT * FROM execution_batches ORDER BY created_at').fetchall():
        card=batch_card(store,batch['id'])
        if batch['state'] in ('running','paused'):
            card['elements'].append({'tag':'action','actions':[
                {'tag':'button','text':{'tag':'plain_text','content':'暂停后续' if batch['state']=='running' else '继续任务'},
                 'value':{'stage':'execution','batch_id':batch['id'],'operation':'pause' if batch['state']=='running' else 'resume'}},
                {'tag':'button','text':{'tag':'plain_text','content':'取消剩余（当前电话继续）'},
                 'value':{'stage':'execution','batch_id':batch['id'],'operation':'cancel'}}]})
        digest=hashlib.sha256(json.dumps(card,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        old=store.db.execute('SELECT * FROM execution_notifications WHERE batch_id=?',(batch['id'],)).fetchone()
        if not old or old['digest']!=digest:
            if old and old['message_id']:
                gateway.patch_card(old['message_id'],card)
                message_id=old['message_id']
            else:
                message_id=gateway.send_card(batch['chat_id'],batch['id'],card,kind='execution-progress')
            with store.db:
                store.db.execute('INSERT OR REPLACE INTO execution_notifications VALUES (?,?,?)',(batch['id'],message_id,digest))
        if batch['state'] in ('finished','stopped','cancelled') and not store.db.execute("SELECT 1 FROM execution_items WHERE batch_id=? AND state IN ('waiting','output_pending')",(batch['id'],)).fetchone():
            if not store.db.execute('SELECT 1 FROM execution_terminal_notices WHERE batch_id=?',(batch['id'],)).fetchone():
                # Stable Feishu UUID via send_card: retry delivery, never recreate a call.
                notice_id=gateway.send_card(batch['chat_id'],batch['id'],card,kind='execution-completion')
                with store.db:store.db.execute('INSERT OR IGNORE INTO execution_terminal_notices VALUES (?,?)',(batch['id'],notice_id))
