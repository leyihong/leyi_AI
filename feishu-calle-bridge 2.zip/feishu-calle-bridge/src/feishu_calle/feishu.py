"""Read-only Base inspection using the official SDK. No CALL-E dependency."""
import hashlib
import uuid
import json
from collections.abc import Iterator
from .resources import BaseRef, WikiRef
import re


class FeishuFailure(RuntimeError):
    def __init__(self,message,code=None):
        self.code=code
        super().__init__(message)


def response_data(response):
    if not response.success() or response.data is None:
        # Provider messages can contain operational data; only expose the code.
        raise FeishuFailure(f"Feishu request failed (code={response.code})")
    return response.data


class FeishuGateway:
    def __init__(self, client):
        self.client = client

    def resolve_wiki(self, ref: WikiRef, expected_app_token: str | None = None) -> BaseRef:
        from lark_oapi.api.wiki.v2 import GetNodeSpaceRequest
        request = GetNodeSpaceRequest.builder().token(ref.node_token).build()
        data = response_data(self.client.wiki.v2.space.get_node(request))
        node = data.node
        if node is None or node.obj_type != 'bitable':
            raise FeishuFailure('The wiki node is not a Base table')
        token = node.obj_token
        if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9]+', token):
            raise FeishuFailure('The wiki node returned no valid Base token')
        if expected_app_token is not None and token != expected_app_token:
            raise FeishuFailure('The wiki node target changed; review the resource binding')
        return BaseRef(ref.host, token, ref.table_id, ref.view_id)

    def fields(self, ref: BaseRef) -> list[dict]:
        from lark_oapi.api.bitable.v1 import ListAppTableFieldRequest
        def fetch(token):
            builder = (ListAppTableFieldRequest.builder().app_token(ref.app_token)
                       .table_id(ref.table_id).page_size(100))
            if token:
                builder.page_token(token)
            return response_data(self.client.bitable.v1.app_table_field.list(builder.build()))
        return [{"field_id": item.field_id, "field_name": item.field_name, "type": item.type, "options": [option.name for option in (getattr(getattr(item, "property", None), "options", None) or [])]}
                for item in self._pages(fetch)]

    @staticmethod
    def _pages(fetch) -> Iterator:
        token = None
        seen = set()
        while True:
            data = fetch(token)
            yield from data.items or []
            if not data.has_more:
                return
            token = data.page_token
            if not token or token in seen:
                raise FeishuFailure("Incomplete scan: missing or repeated pagination token")
            seen.add(token)

    def inspect(self, ref: BaseRef) -> dict:
        fields = self.fields(ref)
        records = self.records(ref)
        return {"fields": fields, "record_count": len(records), "scan_complete": True,
                "view_scoped": bool(ref.view_id)}

    def records(self, ref: BaseRef) -> list[dict]:
        from lark_oapi.api.bitable.v1 import ListAppTableRecordRequest
        def fetch(token):
            builder = (ListAppTableRecordRequest.builder().app_token(ref.app_token)
                       .table_id(ref.table_id).page_size(500))
            if ref.view_id:
                builder.view_id(ref.view_id)
            # Never send filter/sort here: these can override view semantics.
            if token:
                builder.page_token(token)
            return response_data(self.client.bitable.v1.app_table_record.list(builder.build()))
        records = {}
        for record in self._pages(fetch):
            if not record.record_id:
                raise FeishuFailure("Incomplete scan: record has no ID")
            records[record.record_id] = {"record_id": record.record_id, "fields": getattr(record, 'fields', {}) or {}}
        return list(records.values())

    def record(self, ref: BaseRef, record_id: str) -> dict:
        from lark_oapi.api.bitable.v1 import GetAppTableRecordRequest
        request = (GetAppTableRecordRequest.builder().app_token(ref.app_token)
                   .table_id(ref.table_id).record_id(record_id).build())
        record = response_data(self.client.bitable.v1.app_table_record.get(request)).record
        if not record or record.record_id != record_id:
            raise FeishuFailure('Record missing or changed')
        return {'record_id':record.record_id, 'fields':record.fields or {}}

    def create_record(self, ref: BaseRef, values: dict, operation_id: str) -> dict:
        from lark_oapi.api.bitable.v1 import CreateAppTableRecordRequest, AppTableRecord
        request=(CreateAppTableRecordRequest.builder().app_token(ref.app_token).table_id(ref.table_id)
                 .client_token(str(uuid.UUID(bytes=hashlib.sha256(operation_id.encode()).digest()[:16],version=4)))
                 .request_body(AppTableRecord.builder().fields(values).build()).build())
        record=response_data(self.client.bitable.v1.app_table_record.create(request)).record
        if not record or not record.record_id:raise FeishuFailure('Created record response missing ID; reconcile before retry')
        return {'record_id':record.record_id,'fields':record.fields or {}}

    def create_field(self,ref,name,kind,options,operation_id):
        from lark_oapi.api.bitable.v1 import CreateAppTableFieldRequest,AppTableField,AppTableFieldProperty,AppTableFieldPropertyOption
        body=AppTableField.builder().field_name(name).type(kind)
        if kind==3:body.property(AppTableFieldProperty.builder().options([AppTableFieldPropertyOption.builder().name(v).build() for v in options]).build())
        request=(CreateAppTableFieldRequest.builder().app_token(ref.app_token).table_id(ref.table_id)
            .client_token(str(uuid.UUID(bytes=hashlib.sha256(operation_id.encode()).digest()[:16],version=4)))
            .request_body(body.build()).build())
        response=self.client.bitable.v1.app_table_field.create(request)
        if not response.success():raise FeishuFailure(f'Create field rejected (code={response.code})',code=response.code)
        return response_data(response).field

    def write_fields(self, ref: BaseRef, record_id: str, values: dict, operation_id: str) -> None:
        from lark_oapi.api.bitable.v1 import UpdateAppTableRecordRequest, AppTableRecord
        request = (UpdateAppTableRecordRequest.builder().app_token(ref.app_token).table_id(ref.table_id)
                   .record_id(record_id).client_token(str(uuid.UUID(bytes=hashlib.sha256(operation_id.encode()).digest()[:16],version=4)))
                   .request_body(AppTableRecord.builder().fields(values).build()).build())
        response = self.client.bitable.v1.app_table_record.update(request)
        if not response.success():
            raise FeishuFailure(f'Writeback failed (code={response.code})')

    def send_card(self, chat_id: str, message_id: str, card: dict, *, kind: str = 'roster-preview') -> None:
        from lark_oapi.api.im.v1 import CreateMessageRequest, CreateMessageRequestBody
        body = (CreateMessageRequestBody.builder().receive_id(chat_id).msg_type('interactive')
                .uuid(hashlib.sha256((kind + ':' + message_id).encode()).hexdigest()[:32])
                .content(json.dumps(card, ensure_ascii=False)).build())
        response = self.client.im.v1.message.create(
            CreateMessageRequest.builder().receive_id_type('chat_id').request_body(body).build())
        if not response.success():
            raise FeishuFailure(f'Preview delivery failed (code={response.code})')
        return getattr(getattr(response,'data',None),'message_id',None)

    def patch_card(self, message_id: str, card: dict) -> None:
        from lark_oapi.api.im.v1 import PatchMessageRequest, PatchMessageRequestBody
        request = (PatchMessageRequest.builder().message_id(message_id)
                   .request_body(PatchMessageRequestBody.builder().content(json.dumps(card,ensure_ascii=False)).build()).build())
        response=self.client.im.v1.message.patch(request)
        if not response.success():
            raise FeishuFailure(f'Progress update failed (code={response.code})')

    def reply_text(self, message_id: str, text: str, kind: str) -> None:
        from lark_oapi.api.im.v1 import ReplyMessageRequest, ReplyMessageRequestBody
        body = (ReplyMessageRequestBody.builder().msg_type('text')
                .content(json.dumps({'text':text},ensure_ascii=False))
                .uuid(hashlib.sha256((kind + ':' + message_id).encode()).hexdigest()[:32]).build())
        response = self.client.im.v1.message.reply(
            ReplyMessageRequest.builder().message_id(message_id).request_body(body).build())
        if not response.success():
            raise FeishuFailure(f'Reply delivery failed (code={response.code})')

    def send_inspection(self, chat_id: str, message_id: str, summary: dict) -> None:
        from lark_oapi.api.im.v1 import CreateMessageRequest, CreateMessageRequestBody
        # Plain-text components prevent source field names from injecting card markup.
        names = [field["field_name"] for field in summary["fields"]]
        text = (f"Read-only table inspection completed. Records: {summary['record_count']}. "
                f"Fields: {', '.join(names[:25])}. "
                "No call was created and no table value was changed.")
        body = (CreateMessageRequestBody.builder().receive_id(chat_id).msg_type("interactive")
                .uuid(hashlib.sha256(message_id.encode()).hexdigest()[:32])
                .content(json.dumps({"header": {"title": {"tag": "plain_text", "content": "CALL-E: table inspection"}},
                    "elements": [{"tag": "div", "text": {"tag": "plain_text", "content": text}}]}))
                .build())
        response = self.client.im.v1.message.create(
            CreateMessageRequest.builder().receive_id_type("chat_id").request_body(body).build())
        if not response.success():
            raise FeishuFailure(f"Message delivery failed (code={response.code})")


def create_client(app_id: str, app_secret: str):
    import lark_oapi as lark
    return (lark.Client.builder().app_id(app_id).app_secret(app_secret)
            .log_level(lark.LogLevel.ERROR).build())
