"""Reviewable task/schema proposals. No LLM inference or external writes."""
import hashlib
import json
import re
import secrets
import time
from .preview import Clarification, parse_selection
from .output_columns import plan_output_columns


def propose_definition(text: str, fields: list[dict]) -> dict:
    clean = re.sub(r'https://[^\s<>]+', '', text)
    match = re.search(r'目的\s*[:：]\s*(.+?)(?=结果\s*[:：]|$)', clean, re.S)
    if not match or not match[1].strip():
        raise Clarification('请写明“目的：希望向联系人询问或确认什么”。')
    purpose = match[1].strip()
    if len(purpose) > 1000:
        raise Clarification('任务目的过长，请缩短至 1000 字以内。')
    conditions, unique = parse_selection(clean, fields)
    result_match = re.search(r'结果\s*[:：]\s*(.+)$', clean, re.S)
    proposals = []
    if result_match:
        for clause in re.split(r'[;；]', result_match[1].strip().rstrip('。；;')):
            parts = re.split(r'[=＝]', clause, maxsplit=1)
            if len(parts) != 2 or not parts[0].strip():
                raise Clarification('结果请使用“字段=选项/选项”或“字段=文本”，多个字段用分号分隔。')
            label, spec = (part.strip() for part in parts)
            if spec == '文本':
                proposals.append((label, 'text', []))
            else:
                options = list(dict.fromkeys(p.strip() for p in spec.split('/') if p.strip()))
                if len(options) < 2 or len(options) > 10:
                    raise Clarification('单选字段请给出 2–10 个不同选项，以 / 分隔。')
                if not any(v in options for v in ('未知','不明')):
                    options.append('未知')
                proposals.append((label, 'enum', options))
        source = '按你提供的结果字段整理；单选补充“未知”。'
    elif re.search(r'参加|参会|出席', purpose):
        proposals = [('回访出席意向', 'enum', ['参加', '不参加', '待定', '拒绝回答', '未知']),
                     ('人工联系请求', 'enum', ['需要', '不需要', '未知']),
                     ('回访摘要', 'text', [])]
        source = '根据参会确认目的推荐的规则模板，可取消后修改；尚未接入自由任务的模型推理。'
    else:
        proposals = [('联系人答复', 'text', []), ('人工联系请求', 'enum', ['需要', '不需要', '未知'])]
        source = '通用信息采集建议，可在消息中使用“结果：字段=选项/选项；备注=文本”自定义。'
    if not 1 <= len(proposals) <= 5 or len({p[0] for p in proposals}) != len(proposals):
        raise Clarification('请提供 1–5 个名称不重复的结果字段。')
    outputs = []
    protected = {'电话号码', '联系人', '允许电话联系', '禁止联系', '授权来源', '数据模式'}
    for i, (label, kind, options) in enumerate(proposals):
        if label in protected or len(label) > 40 or any(len(option) > 80 for option in options):
            raise Clarification('结果字段不可使用联系人、号码、授权等来源列，名称限 40 字，选项限 80 字。')
        existing = next((f for f in fields if f['field_name'] == label), None)
        # Existing dedicated result fields only; column creation is a later milestone.
        compatible = bool(existing and existing.get('type') in ((1, 3) if kind == 'enum' else (1,)))
        outputs.append({'key': f'result_{i+1}', 'label': label, 'type': kind, 'options': options,
                        'unknown_value': ('不明' if '不明' in options else '未知') if kind == 'enum' else None,
                        'target_field_id': existing['field_id'] if compatible else None})
    return plan_output_columns({'revision': 1, 'purpose': purpose, 'result_fields': outputs, 'conditions': conditions,
            'exclude_duplicates': unique, 'proposal_source': source, 'mode': 'preview_only',
            'context_fields': [f['field_name'] for f in fields if f['field_name'] in ('活动名称','活动时间','活动时区')],
            'disclosure': '通话仅使用已确认目的及以下背景列（如有）：活动名称、活动时间、活动时区。其他表格字段不发送。'},fields)


def init_definitions(store):
    store.db.execute('''CREATE TABLE IF NOT EXISTS task_definitions (
        token TEXT PRIMARY KEY, message_id TEXT UNIQUE NOT NULL, chat_id TEXT NOT NULL,
        actor TEXT NOT NULL, payload TEXT NOT NULL, definition TEXT NOT NULL,
        state TEXT NOT NULL, expires_at REAL NOT NULL)''')
    store.db.commit()


def save_definition(store, payload, definition):
    with store.db:
        store.db.execute('INSERT OR IGNORE INTO task_definitions VALUES (?,?,?,?,?,?,?,?)',
            (secrets.token_urlsafe(24), payload['message_id'], payload['chat_id'], payload['actor'],
             json.dumps(payload, ensure_ascii=False), json.dumps(definition, ensure_ascii=False),
             'pending', time.time()+900))
    return dict(store.db.execute('SELECT * FROM task_definitions WHERE message_id=?',
                                (payload['message_id'],)).fetchone())


def definition_card(row):
    definition = json.loads(row['definition'])
    code = hashlib.sha256(row['message_id'].encode()).hexdigest()[:8]
    lines = [f"任务编号：{code}\n任务版本：{definition['revision']}\n任务目的：" + definition['purpose'], definition['proposal_source'],
             '筛选：' + '；'.join(f'{name}{op}{value}' for name,op,value in definition['conditions']),
             '同号规则：' + ('同一号码保留第一条，其余去重。' if definition['exclude_duplicates'] else '存在同号时需处理后才能确认名单。'),
             '建议结果字段：']
    if definition.get('change_summary'):
        lines.insert(0,'本次修改：'+'、'.join(definition['change_summary']))
    if definition.get('interpretation'):lines.insert(1,'指令理解：'+definition['interpretation'])
    if definition.get('trace_code'):lines.append('本地解析复核编号：'+definition['trace_code'])
    if definition.get('review_diff') and definition['revision']>1:
        diff=definition['review_diff']
        names={'purpose':'任务目的','conditions':'筛选条件','exclude_duplicates':'去重规则',
               'result_fields':'结果字段','recipient_selection':'指定对象'}
        lines.insert(1,'实际变更：'+'、'.join(names[k] for k in diff if k in names)+'；其余设置保留。')
        if 'result_fields' in diff:
            before={f['label']:f for f in diff['result_fields']['before'] or []}
            for f in diff['result_fields']['after'] or []:
                old=before.get(f['label'])
                if old==f:continue
                render=lambda item:'无' if item is None else ('/'.join(item['options']) if item['type']=='enum' else '文本')
                lines.append('字段差异 '+f['label']+'：'+render(old)+' → '+render(f))
    if definition.get('questions'):
        lines.insert(2,'拟询问：'+'；'.join(definition['questions']))
    for f in definition['result_fields']:
        mapping = f.get('column_issue') if f.get('column_action')=='blocked' else ('复用已有兼容列' if f['target_field_id'] else ('确认后新建单选列' if f['type']=='enum' else '确认后新建文本列'))
        lines.append(f"• {f['label']}：" + (' / '.join(f['options']) if f['type']=='enum' else '简短文本') + '；' + mapping)
    lines.extend(['电话未接通等技术状态单独记录，不当成业务否定或拒绝回答。', definition['disclosure'],
                  '确认定义后将按所列方案新建缺失输出列（追加到原表末尾），不会改动已有列；不拨号。名单卡会另行列明模拟/真实执行与回填范围，须再次确认。',
                  '可直接 @我描述修改目的、筛选或结果字段，无需重发链接；修改后需重新确认，旧卡片失效。',
                  '也可使用明确标签：对象：姓名或记录编号；目的：新目的；筛选：新条件；结果：字段=选项/选项。',
                  '状态：' + {'pending':'等待确认','confirmed':'任务定义已确认，正在生成名单预览','cancelled':'已取消','superseded':'已被新版本替代，请使用最新卡片' }[row['state']]])
    if row['state'] == 'pending':
        lines.append(f'按钮暂不可用时，可 @我发送：确认定义 {code}（只生成名单，不拨号）')
    elements = [{'tag':'div','text':{'tag':'plain_text','content':'\n'.join(lines)}}]
    if row['state'] == 'pending':
        elements.append({'tag':'action','actions':[
            {'tag':'button','type':'primary','text':{'tag':'plain_text','content':'确认定义并建列，生成名单' if any(f.get('column_action')=='create' for f in definition['result_fields']) else '确认定义，生成名单'},
             'value':{'stage':'definition','token':row['token'],'operation':'confirm'}},
            {'tag':'button','text':{'tag':'plain_text','content':'取消并修改'},
             'value':{'stage':'definition','token':row['token'],'operation':'cancel'}}]})
    return {'config':{'update_multi':True},'header':{'title':{'tag':'plain_text','content':(('CALL-E：任务方案已更新（待确认）' if definition.get('change_summary') else 'CALL-E：结果字段已更新（待确认）') if definition['revision'] > 1 else 'CALL-E：确认任务与结果字段')}},'elements':elements}


def act_on_definition(store, token, actor, chat, operation):
    with store.db:
        row = store.db.execute('SELECT * FROM task_definitions WHERE token=?',(token,)).fetchone()
        if not row or row['actor'] != actor or row['chat_id'] != chat or row['expires_at'] < time.time():
            raise Clarification('任务定义已过期或你无权操作，请重新发起。')
        if operation not in ('confirm','cancel'):
            raise Clarification('不支持的任务定义操作。')
        state = {'confirm':'confirmed','cancel':'cancelled'}[operation]
        if row['state'] not in ('pending', state):
            raise Clarification('该任务定义已结束，请重新发起。')
        store.db.execute('UPDATE task_definitions SET state=? WHERE token=?',(state,token))
        if operation == 'confirm':
            payload = json.loads(row['payload'])
            payload.update(phase='scan', definition_token=token)
            store.db.execute('INSERT OR IGNORE INTO inspection_jobs(message_id,payload) VALUES (?,?)',
                             (row['message_id']+':scan',json.dumps(payload,ensure_ascii=False)))
        return dict(store.db.execute('SELECT * FROM task_definitions WHERE token=?',(token,)).fetchone())


def approved_definition(store, payload):
    row = store.db.execute("SELECT * FROM task_definitions WHERE token=? AND state='confirmed'",
                           (payload.get('definition_token'),)).fetchone()
    if not row or any(row[key] != payload[key] for key in ('actor','chat_id','message_id')):
        raise Clarification('未找到本任务已确认的定义，请重新发起。')
    return json.loads(row['definition'])
