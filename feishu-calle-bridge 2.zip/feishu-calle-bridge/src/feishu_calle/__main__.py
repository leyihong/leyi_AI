"""Development commands with explicit external-side-effect selection."""
import argparse
import json
import os
from pathlib import Path
from .config import Settings
from .resources import parse_resource_link


def main() -> None:
    parser = argparse.ArgumentParser(description="Feishu CALL-E bridge development tools")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("check-config")
    link = commands.add_parser("inspect-link", help="Parse a Base URL offline")
    link.add_argument("url")
    trace=commands.add_parser('inspect-trace',help='Read private structured parsing evidence offline; no model thoughts or dialing')
    trace.add_argument('code')
    listen = commands.add_parser("listen-inspection", help="Run the authorized Feishu bridge; mock by default, explicit live confirmations required")
    listen.add_argument("--enable-feishu", action="store_true", required=True)
    listen.add_argument("--bindings", type=Path, required=True)
    args = parser.parse_args()
    settings = Settings.from_env(os.environ)
    if args.command == "check-config":
        print(json.dumps({"mode": settings.mode, "missing_live_settings": settings.missing_live_settings(),
                          "nlp_engine": settings.nlp_engine, "dialing_implemented": True, "writeback_enabled": settings.writeback, "test_phone_allowlist_configured": bool(settings.allowed_phones), "network_requests": 0}, indent=2))
    elif args.command == "inspect-link":
        ref = parse_resource_link(args.url)
        print(json.dumps({"valid": True, "table_selected": bool(ref.table_id),
                          "view_selected": bool(ref.view_id), "network_requests": 0}))
    elif args.command=='inspect-trace':
        from .store import Store
        from .audit import read_audit
        if not settings.database.exists():raise SystemExit('Local database not found')
        store=Store(settings.database)
        try:print(json.dumps(read_audit(store,args.code),ensure_ascii=False,indent=2))
        finally:store.close()
    else:
        from .inspection_runtime import run
        run(settings, bot_id=os.environ.get("FEISHU_BOT_OPEN_ID", ""), bindings_path=args.bindings)


if __name__ == "__main__":
    main()
